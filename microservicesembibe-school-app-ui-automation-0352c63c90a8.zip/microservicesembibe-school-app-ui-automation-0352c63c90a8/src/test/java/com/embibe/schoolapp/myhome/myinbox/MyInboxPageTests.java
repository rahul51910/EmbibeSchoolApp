package com.embibe.schoolapp.myhome.myinbox;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.create.CreatePage;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.myhome.myinbox.MyInboxPage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class MyInboxPageTests extends TestBase {
    LoginPage loginPage = null;
    MyHomePage myHomePage = null;
    MyInboxPage myInboxPage = null;
    String jwtToken = null;
    String orgId = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();
    CreatePage createPage = null;

    @Test(description = "Verify MyInbox page",groups = {"regression_suite","myHome_myInbox"})
    public void verifyMyInboxPage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify My home MyInbox page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying Messages tab");
        Assert.assertTrue(myInboxPage.isMessagesTabDisplaying(),"Messages tab is not displaying in MyInbox page");
        LoggerUtils.info("Verifying Files shared tab");
        Assert.assertTrue(myInboxPage.isFilesSharedTabDisplaying(),"Files shared tab is not displaying in MyInbox page");
        LoggerUtils.info("Verifying My Students tab");
        Assert.assertTrue(myInboxPage.isMyStudentsTabDisplaying(),"My Students tab is not displaying in MyInbox page");
    }

    @Test(description = "Verify Inbox Menu tabs",groups = {"regression_suite","myHome_myInbox"})
    public void verifyMyInboxMenuTabs(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Inbox Menu tabs");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying Inbox menu tab");
        Assert.assertTrue(myInboxPage.isInboxTabDisplaying(),"Inbox tab is not displaying");
        LoggerUtils.info("Verifying sent menu tab");
        Assert.assertTrue(myInboxPage.isSentTabDisplaying(),"sent tab is not displaying");
        LoggerUtils.info("Verifying Important menu tab");
        Assert.assertTrue(myInboxPage.isImportantTabDisplaying(),"Important tab is not displaying");
        LoggerUtils.info("Verifying drafts menu tab");
        Assert.assertTrue(myInboxPage.isDraftsTabDisplaying(),"Drafts tab is not displaying");
        LoggerUtils.info("Verifying trash menu tab");
        Assert.assertTrue(myInboxPage.isTrashTabDisplaying(),"Trash tab is not displaying");

    }
    @Test(description = "Verify chose type of mail popup",groups = {"regression_suite","myHome_myInbox"})
    public void verifyChoseTypeOfMailPopup(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify chose type of mail popup");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose Mail button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Asserting type of mail pop up desc text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailDescText().equals("Choose the type of mail you are composing"),"Type of mail pop up desc text is not matched");
        LoggerUtils.info("Asserting the Types of mails");
        Assert.assertTrue(myInboxPage.getAnnouncementText().equals("Announcement"),"Announcement text is not matched");
        Assert.assertTrue(myInboxPage.getSendNoticeText().equals("Send Notice"),"Send Notice text is not matched");
        Assert.assertTrue(myInboxPage.getReportCardText().equals("Report Card"),"Report Card text is not matched");
        Assert.assertTrue(myInboxPage.getNoteInDiaryText().equals("Note in a diary"),"Note in a diary text is not matched");
    }

    @Test(description = "Verify Edit chose type of mail popup",groups = {"regression_suite","myHome_myInbox"})
    public void verifyEditChoseTypeOfMailPopup(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify chose type of mail popup");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose Mail button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Click On Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Click on type of mail editor");
        myInboxPage.clickOnTypeOfMailEditor();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Asserting type of mail pop up desc text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailDescText().equals("Choose the type of mail you are composing"),"Type of mail pop up desc text is not matched");
        LoggerUtils.info("Asserting the Types of mails");
        Assert.assertTrue(myInboxPage.getAnnouncementText().equals("Announcement"),"Announcement text is not matched");
        Assert.assertTrue(myInboxPage.getSendNoticeText().equals("Send Notice"),"Send Notice text is not matched");
        Assert.assertTrue(myInboxPage.getReportCardText().equals("Report Card"),"Report Card text is not matched");
        Assert.assertTrue(myInboxPage.getNoteInDiaryText().equals("Note in a diary"),"Note in a diary text is not matched");
    }


    @Test(description = "Verify Files shared",groups = {"regression_suite","myHome_myInbox"})
    public void verifyFilesShared(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Files shared");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on Files shared");
        myInboxPage.clickOnFilesShared();
        LoggerUtils.info("Validate the Number of Files shared");
        Assert.assertTrue(myInboxPage.getFilesSharedCount()==schoolAppOps.getListOfFilesShared(jwtToken),"Files ");
    }
    @Test(description = "Verify download Option for Shared File",groups = {"regression_suite","myHome_myInbox"})
    public void verifyDownloadOptionForSharedFile(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify download Option for Shared File");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on Files shared");
        myInboxPage.clickOnFilesShared();
        LoggerUtils.info("Validate Download option for shared files");
        if (myInboxPage.getFilesSharedCount()>0){
            LoggerUtils.info("Click on first shared file");
            myInboxPage.clickOnSharedFile();
            LoggerUtils.info("Validate shared file pop up window");
            Assert.assertTrue(myInboxPage.isSharedFilePopupHeaderDisplaying(),"Shared file pop up header is ot displaying");
            LoggerUtils.info("validate download button is displaying");
            Assert.assertTrue(myInboxPage.isDownloadButtonIsDisplaying(),"Download button is not displaying");
        }else {
            LoggerUtils.info("There is no shared files to download");
        }
    }
    @Test(description = "Verify Forward Option for Shared File",groups = {"regression_suite","myHome_myInbox"})
    public void verifyForwardOptionForSharedFile(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify forward Option for Shared File");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on Files shared");
        myInboxPage.clickOnFilesShared();
        LoggerUtils.info("Validate forward option for shared files");
        if (myInboxPage.getFilesSharedCount()>0){
            LoggerUtils.info("Click on first shared file");
            myInboxPage.clickOnSharedFile();
            LoggerUtils.info("Validate shared file pop up window");
            Assert.assertTrue(myInboxPage.isSharedFilePopupHeaderDisplaying(),"Shared file pop up header is ot displaying");
            LoggerUtils.info("validate forward button is displaying");
            Assert.assertTrue(myInboxPage.isForwardButtonIsDisplaying(),"Forward button is not displaying");
            LoggerUtils.info("Click on forward button");
            myInboxPage.clickOnForward();
            LoggerUtils.info("Asserting type of mail pop up header text ");
            Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
            LoggerUtils.info("Asserting type of mail pop up desc text ");
            Assert.assertTrue(myInboxPage.getTypeOfMailDescText().equals("Choose the type of mail you are composing"),"Type of mail pop up desc text is not matched");
            LoggerUtils.info("Asserting the Types of mails");
            Assert.assertTrue(myInboxPage.getAnnouncementText().equals("Announcement"),"Announcement text is not matched");
            Assert.assertTrue(myInboxPage.getSendNoticeText().equals("Send Notice"),"Send Notice text is not matched");
            Assert.assertTrue(myInboxPage.getReportCardText().equals("Report Card"),"Report Card text is not matched");
            Assert.assertTrue(myInboxPage.getNoteInDiaryText().equals("Note in a diary"),"Note in a diary text is not matched");
        }else {
            LoggerUtils.info("There is no shared files to forward");
        }
    }
    @Test(description = "Verify mark as Read, important and Delete Options",groups = {"regression_suite","myHome_myInbox"})
    public void verifyMarkAsReadImportantDelete(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify mark as Read, important and Delete Options");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("click on Sent mails");
        myInboxPage.clickOnInboxSent();
        LoggerUtils.info("Click on select All");
        myInboxPage.clickOnSelectAll();
        Assert.assertTrue(myInboxPage.isMarkAsImportantOptionDisplaying(),"Mark as Important option is not displaying");
        Assert.assertTrue(myInboxPage.isMarkAsReadOptionIsDisplaying(),"Mark as Read option is not displaying");
        Assert.assertTrue(myInboxPage.isDeleteOptionAvailable(),"Delete option is not displaying");
    }


    @Test(description = "Verify Inbox messages",groups = {"regression_suite","myHome_myInbox"})
    public void verifyInboxMessages(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify mark as Read, important and Delete Options");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("click on inbox mails");
        myInboxPage.clickOnInboxTab();
        LoggerUtils.info("verify messages are available in inbox");
        if (myInboxPage.verifyIsMessagesAvailable()){
            LoggerUtils.info("Assert the total messages in inbox");
            Assert.assertTrue(myInboxPage.validateTotalMessages("inbox",jwtToken),"total messages in inbox not matched");
        }else {
            LoggerUtils.info("there is no messages available in inbox");
        }
    }
//    @Test(description = "Verify Sent messages",groups = {"regression_suite","myHome_myInbox"})
    public void verifySentMessages(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify mark as Read, important and Delete Options");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("click on inbox mails");
        myInboxPage.clickOnInboxSent();
        LoggerUtils.info("verify messages are available in sent");
        if (myInboxPage.verifyIsMessagesAvailable()){
            LoggerUtils.info("Assert the total messages in sent");
            Assert.assertTrue(myInboxPage.validateTotalMessages("sent",jwtToken),"total messages in sent not matched");
        }else {
            LoggerUtils.info("there is no messages available in sent");
        }
    }
    @Test(description = "Verify draft messages",groups = {"regression_suite","myHome_myInbox"})
    public void verifyDraftMessages(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify mark as Read, important and Delete Options");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("click on inbox mails");
        myInboxPage.clickOnDrafts();
        LoggerUtils.info("verify messages are available in draft");
        if (myInboxPage.verifyIsMessagesAvailable()){
            LoggerUtils.info("Assert the total messages in draft");
            Assert.assertTrue(myInboxPage.validateTotalMessages("drafts",jwtToken),"draft messages in sent not matched");
        }else {
            LoggerUtils.info("there is no messages available in sent");
        }
    }
    @Test(description = "Verify Trash messages in inbox tab",groups = {"regression_suite","myHome_myInbox"})
    public void verifyTrashMessages(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Trash messages in inbox tab");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("click on inbox mails");
        myInboxPage.clickOnTrash();
        LoggerUtils.info("verify messages are available in trash");
        if (myInboxPage.verifyIsMessagesAvailable()){
            LoggerUtils.info("Assert the total messages in trash");
            Assert.assertTrue(myInboxPage.validateTotalMessages("trash",jwtToken),"Trash messages in sent not matched");
        }else {
            LoggerUtils.info("there is no messages available in trash tab");
        }
    }
    @Test(description = "Verify inbox Important messages",groups = {"regression_suite","myHome_myInbox"})
    public void verifyImportantMessages(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify inbox Important messages");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("click on inbox mails");
        myInboxPage.clickOnImportant();
        LoggerUtils.info("verify messages are available in Important");
        if (myInboxPage.verifyIsMessagesAvailable()){
            LoggerUtils.info("Assert the total messages in Important");
            Assert.assertTrue(myInboxPage.validateTotalMessages("important",jwtToken),"Important messages in sent not matched");
        }else {
            LoggerUtils.info("there is no messages available in Important tab");
        }
    }
    @Test(description = "Verify Students while compose",groups = {"regression_suite","myHome_myInbox"})
    public void verifyStudentsWhileCompose(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Students while compose");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Click on Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Assert the type of mail text on compose page");
        Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
        LoggerUtils.info("Click on mail To");
        myInboxPage.clickOnMailTo();
        LoggerUtils.info("Validate sender header text");
        Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
        LoggerUtils.info("Verify Students appearing while composing");
        Assert.assertTrue(myInboxPage.getStudentsSizeWhileCompose()>0,"Students are not showing");

    }

    @Test(description = "Verify Groups while compose",groups = {"regression_suite","myHome_myInbox"})
    public void verifyGroupsWhileCompose(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Groups while compose");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Click on Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Assert the type of mail text on compose page");
        Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
        LoggerUtils.info("Click on mail To");
        myInboxPage.clickOnMailTo();
        LoggerUtils.info("Validate sender header text");
        Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
        LoggerUtils.info("Click on groups");
        myInboxPage.clickOnGroups();
        LoggerUtils.info("Verify Groups appearing while composing");
        Assert.assertTrue(myInboxPage.getGroupsSizeWhileCompose()>0,"Groups are not showing");

    }
    @Test(description = "Verify compose a mail to All Students",groups = {"regression_suite","myHome_myInbox"})
    public void verifyComposeAMailToAllStudents(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        String subject = "Subject"+schoolAppOps.getEpochTime();
        String body = "mailBody"+schoolAppOps.getEpochTime();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify compose a mail to All Students");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Click on Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Assert the type of mail text on compose page");
        Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
        LoggerUtils.info("Click on mail To");
        myInboxPage.clickOnMailTo();
        LoggerUtils.info("Validate sender header text");
        Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
        LoggerUtils.info("Click on select all students");
        myInboxPage.clickOnSelectAllStudents();
        LoggerUtils.info("Click on save and continue");
        myInboxPage.clickOnSaveAndContinue();
        LoggerUtils.info("Set mail Subject");
        myInboxPage.setMailSubject(subject);
        LoggerUtils.info("set mail body");
        myInboxPage.setMailBody(body);
        LoggerUtils.info("click on send");
        myInboxPage.clickOnSend();
        LoggerUtils.info("click on inbox sent tab");
        myInboxPage.clickOnInboxSent();
        LoggerUtils.info("Get first mail subject and validate");
        Assert.assertTrue(myInboxPage.getSubjectOfFirstMail().equals(subject),"sent mail subject is not matched ");
    }
    @Test(description = "Verify compose a mail to All Groups",groups = {"regression_suite","myHome_myInbox"})
    public void verifyComposeAMailToAllGroups(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        String subject = "Subject"+schoolAppOps.getEpochTime();
        String body = "mailBody"+schoolAppOps.getEpochTime();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify compose a mail to All Groups");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Click on Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Assert the type of mail text on compose page");
        Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
        LoggerUtils.info("Click on mail To");
        myInboxPage.clickOnMailTo();
        LoggerUtils.info("Validate sender header text");
        Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
        LoggerUtils.info("Click on Groups");
        myInboxPage.clickOnGroups();
        LoggerUtils.info("Click on select all Groups");
        myInboxPage.clickOnSelectAllGroups();
        LoggerUtils.info("Click on save and continue");
        myInboxPage.clickOnSaveAndContinue();
        LoggerUtils.info("Set mail Subject");
        myInboxPage.setMailSubject(subject);
        LoggerUtils.info("set mail body");
        myInboxPage.setMailBody(body);
        LoggerUtils.info("click on send");
        myInboxPage.clickOnSend();
        LoggerUtils.info("click on inbox sent tab");
        myInboxPage.clickOnInboxSent();
        LoggerUtils.info("Get first mail subject and validate");
        Assert.assertTrue(myInboxPage.getSubjectOfFirstMail().equals(subject),"sent mail subject is not matched ");
    }

    @Test(description = "Verify compose a mail to single student",groups = {"regression_suite","myHome_myInbox"})
    public void verifyComposeAMailToSingleStudent(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        String subject = "Subject"+schoolAppOps.getEpochTime();
        String body = "mailBody"+schoolAppOps.getEpochTime();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify compose a mail to single student");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Click on Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Assert the type of mail text on compose page");
        Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
        LoggerUtils.info("Click on mail To");
        myInboxPage.clickOnMailTo();
        LoggerUtils.info("Validate sender header text");
        Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
        LoggerUtils.info("Verify teachers has students ");
        if(myInboxPage.getStudentsSizeWhileCompose()>0){
            LoggerUtils.info("click on first student");
            myInboxPage.selectSingleStudent();
            LoggerUtils.info("Click on save and continue");
            myInboxPage.clickOnSaveAndContinue();
            LoggerUtils.info("Set mail Subject");
            myInboxPage.setMailSubject(subject);
            LoggerUtils.info("set mail body");
            myInboxPage.setMailBody(body);
            LoggerUtils.info("click on send");
            myInboxPage.clickOnSend();
            LoggerUtils.info("click on inbox sent tab");
            myInboxPage.clickOnInboxSent();
            LoggerUtils.info("Get first mail subject and validate");
            Assert.assertTrue(myInboxPage.getSubjectOfFirstMail().equals(subject),"sent mail subject is not matched ");
        }else {
            LoggerUtils.info("There is no students for the given teacher ");
        }

    }

    @Test(description = "Verify delete a mail",groups = {"regression_suite","myHome_myInbox"})
    public void verifyDeleteMail(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        String subject = "Subject"+schoolAppOps.getEpochTime();
        String body = "mailBody"+schoolAppOps.getEpochTime();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify compose a mail to single student");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Click on compose button");
        myInboxPage.clickOnCompose();
        LoggerUtils.info("Asserting type of mail pop up header text ");
        Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
        LoggerUtils.info("Click on Announcement");
        myInboxPage.clickOnAnnouncement();
        LoggerUtils.info("Assert the type of mail text on compose page");
        Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
        LoggerUtils.info("Click on mail To");
        myInboxPage.clickOnMailTo();
        LoggerUtils.info("Validate sender header text");
        Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
        LoggerUtils.info("Verify teachers has students ");
        if(myInboxPage.getStudentsSizeWhileCompose()>0){
            LoggerUtils.info("click on first student");
            myInboxPage.selectSingleStudent();
            LoggerUtils.info("Click on save and continue");
            myInboxPage.clickOnSaveAndContinue();
            LoggerUtils.info("Set mail Subject");
            myInboxPage.setMailSubject(subject);
            LoggerUtils.info("set mail body");
            myInboxPage.setMailBody(body);
            LoggerUtils.info("click on send");
            myInboxPage.clickOnSend();
            LoggerUtils.info("click on inbox sent tab");
            myInboxPage.clickOnInboxSent();
            LoggerUtils.info("Get first mail subject and validate");
            Assert.assertTrue(myInboxPage.getSubjectOfFirstMail().equals(subject),"sent mail subject is not matched ");
            LoggerUtils.info("Click on trash");
            myInboxPage.clickOnTrash();
            LoggerUtils.info("get today's trash messages before delete");
            int todayMessagesInTrash = myInboxPage.getTodayMessagesCount();
            LoggerUtils.info("Click on inbox sent tab");
            myInboxPage.clickOnInboxSent();
            if (myInboxPage.verifyIsMessagesAvailable()){
                LoggerUtils.info("Select the first message");
                myInboxPage.selectFirstMessage();
                LoggerUtils.info("delete the first message");
                myInboxPage.deleteFirstMessage();
                LoggerUtils.info("Click on trash");
                myInboxPage.clickOnTrash();
                LoggerUtils.info("get today's trash messages after delete");
                int totalMessageAfterDelete = myInboxPage.getTodayMessagesCount();
                Assert.assertTrue(todayMessagesInTrash+1==totalMessageAfterDelete,"total message are not matched");
            }else {
                LoggerUtils.info("there is no messages available in inbox sent tab");
            }
        }else {
            LoggerUtils.info("There is no students for the given teacher ");
        }






    }


    @Test(description = "Verify Forward a shared file",groups = {"regression_suite","myHome_myInbox"})
    public void verifyForwardSharedFile(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        String subject = "Subject"+schoolAppOps.getEpochTime();
        String body = "mailBody"+schoolAppOps.getEpochTime();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Forward a shared file");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on Files shared");
        myInboxPage.clickOnFilesShared();
        LoggerUtils.info("Validate forward option for shared files");
        if (myInboxPage.getFilesSharedCount()>0){
            LoggerUtils.info("Click on first shared file");
            myInboxPage.clickOnSharedFile();
            LoggerUtils.info("Validate shared file pop up window");
            Assert.assertTrue(myInboxPage.isSharedFilePopupHeaderDisplaying(),"Shared file pop up header is ot displaying");
            LoggerUtils.info("validate forward button is displaying");
            Assert.assertTrue(myInboxPage.isForwardButtonIsDisplaying(),"Forward button is not displaying");
            LoggerUtils.info("Click on forward button");
            myInboxPage.clickOnForward();
            LoggerUtils.info("Asserting type of mail pop up header text ");
            Assert.assertTrue(myInboxPage.getTypeOfMailHeaderText().equals("Choose the type of mail"),"Type of mail pop up header text is not matched");
            LoggerUtils.info("Asserting type of mail pop up desc text ");
            Assert.assertTrue(myInboxPage.getTypeOfMailDescText().equals("Choose the type of mail you are composing"),"Type of mail pop up desc text is not matched");
            LoggerUtils.info("Click on on announcement");
            myInboxPage.clickOnAnnouncement();
            LoggerUtils.info("Assert the type of mail text on compose page");
            Assert.assertTrue(myInboxPage.getTypeOfMailTypeTextOnCompose().contains("Announcement"),"Type of mail text is not matched on compose page");
            LoggerUtils.info("Click on mail To");
            myInboxPage.clickOnMailTo();
            LoggerUtils.info("Validate sender header text");
            Assert.assertTrue(myInboxPage.getSenderHeaderText().contains("Announcement"),"Sender Header is not matched");
            LoggerUtils.info("Verify teachers has students ");
            if(myInboxPage.getStudentsSizeWhileCompose()>0){
                LoggerUtils.info("click on first student");
                myInboxPage.selectSingleStudent();
                LoggerUtils.info("Click on save and continue");
                myInboxPage.clickOnSaveAndContinue();
                LoggerUtils.info("Set mail Subject");
                myInboxPage.setMailSubject(subject);
                LoggerUtils.info("set mail body");
                myInboxPage.setMailBody(body);
                LoggerUtils.info("click on send");
                myInboxPage.clickOnSend();
                LoggerUtils.info("click on inbox sent tab");
                myInboxPage.clickOnInboxSent();
                LoggerUtils.info("Get first mail subject and validate");
                Assert.assertTrue(myInboxPage.getSubjectOfFirstMail().equals(subject),"sent mail subject is not matched ");
            }else {
                LoggerUtils.info("There is no students for the given teacher ");
            }

        }else {
            LoggerUtils.info("There is no shared files to forward");
        }
    }

    @Test(description = "Verify downloaded attachment is working ",groups = {"regression_suite","myHome_myInbox"})
    public void verifyDownloadAttachmentIsWorking(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify downloaded attachment is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on Files shared");
        myInboxPage.clickOnFilesShared();
        LoggerUtils.info("Validate Download option for shared files");
        if (myInboxPage.getFilesSharedCount()>0){
            String fileName = myInboxPage.getFirstAttachmentName();
            LoggerUtils.info("Click on first shared file");
            myInboxPage.clickOnSharedFile();
            LoggerUtils.info("Validate shared file pop up window");
            Assert.assertTrue(myInboxPage.isSharedFilePopupHeaderDisplaying(),"Shared file pop up header is ot displaying");
            LoggerUtils.info("validate download button is displaying");
            Assert.assertTrue(myInboxPage.isDownloadButtonIsDisplaying(),"Download button is not displaying");
            LoggerUtils.info("get Download Files Count before download");
            int preCount = schoolAppOps.getAllDownloadFilesCount();
            LoggerUtils.info("Click on download button");
            myInboxPage.clickOnDownload();
            LoggerUtils.info("Verify file is downloaded");
            int postCount = schoolAppOps.getAllDownloadFilesCount();
            Assert.assertTrue(postCount== preCount+1,"File is not downloaded");

        }else {
            LoggerUtils.info("There is no shared files to download");
        }
    }
    @Test(description = "Verify class details on my students section ",groups = {"regression_suite","myHome_myInbox"})
    public void verifyClassDetailsOnMyStudents(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        orgId= Properties.schoolId;
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify class details on my students section ");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on my students");
        myInboxPage.clickOnMyStudents();
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getClassIdAndKvCodes(jwtToken);
        Set<String> classes = myClassesMap.keySet();
        LoggerUtils.info("Assert the number of classes");
        Assert.assertTrue(classes.size()== myInboxPage.getClassCount(),"Class count is not matched");
        LoggerUtils.info("Assert the class names");
        Assert.assertTrue(classes.containsAll(myInboxPage.getClassNames()),"class names are not matched");
    }
    @Test(description = "Verify Subject details on my students section ",groups = {"regression_suite","myHome_myInbox"})
    public void verifySubjectDetailsOnMyStudents(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        orgId= Properties.schoolId;
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify Subject details on my students section");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on my students");
        myInboxPage.clickOnMyStudents();
        //Map<String,Map<String,Object>> classStudentMap = schoolAppOps.getClassDetails(jwtToken,orgId,0,100);
        //Set<String> classes = classStudentMap.keySet();
        LoggerUtils.info("Assert the number of classes");
        int classcountfromapi = schoolAppOps.getClassCount(jwtToken);
        Assert.assertTrue(classcountfromapi== myInboxPage.getClassCount(),"Class count is not matched");
        List<String> subjectNamesfromapi = schoolAppOps.getSubjectsNames(jwtToken);
        Set<String> subjectSet = myInboxPage.getSubjectsNames();
        for (int i =0;i<subjectNamesfromapi.size();i++) {
            LoggerUtils.info("Assert the class subjects");
            Assert.assertTrue(subjectSet.contains(subjectNamesfromapi.get(i).toString()),"Subject is not matched");
        }
    }
    @Test(description = "Verify Student strength on my students section ",groups = {"regression_suite","myHome_myInbox"})
    public void verifyStudentsStrengthOnMyStudents(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        orgId= Properties.schoolId;
        jwtToken = Properties.jwtResellerToken;
        LoggerUtils.info("Verify  Student strength details on my students section");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on my students");
        myInboxPage.clickOnMyStudents();
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getClassIdAndKvCodes(jwtToken);
        Set<String> classes = myClassesMap.keySet();
        LoggerUtils.info("Assert the number of classes");
        Assert.assertTrue(classes.size()== myInboxPage.getClassCount(),"Class count is not matched");
        for (String str:classes) {
            String studentsCountFromUI= myInboxPage.getStudentStrengthByClass(str);
            LoggerUtils.info("Click on ClassName");
            myInboxPage.clickOnClassName(str);
            myInboxPage.scrollDown();
            LoggerUtils.info("Assert the student strength");
            String studentCountFromBackend= myClassesMap.get(str).get("strength").toString();
            if (studentCountFromBackend.equals("0")){
                LoggerUtils.info("No students are available for this class : "+str);
            }else {
                Assert.assertTrue(studentsCountFromUI.equals(studentCountFromBackend),"Student strength is not matched");
            }

        }
    }
    @Test(description = "Verify student details on my students section ",groups = {"regression_suite","myHome_myInbox"})
    public void verifyStudentDetailsOnMyStudents(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        orgId= Properties.schoolId;
        LoggerUtils.info("Verify class details on my students section ");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyInboxMenu();
        LoggerUtils.info("Verifying Inbox page URL");
        Assert.assertTrue( myInboxPage.verifySchedulePageURL(Properties.baseUrl+"/school/home/inbox"),"My inbox page url is not matched");
        LoggerUtils.info("Verifying click on my students");
        myInboxPage.clickOnMyStudents();
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getClassIdAndKvCodes(Embibetoken);
        Set<String> classes = myClassesMap.keySet();
        LoggerUtils.info("Assert the number of classes");
        Assert.assertTrue(classes.size()== myInboxPage.getClassCount(),"Class count is not matched");
        LoggerUtils.info("Assert the student names ");
        //Assert.assertTrue(myInboxPage.getStudentNames(myClassesMap,jwtToken),"Student names are not matched");
    }

    @Test(description = "Verify student details on my students section ",groups = {"regression_suite","myHome_myInbox"})
    public void verifyAddStudentOnMyStudents() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        createPage = new CreatePage();
        orgId = Properties.schoolId;
        LoggerUtils.info("Verify class details on my students section ");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyStudents();
        LoggerUtils.info("click On My Students");
        myInboxPage.clickAddStudentButton();
        LoggerUtils.info("Click to add student button");
        String name = createPage.randomName();
        myInboxPage.selectAndEnterFirstName(name);
        myInboxPage.selectAndEnterLastName(name);
        myInboxPage.randomMobileNumberGenerate();
        String number = myInboxPage.randomMobileNumberGenerate();
        myInboxPage.selectMobileNumber(number);
        myInboxPage.selectTheClassArrow();
        LoggerUtils.info("Click to Select class");
        myInboxPage.selectRecommendedAllVideo(1);
        LoggerUtils.info("Click to  class value");
        myInboxPage.clickAddStudentButtonOfDetails();
        LoggerUtils.info("Click add Student Button Of Details");
        driver.navigate().refresh();
        myInboxPage.waitingScreen();

        driver.navigate().refresh();
        myInboxPage.waitingScreen();
        driver.navigate().refresh();
        myInboxPage.waitingScreen();
        driver.navigate().refresh();

        myInboxPage.clickFirstNameOfClass();
        LoggerUtils.info("Click First Name Of Class");
        myInboxPage.scrollDown();
        myInboxPage.numberVerification();
        Assert.assertEquals(myInboxPage.numberVerification(),myInboxPage.randomMobileNumberGenerate());






    }
    @Test(description = "Verify Sorting of student details on my students section ",groups = {"regression_suite","myHome_myInbox"})
    public void sortingMyStudentsButton() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myInboxPage = new MyInboxPage();
        createPage = new CreatePage();
        orgId = Properties.schoolId;
        LoggerUtils.info("Verify the class details on my students section ");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on MyInbox module");
        myInboxPage.clickOnMyStudents();
        LoggerUtils.info("Click on MyStudent");

        myInboxPage.clickSortButton();
        LoggerUtils.info("Click on Click on ascending order of name sort");

        myInboxPage.clickSortButton();
        LoggerUtils.info("Click on Click on descending order of  name sort");

        myInboxPage.clickClassName();
        LoggerUtils.info("Click on MyInbox module class name 10/12 etc");

        myInboxPage.clickStudentSort();
        LoggerUtils.info("Click on MyInbox module and sort the ascending order of student data ");

        myInboxPage.clickStudentSort();
        LoggerUtils.info("Click on MyInbox module and sort the descending order of student data ");

    }
}
