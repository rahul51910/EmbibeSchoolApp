package com.embibe.schoolapp.teach;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.teach.TeachPage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TeachPageTests extends TestBase {
    LoginPage loginPage = null;
    MyHomePage myHomePage = null;
    TeachPage teachPage = null;
    String jwtToken = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();
    @Test(description = "Verify Teach page ",groups = {"regression_suite","teach-tests"})
    public void verifyLessonCreatePage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        LoggerUtils.info("Verify Teach page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying teach  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("validate teach page text");
        Assert.assertTrue(teachPage.getTeachPageText().equals("Choose a class to teach"));
    }
    @Test(description = "Verify teachers schedule is visible on Teach page ",groups = {"regression_suite","teach-tests"})
    public void verifyTeachersSchedule(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        LoggerUtils.info("Verify teachers schedule is visible on teach page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("Asserting the total timetable days for the week ");
        Assert.assertTrue(teachPage.getTimeTableDays()==7,"Total timetable day's are not matching");
        LoggerUtils.info("Asserting the total Allotted periods");
        Assert.assertTrue(teachPage.getTotalAllottedPeriods()>1,"Allotted periods are not matched");
        LoggerUtils.info("Asserting total periods per day");
        Assert.assertTrue(teachPage.getTotalPeriodsPerDay()==9,"Total periods per day is not matching");
    }

    @Test(description = "Verify Jio meet link",groups = {"regression_suite","teach-tests"})
    public void verifyJioMeetLink(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        LoggerUtils.info("Verify Jio meet link");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("Is start teaching button visible");
        if (teachPage.isStartTeachingButtonAvailable()){
            LoggerUtils.info("Verify Jio link copy button visible");
            Assert.assertTrue(teachPage.isCopyJioLinkButtonVisible(),"Jio link copy button is not visible");
            LoggerUtils.info("Verify start teaching button text");
            Assert.assertTrue(teachPage.getStartTeachingButtonText().equals("Start Teaching"),"Start teaching button is not working");
        }else {
           LoggerUtils.info("Start teaching is not available for today's periods");
        }

    }
    @Test(description = "Verify teacher is navigated to Jio meet",groups = {"regression_suite","teach-tests"})
    public void verifyTeacherIsNavigatedToJioMeet(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        jwtToken="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJsYXN0TmFtZSI6Ikt1bWFyICAiLCJ0aW1lX3N0YW1wIjoiMjAyMS0wOS0xMyAxMTozODo1MyBVVEMiLCJzdWJfb3JnYW5pemF0aW9uX2lkIjoxLCJtb2JpbGUiOiI5MDAwMDE3ODc5Iiwicm9vdE9yZ0lkIjoiNjBjMWUzZDEzMzVmNWE1ZDQ0NmY2YmNlIiwiZmlyc3ROYW1lIjoiUmFrZXNoIiwib3JnVHlwZSI6IlNjaG9vbCIsInBhcmVudE9yZ0lkIjoiNjBjMWU1NjkzMzVmNWE1ZDQ0NmY2YmQyIiwicGVyc29uYVR5cGUiOiJUZWFjaGVyIiwib3JnYW5pemF0aW9uX2lkIjoxLCJhZG1pbklkIjoiNjBjMjI5NDQ4NDdiZGE3ZTE0Mzk3YTE1IiwiaWQiOjE1MDAwNDUwMTIsImVtYWlsIjoicmFqZXNoa0BlbWJpYmUuY29tIn0.ZxTjNWbTT8WRTwVy6kMtg0pOweMh80rM8b9Aae7ksJlIi4QMniKvNH2tfjtRspeJ4HKwCEo0PMPCMDumLQ0P0A";
        LoggerUtils.info("Verify teacher is navigated to Jio meet");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("Is start teaching button visible");
        if (teachPage.isStartTeachingButtonAvailable()){
            LoggerUtils.info("Verify teacher is navigated to Jio meet");
            Assert.assertTrue(teachPage.verifyTeacherNavigatedJioMeet(),"Teacher is not navigated to Jio meet");
        }else {
            LoggerUtils.info("Start teaching is not available for today's periods");
        }

    }
    @Test(description = "Verify Students section visible on Jio meet",groups = {"regression_suite","teach-tests"})
    public void verifyStudentSectionVisibleOnJioMeet(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        jwtToken="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJsYXN0TmFtZSI6Ikt1bWFyICAiLCJ0aW1lX3N0YW1wIjoiMjAyMS0wOS0xMyAxMTozODo1MyBVVEMiLCJzdWJfb3JnYW5pemF0aW9uX2lkIjoxLCJtb2JpbGUiOiI5MDAwMDE3ODc5Iiwicm9vdE9yZ0lkIjoiNjBjMWUzZDEzMzVmNWE1ZDQ0NmY2YmNlIiwiZmlyc3ROYW1lIjoiUmFrZXNoIiwib3JnVHlwZSI6IlNjaG9vbCIsInBhcmVudE9yZ0lkIjoiNjBjMWU1NjkzMzVmNWE1ZDQ0NmY2YmQyIiwicGVyc29uYVR5cGUiOiJUZWFjaGVyIiwib3JnYW5pemF0aW9uX2lkIjoxLCJhZG1pbklkIjoiNjBjMjI5NDQ4NDdiZGE3ZTE0Mzk3YTE1IiwiaWQiOjE1MDAwNDUwMTIsImVtYWlsIjoicmFqZXNoa0BlbWJpYmUuY29tIn0.ZxTjNWbTT8WRTwVy6kMtg0pOweMh80rM8b9Aae7ksJlIi4QMniKvNH2tfjtRspeJ4HKwCEo0PMPCMDumLQ0P0A";
        LoggerUtils.info("Verify Students section visible on Jio meet");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("Is start teaching button visible");
        if (teachPage.isStartTeachingButtonAvailable()){
            LoggerUtils.info("Verify student section is visible");
            Assert.assertTrue(teachPage.isStudentSectionVisibleOnJioMeet(),"Student section is not visible on Jio meet");
        }else {
            LoggerUtils.info("Start teaching is not available for today's periods");
        }

    }
    @Test(description = "Verify Teachers section visible on Jio meet",groups = {"regression_suite","teach-tests"})
    public void verifyTeachersSectionVisibleOnJioMeet(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        jwtToken="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJsYXN0TmFtZSI6Ikt1bWFyICAiLCJ0aW1lX3N0YW1wIjoiMjAyMS0wOS0xMyAxMTozODo1MyBVVEMiLCJzdWJfb3JnYW5pemF0aW9uX2lkIjoxLCJtb2JpbGUiOiI5MDAwMDE3ODc5Iiwicm9vdE9yZ0lkIjoiNjBjMWUzZDEzMzVmNWE1ZDQ0NmY2YmNlIiwiZmlyc3ROYW1lIjoiUmFrZXNoIiwib3JnVHlwZSI6IlNjaG9vbCIsInBhcmVudE9yZ0lkIjoiNjBjMWU1NjkzMzVmNWE1ZDQ0NmY2YmQyIiwicGVyc29uYVR5cGUiOiJUZWFjaGVyIiwib3JnYW5pemF0aW9uX2lkIjoxLCJhZG1pbklkIjoiNjBjMjI5NDQ4NDdiZGE3ZTE0Mzk3YTE1IiwiaWQiOjE1MDAwNDUwMTIsImVtYWlsIjoicmFqZXNoa0BlbWJpYmUuY29tIn0.ZxTjNWbTT8WRTwVy6kMtg0pOweMh80rM8b9Aae7ksJlIi4QMniKvNH2tfjtRspeJ4HKwCEo0PMPCMDumLQ0P0A";
        LoggerUtils.info("Verify Teachers section visible on Jio meet");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("Is start teaching button visible");
        if (teachPage.isStartTeachingButtonAvailable()){
            LoggerUtils.info("Verify Teachers section visible on jio meet");
            Assert.assertTrue(teachPage.isTeacherSectionVisibleOnJioMeet(),"Teacher section is not visible Jio meet");
        }else {
            LoggerUtils.info("Start teaching is not available for today's periods");
        }

    }

    @Test(description = "Verify Teachers sections visible on Jio meet",groups = {"regression_suite","teach-tests"})
    public void verifyTeachersSectionsVisibleOnJioMeet(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        LoggerUtils.info("Verify Teachers section visible on Jio meet");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( teachPage.verifyTeachPageURL(Properties.baseUrl+"/teach"),"Lesson create url is not matched");
        LoggerUtils.info("Is start teaching button visible");
        if (teachPage.isStartTeachingButtonAvailable()){
            LoggerUtils.info("Verify Teachers sections visible on jio meet");
            Assert.assertTrue(teachPage.isPreReadinessDisplaying(),"teachers preReadiness is not displaying");
            Assert.assertTrue(teachPage.isHomeworkStatsDisplayed(),"teachers homework stats is not displaying");
            Assert.assertTrue(teachPage.isRecapSuggestions(),"teachers recap suggestions is not displaying");
            Assert.assertTrue(teachPage.isAddInteractiveDisplayed(),"teachers interactive is not displaying");
        }else {
            LoggerUtils.info("Start teaching is not available for today's periods");
        }

    }
    @Test(description = "verify Lesson Library",groups = {"regression_suite","teach-tests"})
    public void verifyLessonLibrary() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        teachPage = new TeachPage();
        LoggerUtils.info("Verify Teachers section visible on Jio meet");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnTeach();
        myHomePage.clickLessonLibrary();


    }


}
