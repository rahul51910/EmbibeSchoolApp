package com.embibe.schoolapp;

import com.browserstack.local.Local;
import com.embibe.schoolapp.driver.DriverInitializer;
import com.embibe.schoolapp.driver.driverfactory.DriverEnvironment;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.myhome.attendance.AttendancePage;
import com.embibe.schoolapp.pages.myhome.myclasses.MyClassesPage;
import com.embibe.schoolapp.utils.Properties;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class TestBase {
    public WebDriver driver = null;

    SchoolAppOps schoolAppOps = new SchoolAppOps();
    private Local local;
    public static String jwtToken = null;
    public static String Embibetoken=null;
    private static final ZoneId defaultZoneId = ZoneId.systemDefault();
    static String getAlphaNumericString(int n)
    {
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        StringBuilder sb = new StringBuilder(n);
        for (int i = 0; i < n; i++) {
            int index = (int)(AlphaNumericString.length() * Math.random());
            sb.append(AlphaNumericString.charAt(index));
        }
        return sb.toString();
    }

    private void startLocalTestingOnBrowserStack() throws Exception {
        if (System.getProperty("driverEnvironment").equals(DriverEnvironment.BROWSERSTACK)) {
            String BROWSERSTACK_LOCAL_IDENTIFIER = getAlphaNumericString(10);
            local = new Local();
            Map<String, String> options = new HashMap<String, String>();
            options.put("key", Properties.BROWSER_STACK_KEY);
            options.put("localIdentifier",BROWSERSTACK_LOCAL_IDENTIFIER);
            options.put("forcelocal","true");
            System.out.println("port number 45691 is busy " + isPortBusy(45691));
            if (isPortBusy(45691)) {
                killThePort();
            }
            local.start(options);
        }
    }
    public void GETjwtToken(){
        schoolAppOps = new SchoolAppOps();
        jwtToken= schoolAppOps.getresellerJwtTokenForShowAPI();
        Embibetoken=schoolAppOps.getEmbibeTokenShowAPI();
    }

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() throws Exception {
        System.out.println(" before suite");
        startLocalTestingOnBrowserStack();
        GETjwtToken();
    }



    @AfterSuite(alwaysRun = true)
    public void afterSuite() throws Exception {
        System.out.println(" after suite");
        if (local != null) {
            local.stop();
            if (isPortBusy(45691))
                killThePort();

        }

    }

    @BeforeMethod(alwaysRun = true)
    public void setUp() throws Exception {
        System.out.println("Before method");
        driver = new DriverInitializer(System.getProperty("driver")).init();

    }
    public void openUrl(String baseUrl){
        driver.get(baseUrl);
    }
    public void navigateToUrl(String baseUrl){
        driver.navigate().to(baseUrl);
    }

    private boolean isPortBusy(int portNumber) {
        boolean isBusy = false;
        try (Socket socket = new Socket("localhost", portNumber)) {
            isBusy = true;
        } catch (IOException e) {
            isBusy = false;
        }
        return isBusy;
    }


    public void killThePort() {
        //lsof -i :45691 to find out  the process id by port number
        //kill -9 98206
        try {
            Runtime run = Runtime.getRuntime();
            Process process = run.exec("pgrep BrowserSt");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            String processId;
            while ((processId = reader.readLine()) != null) {
                int exitVal = process.waitFor();
                if (exitVal == 0) {
                    System.out.print("browserStack process is running on this process id ");
                    System.out.println(processId);
                    run.exec("kill -9 " + processId);
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    @AfterMethod(alwaysRun = true)
    public void captureScreenShot(ITestResult result, java.lang.reflect.Method methodname, ITestContext context){
        if (result.getStatus() == ITestResult.FAILURE) {
            getScreenshot(driver,result.getMethod().getMethodName() );
        }
    }
    public static String getScreenshot(WebDriver driver, String screenshotName) {
        String destination = null;
        try {
            String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);
            // after execution, you could see a folder "FailedTestsScreenshots" under src folder
            destination = System.getProperty("user.dir") + "/target/Screenshots/" + screenshotName+"_"+dateName + ".png";
            File finalDestination = new File(destination);
            FileUtils.copyFile(source, finalDestination);
        }catch (IOException e){
            e.printStackTrace();
        }finally {
            return destination;
        }
    }
    public static LocalDateTime getLocalDateByEpoch(Long epochDate) {
        return LocalDateTime.ofInstant(Instant.ofEpochSecond(epochDate, 0), ZoneId.systemDefault());
    }
    @AfterMethod(alwaysRun = true)
    public void tearDown(){
        if (null != driver) {

            driver.quit();
            driver = null;
        }
    }

}
