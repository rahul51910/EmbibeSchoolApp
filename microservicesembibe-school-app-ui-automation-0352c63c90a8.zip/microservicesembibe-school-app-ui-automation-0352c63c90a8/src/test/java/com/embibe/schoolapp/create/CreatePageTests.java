package com.embibe.schoolapp.create;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.create.CreatePage;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.List;


public class CreatePageTests extends TestBase {
    LoginPage loginPage = null;
    MyHomePage myHomePage = null;
    CreatePage createPage = null;
    String jwtToken = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();


    @Test(description = "Verify lesson Create page ",groups = {"regression_suite","create-tests"})
    public void verifyLessonCreatePage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        //LoggerUtils.info("Verify lesson Create page");
        //LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        //LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
//        LoggerUtils.info("Verify create button on home screen");
//        Assert.assertTrue(myHomePage.isCreateButtonDisplayed(),"Create button is not displayed");
       // LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
       // LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
       // LoggerUtils.info("validate create page text");
        Assert.assertTrue(createPage.getCreatePageText().equals("Choose a class to Teach"));
    }
    @Test(description = "Verify teachers schedule is visible on create page ",groups = {"regression_suite","create-tests"})
    public void verifyTeachersSchedule(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify teachers schedule is visible on create page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Asserting the total timetable days for the week ");
        Assert.assertTrue(createPage.getTimeTableDays()==7,"Total timetable day's are not matching");
        LoggerUtils.info("Asserting the total Allotted periods");
        Assert.assertTrue(createPage.getTotalAllottedPeriods()>1,"Allotted periods are not matched");
        LoggerUtils.info("Asserting total periods per day");
        Assert.assertTrue(createPage.getTotalPeriodsPerDay()==10,"Total periods per day is not matching");
    }
    @Test(description = "Verify Click on No topic selected period",groups = {"regression_suite","create-tests"})
    public void verifyClickOnNoTopicSelectedPeriod(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Click on No topic selected period");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("validate pre and post actions tab and view lesson text");
            Assert.assertTrue(createPage.getPreAndPostActionsTabText().equals("Pre and Post Class Actions"),"Pre and post actions tab text is not matched");
            Assert.assertTrue(createPage.getViewLessonTabText().equals("View Lesson"),"View lesson tab text is not matched");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify All pre class actions  ",groups = {"regression_suite","create-tests"})
    public void verifyAllPreClassActions(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();
        List<String> preActListExp = new ArrayList<>();
        preActListExp.add("CREATE OR MODIFY LESSON");
        preActListExp.add("REVIEW HOMEWORK");
        preActListExp.add("REVIEW PREREQUISITE READINESS");
        preActListExp.add("POST ANNOUNCEMENT");

        LoggerUtils.info("Verify All pre class actions");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Get the pre class actions ");
            List<String> preActListAct = createPage.getAllPreClassActions();
            LoggerUtils.info("validate the pre class actions ");
            Assert.assertTrue(preActListAct.size()==preActListExp.size() && preActListAct.containsAll(preActListExp),"Pre class actions are not matched");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify All post class actions  ",groups = {"regression_suite","create-tests"})
    public void verifyAllPostClassActions(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();
        List<String> postActListExp = new ArrayList<>();
       // postActListExp.add("CHECK LESSON SUMMARY");
        postActListExp.add("SET HOMEWORK");
        postActListExp.add("SET TEST");
        //postActListExp.add("REVIEW CLASS PROGRESS");

        LoggerUtils.info("Verify All post class actions");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Get the pre class actions ");
            List<String> postActListAct = createPage.getAllPostClassActions();
            LoggerUtils.info("validate the post class actions ");
            Assert.assertTrue(postActListAct.size()==postActListExp.size() && postActListAct.containsAll(postActListExp),"Pre class actions are not matched");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify view lesson option available",groups = {"regression_suite","create-tests"})
    public void verifyViewLessonOptionAvailable(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();
        LoggerUtils.info("Verify view lesson option available");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Verify  view lesson tab available");
            Assert.assertTrue(createPage.isViewLessonTabAvailable(),"View lesson tab is not displaying");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify Create Lesson button available",groups = {"regression_suite","create-tests"})
    public void verifyCreateLessonOption(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Create Lesson button available");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  create lesson button available");
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"create lesson button is not displaying");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify change topic and continue to create lesson buttons",groups = {"regression_suite","create-tests"})
    public void verifyChangeTopicAndContinueToCreateLessonOptions(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify change topic and continue to create lesson buttons");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Validate continue to create and change topic buttons");
            Assert.assertTrue(createPage.isContinueToCreateLessonDisplayed(),"Continue to create is not displaying");
            Assert.assertTrue(createPage.isChangeTopicButtonDisplayed(),"Change topic button is not displaying");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }

    @Test(description = "Verify book details on select topic page",groups = {"regression_suite","create-tests"})
    public void verifyBookDetailsOnSelectTopicPage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify book details on select topic page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Verify book details on select topic page");
            Assert.assertTrue(createPage.getSelectBookTitle().equals("Selected Book"),"select book title is not matched");
            Assert.assertTrue(createPage.getBookTitle().length()>0,"book title is not showing");
            Assert.assertTrue(createPage.getClassDetails().length()>0,"Class details are not coming");
//            Assert.assertTrue(createPage.getBookDuration().length()>0,"Book duration is not showing");
//            Assert.assertTrue(createPage.videoDuration().length()>0,"video duration is not showing");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify user is navigate to Coobo Lesson Creation",groups = {"regression_suite","create-tests"})
    public void VerifyUserNavigateToCooboLessonCreation(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify user is navigate to Coobo Lesson Creation");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Validate user is navigated to lesson creation page");
            Assert.assertTrue(createPage.verifyTeacherNavigatedToCreatePage(),"user is not navigated to coobo lesson creation page");

        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify user is navigate to Coobo Lesson Creation",groups = {"regression_suite","create-tests"})
    public void VerifyLessonCreationAndSave(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify user is navigate to Coobo Lesson Creation");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
//            createPage.createPageRefresh();
//            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Validate slides count");
            Assert.assertTrue(createPage.getSlidesCount()== createPage.getTotalSlides(),"Slides count is not matched");
        }else {
            LoggerUtils.warning("No Periods are available with out topic select");
        }

    }
    @Test(description = "Verify view lesson is created and slides count",groups = {"regression_suite","create-tests"})
    public void VerifyViewLessonAfterLessonCreated(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify the view lesson is created and slides count");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
            createPage.createPageRefresh();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Validate slides count");
            Assert.assertTrue(createPage.getSlidesCount()== createPage.getTotalSlides(),"Slides count is not matched");
        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Validate slides count");
            Assert.assertTrue(createPage.getSlidesCount()== createPage.getTotalSlides(),"Slides count is not matched");
        }

    }
    //Test case is depricated, since the more action button is removed */
    @Test(description = "Verify more action option on view lesson page",groups = {"regression_suite","create-tests"})
    public void VerifyIsMoreActionOptionDisplayed(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();
        LoggerUtils.info("Verify more action option on view lesson page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();

        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
            createPage.createPageRefresh();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify more action option");
            Assert.assertTrue(createPage.isMoreActionOptionDisplayed(),"More action option is not displayed");

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify more action option");
            Assert.assertTrue(createPage.isMoreActionOptionDisplayed(),"More action option is not displayed");
        }

    }
    @Test(description = "Verify edit topic, edit lesson and delete lesson options",groups = {"regression_suite","create-tests"})
    public void VerifyEditTopicLessonAndDeleteLessonOptions(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify edit topic, edit lesson and delete lesson options");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
            createPage.createPageRefresh();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Validate edit topic, edit lesson and delete lesson options");
            Assert.assertTrue(createPage.getEditTopicText().equals("Edit Topic"),"Edit topic text is not matched");
            Assert.assertTrue(createPage.getEditLessonText().equals("Edit Lesson"),"Edit Lesson text is not matched");
            Assert.assertTrue(createPage.getDeleteLessonText().equals("Delete Lesson"),"Delete lesson is not matched");
        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Validate edit topic, edit lesson and delete lesson options");
            Assert.assertTrue(createPage.getEditTopicText().equals("Edit Topic"),"Edit topic text is not matched");
            Assert.assertTrue(createPage.getEditLessonText().equals("Edit Lesson"),"Edit Lesson text is not matched");
            Assert.assertTrue(createPage.getDeleteLessonText().equals("Delete Lesson"),"Delete lesson is not matched");
        }

    }

    @Test(description = "Verify Edit topic is working",groups = {"regression_suite","create-tests"})
    public void VerifyEditTopicIsWorking(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();
        LoggerUtils.info("Verify Edit topic is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
            createPage.createPageRefresh();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on edit Topic button");
            createPage.clickOnEditTopic();
            LoggerUtils.info("Validate edit topic popup text");
            Assert.assertTrue(createPage.getEditTopicPopupText().equals("If you edit/change Topics, your current Lesson will also get deleted"),"edit topic pop up text not matched");
            LoggerUtils.info("Click on Ok continue");
            createPage.clickOnOkContinueButton();
            LoggerUtils.info("Validate continue to create and change topic buttons");
            Assert.assertTrue(createPage.isContinueToEditLessonDisplayed(),"Continue to edit lesson is not displaying");
            Assert.assertTrue(createPage.isChangeTopicButtonDisplayed(),"Change topic button is not displaying");

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on edit Topic button");
            createPage.clickOnEditTopic();
            LoggerUtils.info("Validate edit topic popup text");
            Assert.assertTrue(createPage.getEditTopicPopupText().equals("If you edit/change Topics, your current Lesson will also get deleted"),"edit topic pop up text not matched");
            LoggerUtils.info("Click on Ok continue");
            createPage.clickOnOkContinueButton();
            LoggerUtils.info("Validate continue to create and change topic buttons");
            Assert.assertTrue(createPage.isContinueToEditLessonDisplayed(),"Continue to edit lesson is not displaying");
            Assert.assertTrue(createPage.isChangeTopicButtonDisplayed(),"Change topic button is not displaying");
        }

    }

    @Test(description = "Verify edit lesson is working",groups = {"regression_suite","create-tests"})
    public void VerifyEditLessonIsWorking(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();
        LoggerUtils.info("Verify edit lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
            createPage.createPageRefresh();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Verify Edit lesson option");
            createPage.editLesson();

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Verify Edit lesson option");
            createPage.editLesson();
        }

    }

    @Test(description = "Verify mark as complete and publish lesson buttons",groups = {"regression_suite","create-tests"})
    public void VerifyMarkAsCompleteAndPublishLesson(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify mark as complete and publish lesson buttons");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Click on back to period");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Refresh the page");
            createPage.clickSaveAndLeave();
            createPage.createPageRefresh();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify mark as complete option");
            createPage.clickOnMoreAction();
            Assert.assertTrue(createPage.getMarkAsCompletedText().equals("Mark Completed"),"Mark as complete text is not matched");
            LoggerUtils.info("Verify publish option");
            Assert.assertTrue(createPage.isPublishLessonButtonAvailable(),"Publish lesson is not available");

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            createPage.clickOnMoreAction();
           LoggerUtils.info("Verify mark as complete option");
          Assert.assertTrue(createPage.getMarkAsCompletedText().equals("Mark Completed"),"Mark as complete text is not matched");
            LoggerUtils.info("Verify publish option");
            Assert.assertTrue(createPage.isPublishLessonButtonAvailable(),"Publish lesson is not available");


        }

    }
 @Test(description = "Verify Delete lesson is working",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyDeleteLessonIsWorking(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
     createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
          //  createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click on Back to period");
            createPage.clickSaveAndLeave();
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            createPage.clickOnYesDeleteButton();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");
        }

    }
    @Test(description = "Verify New details verification",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyNewDetails(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
           // createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.deleteSlideOnPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.clickOnDuplicateSlide();
            LoggerUtils.info("Duplicated the  Slide added in the Page  ");





        }
        else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");
        }
    }
    @Test(description = "Verify New details verification",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyPageDetails(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
           // createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");



        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");
            createPage.clickOnYesDeleteButton();
        }

    }
    @Test(description = "Verify Recommended things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyRecommended(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
          //  createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.selectRecommendedAllVideo(2);
            //createPage.clickCreateButtonOnPage();

            createPage.addNewSlideToPage();
            createPage.clickOnRecommended();
            createPage.selectRecommendedImage(3);
            createPage.addNewSlideToPage();
            createPage.clickOnRecommended();

            createPage.selectRecommendedImage(2);


            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide added in the Page  ");

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }
    @Test(description = "Verify Templates things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyTemplates(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
          //  createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTemplates();
            createPage.selectLayoutTemplates(2);
            createPage.clickOnTemplates();
            createPage.addNewSlideToPage();
            createPage.selectLayoutTemplates(4);
            createPage.clickOnTemplates();

            createPage.addNewSlideToPage();
            createPage.chooseTemplateLayoutOptions(2);
            createPage.addNewSlideToPage();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }
    @Test(description = "Verify Text things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyText(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }
    @Test(description = "Verify Image things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyImage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
          //  createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnImageOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectRecommendedImage(0);
            createPage.addNewSlideToPage();
            createPage.addNewSlideToPage();
            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");


        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }
    @Test(description = "Verify Video things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyVideo(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
           // createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnVideoOfSlide();
            createPage.selectRecommendedImages(3);
            createPage.clickOnVideoOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickOnVideoOfSlide();
            createPage.selectRecommendedVideos(4);
            createPage.clickOnToggleDeleteButton();
            createPage.addNewSlideToPage();
            createPage.clickOnVideoOfSlide();
            createPage.selectRecommendedVideos(5);
            createPage.clickOnDuplicateSlide();
            createPage.addNewSlideToPage();
            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");


        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }
    @Test(description = "Verify 3DModel things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void Verify3DModel(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
          //  createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnThreeDModelOfSlide();
            LoggerUtils.info("select 3d model of slide  in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.addNewSlideToPage();
            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }
    @Test(description = "Verify Question things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyQuestion(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            //createPage.chooseChaptersFromTheList(1);
            createPage.createLesson();
            LoggerUtils.info("click on create lesson of  the page");
           // createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnQuestionOfSlide();
            LoggerUtils.info("Select  Question from Slide in the page");

            createPage.selectRecommendedQuestions(3);
            LoggerUtils.info("Select Value of Question in the page");

            createPage.clickAddButton();
            LoggerUtils.info("Add the  Question in the page");




            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");

        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");


        }

    }
    @Test(description = "Verify Extras things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyExtras(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("click on create Lesson ");
          //  createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info(" New Slide is created in the page");
            createPage.clickOnExtrasOfSlide();
            LoggerUtils.info("Click on Extras from side slides");

            createPage.selectExtrasOfExtraSlide(1);
            LoggerUtils.info("Selecting Extra Slide values");

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");








        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");


        }

    }
    //@Test(description = "Verify Image things ",groups = {"regression_suite","create-tests"},priority = 1)
    public void VerifyMeetLinkDetails(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        createPage = new CreatePage();

        LoggerUtils.info("Verify Delete lesson is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue( createPage.verifyCreatePageURL(Properties.baseUrl+"/create"),"Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods()>0){
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"),"Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
           // createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnImageOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectRecommendedImage(0);
            createPage.addNewSlideToPage();
            createPage.addNewSlideToPage();
            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");

            createPage.clickMeetLink();

            createPage.clickStartTeaching();






        }else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(),"Create lesson button is not displaying");

        }

    }


}


