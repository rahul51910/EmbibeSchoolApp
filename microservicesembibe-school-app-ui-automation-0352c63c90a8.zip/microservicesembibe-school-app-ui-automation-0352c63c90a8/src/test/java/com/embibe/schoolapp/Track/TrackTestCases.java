package com.embibe.schoolapp.Track;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.track.TrackPage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.List;

public class TrackTestCases extends TestBase {
    LoginPage loginPage = null;
    TrackPage TrackPage = null;

    @Test(description = "Verify Track Page ",groups = {"regression_suite","TrackTestCases"})
    public void verifyTrackPage(){
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Asserting the Track home page URL");
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/track"),"track page URL is not matched");
        Assert.assertTrue(TrackPage.isTrackIsPresent(),"Track button is present on Home page");

    }
    @Test(description = "Verify Track Class ",groups = {"regression_suite","TrackTestCases"})
    public void verifyTrackClasses(){
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Asserting the Track home page URL");
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/track"),"track page URL is not matched");


        LoggerUtils.info("Verify Average Mastery Improvement Section Is Present");
        TrackPage.verifyAllTheElementsOnTrackPage();
        TrackPage.onlyscroll();
        //due to name change in different environment
        //TrackPage.verifyLastData();
        LoggerUtils.info("Verify Mastery Improvement Page Details  ");
        //TrackPage.TrackPagetext();
        LoggerUtils.info("Verify All text Details on Page  ");

        TrackPage.clickOnSeeDetails(0);
        TrackPage.verifyMasteryImprovementModule();
        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Syllabus Covrage Section Page Details ");
        TrackPage.clickOnSeeDetails(1);
        TrackPage.verifySyllabusCoverageModule();
        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Score Improvement Section Page Details ");
        TrackPage.clickOnSeeDetails(2);
        TrackPage.verifyScoreImprovementModule();

        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Behavioural Improvement Section Page Details ");
        TrackPage.clickOnSeeDetails(3);
        TrackPage.verifyBehaviouralImprovementModule();

        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Class Participation Section Page Details ");
        TrackPage.clickOnSeeDetails(4);
        TrackPage.verifyClassParticipationModule();

        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Homework Completion Section Page Details ");
        TrackPage.clickOnSeeDetails(5);
        TrackPage.verifyHomeworkCompletionModule();
        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Learning Outcomes Achieved as per National Curriculum Framework Is Present ");
        TrackPage.clickOnLearningArrowButton();
        TrackPage.verifyLearningOutcomesAchievedasperNationalCurriculumFrameworkDetails();
        LoggerUtils.info("Verify Learning Outcomes Achieved as per National Curriculum Framework Is Details are Present");

        TrackPage.clickOnBackButton();
        TrackPage.scrollDown();
        LoggerUtils.info("Verify Teach Analysis Section Is Present ");
        TrackPage.clickOnTeachAnalysisButton();


        LoggerUtils.info("Verify Assign Analysis Section Is Present ");
        TrackPage.verifyTeachAnalysisDetails();
        TrackPage.clickOnTeachAnalysisButtonViewMore();
        LoggerUtils.info("View more link is working fine");
        TrackPage.clickOnBackButton();
        LoggerUtils.info("Verify Teach Analysis Details Section Is Present ");
        TrackPage.clickOnAssignAnalysisHomeworkButton();
        LoggerUtils.info("Verify Assign Analysis Test Section Is Present ");
        //TrackPage.verifyAssignAnalysisHomeworkDetails();
        LoggerUtils.info("verify Assign Analysis Homework Details Is Present ");
        TrackPage.clickOnAssignAnalysisTestButton();
        LoggerUtils.info("Verify StudentWise Analysis Section Is Present ");
        TrackPage.verifyAssignAnalysisTestDetails();
        LoggerUtils.info("verify Assign Analysis Test Details  Is Present ");
        TrackPage.clickOnStudentWiseAnalysisButton();
        LoggerUtils.info("Verify Attendance Analysis Section Is Present ");
        TrackPage.verifyStudentWiseAnalysisDetails();
        LoggerUtils.info("verify StudentWise Analysis Details Is Present ");
        TrackPage.clickOnOverallPerformanceButton();
        LoggerUtils.info("Verify Overall Performance Section Is Present ");
        TrackPage.clickOnLearningGapsViewMore();
        LoggerUtils.info("Verify Learning Gaps view more  Is Present ");
        TrackPage.clickOnBackButton();










    }
    @Test(description = "Verify Track Page Icon ",groups = {"regression_suite","TrackTestCases"})
    public void verifyTrackPageIcon() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Asserting the Track home page URL");
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/track"), "track page URL is not matched");
        TrackPage.verifyIconsOnTrackPage();
        LoggerUtils.info("All Track Page Icons are Present On Page ");
        TrackPage.clickOnSeeDetails(0);
        TrackPage.verifyMasteryImprovementPageIcons();
        LoggerUtils.info("All Mastery Improvement Icons are Present On Page ");
        TrackPage.clickOnBackButton();
        TrackPage.clickOnSeeDetails(2);
        TrackPage.verifyScoreImprovementPageIcons();
        LoggerUtils.info("All Score Improvement Icons are Present On Page ");
        TrackPage.clickOnBackButton();
        TrackPage.clickOnSeeDetails(3);
        TrackPage.verifyBehaviouralImprovementPageIcon();
        LoggerUtils.info("All Behavioural Improvement Icons are Present On Page ");
        TrackPage.clickOnBackButton();
        TrackPage.clickOnSeeDetails(4);
        TrackPage.verifyClassParticipationPageIcon();
        LoggerUtils.info("All Class Participation Icons are Present On Page ");
        TrackPage.clickOnBackButton();
        TrackPage.clickOnSeeDetails(5);
        TrackPage.verifyHomeworkCompletionPageIcon();
        LoggerUtils.info("All Homework Completion Icons are Present On Page ");
        TrackPage.clickOnBackButton();
        //TrackPage.verifyOverallLearningBehavioursImages();
        LoggerUtils.info("Overall Learning Behaviours Images are Present On Page ");






    }
    @Test(description = "Verify Track page My Profile ",groups = {"regression_suite","TrackTestCases"})
    public void verifyTrackPageMyprofile(){
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        TrackPage.clickuserName();
        TrackPage.verifyMyprofileUsername();
        TrackPage.clickOnmyProfile();
        LoggerUtils.info("verify on clicking My profile redirecting to my profile section");
    }
    @Test(description = "Verify calendar details ",groups = {"regression_suite","TrackTestCases"})
    public void verifyCalendar()  {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickOnClassToBeSelect(2);
        LoggerUtils.info("Track page class is been selected successfully  ");
        TrackPage.selectSectionData(1);
        LoggerUtils.info("Track page Section is been selected successfully  ");
        TrackPage.subjectData(1);
        LoggerUtils.info("Track page Subject is been selected Successfully  ");
        TrackPage.clickOnCalendarFilter();
        TrackPage.calendarDateRangeFilterOfTrack();
        LoggerUtils.info("Calender date selected ");


    }

    @Test(description = "Verify calendar details and Assign analysisTest ",groups = {"regression_suite","TrackTestCases"})
    public void verifyAssignAnalysisTestIndividualPageData(){
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName3,Properties.password3);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.selectClassData("10th CBSE");
        TrackPage.clickOnAssignAnalysisTestButton();
        //TrackPage.scrollDown();
        TrackPage.clickOnAnyTestNameofAssignTest(0);
        LoggerUtils.info("selected  10 cbsc  date filter  ");
        TrackPage.OverallTestAnalysisPageOfAssignTestAnalysis1();
        LoggerUtils.info("Overall Test Analysis Page Data is visible ");
        TrackPage.clickOnAvgClassScorePlusOfTestButton();
        LoggerUtils.info("Avg. Class Score'  Data is visible ");
        TrackPage.verifyAvgClassScoreText();

        TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        //TrackPage.clickOnTopSkillAnalysisPlusOfTestButton();
        LoggerUtils.info("Class Top Skill Analysis is visible ");
        TrackPage.verifyClassTopSkillAnalysisText();
        //TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        //TrackPage.clickOnAvgAttemptTypePlusButton();
        LoggerUtils.info("Avg. Attempt Type Analysis Data is visible ");
        //TrackPage.verifyAvgAttemptTypeAnalysisOverallText();

        //TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        TrackPage.clickOnAvgTimeSpentofClassPlusOfTestButton();
        LoggerUtils.info("Avg. Time Spent of Class  Data is visible ");
        TrackPage.verifyAvgTimeSpentofClassText();

        TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        //TrackPage.clickOnClassSincerityScorePlusButton();
        LoggerUtils.info("Class Sincerity Score Data is visible ");
        //TrackPage.verifyClassSincerityScoreText();

        //TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        //TrackPage.clickOnOverallStrongPlusButton();
        LoggerUtils.info("Overall Strong  is visible ");
        //TrackPage.verifyOverallStrongText();
        //TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        //TrackPage.clickOnOverallWeakPlusOfTestButton();
        LoggerUtils.info("Overall Weak   is visible ");
        //TrackPage.verifyOverallWeakText();
        //TrackPage.clickBackButton();
        LoggerUtils.info("click Back Button is visible ");
        TrackPage.scrollDownTill();

        TrackPage.clickOnStudentOfOverallAssignTest(0);
        TrackPage.clickOnTopSkillAnalysisPlusOfTestButton();
        LoggerUtils.info("Top Skill Analysis Data is visible ");
        TrackPage.verifyTopSkillAnalysisText();
        TrackPage.clickbackButton2();
        //TrackPage.clickOnQuestionWiseAnalysisPlusOfTestButton();
        LoggerUtils.info("QuestionWise Analysis Data is visible ");
       // TrackPage.verifyQuestionwiseAnalysisText();

       // TrackPage.clickbackButton2();
        LoggerUtils.info("click Back Button is visible ");
        TrackPage.clickOnAvgTimeSpentPlusOfTestButton();
        LoggerUtils.info("Avg. Time Spent  Data is visible ");
        TrackPage.verifyAverageTimeSpentText();

        TrackPage.clickbackButton2();
        LoggerUtils.info("click Back Button is visible ");
        TrackPage.clickOnSincerityScorePlusOfTestButton();
        LoggerUtils.info("Sincerity Score Data is visible ");
        TrackPage.verifySincerityScoreText();
        TrackPage.clickbackButton2();
        LoggerUtils.info("click Back Button is visible ");
        TrackPage.clickOnOverallStrongPlusOfSudentButton();
        LoggerUtils.info("Overall Strong   Data is visible ");
        TrackPage.verifyStrongTopicsAnalysisText();
        TrackPage.clickbackButton2();

        LoggerUtils.info("click back Button");
        TrackPage.clickOnOverallWeakOfSudentButton();
        LoggerUtils.info("Overall Weak  Data is visible ");
        TrackPage.verifyWeekTopicText();

        TrackPage.clickbackButton2();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnScorePlusOfTestButton();
        LoggerUtils.info("Score  Data is visible ");
        TrackPage.verifyAverageScoreText();
        TrackPage.clickbackButton2();
        LoggerUtils.info("click back Button");



    }
    @Test(description = "Verify calendar details and HomeworkAnalysis ",groups = {"regression_suite","TrackTestCases"})
    public void verifyAssignAnalysisHomeworkIndividualPageData() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName3,Properties.password3);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.selectClassData("12th CBSE");
        TrackPage.clickOnAssignAnalysisHomeworkButton();
        //TrackPage.scrollDown();
        //no assign test Present on screen
        TrackPage.clickOnAssignmentName(0);
        LoggerUtils.info("selected  12 cbsc  date filter  ");


        TrackPage.OverallHomeworkAnalysisClassPageOfAssignHomeworkAnalysis();
        LoggerUtils.info("Overall Test Analysis Page Data is visible ");






        TrackPage.clickOnAvgClassAccuracyPlusButton();
        LoggerUtils.info("Avg. Class Accuracy Data is visible ");
        TrackPage.verifyAvgClassAccuracyOverallHomeworkText();
        TrackPage.clickBackButton();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnAvgAttemptTypePlusButton();
        LoggerUtils.info("Avg. Attempt Type Analysis Data is visible ");
        TrackPage.verifyAvgAttemptTypeAnalysisOverallHomeworkText();
        TrackPage.clickBackButton();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnAvgTimeSpentOfClassPlusButton();
        LoggerUtils.info("Avg. Time Spent of Class Data is visible ");
        TrackPage.verifyAvgTimeSpentofClassHomeworkText();
        TrackPage.clickBackButton();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnClassSincerityScorePlusButton();
        LoggerUtils.info("Class Sincerity Score Data is visible ");
        TrackPage.verifyClassSincerityScoreOverallHomeworkText();
        TrackPage.clickBackButton();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnOverallStrongPlusButton();
        LoggerUtils.info("Overall Strong  Data is visible ");
        TrackPage.verifyOverallStrongOverallHomeworkText();
        TrackPage.clickBackButton();
        LoggerUtils.info("click back Button");

        TrackPage.clickOnOverallWeakPlusButton();
        LoggerUtils.info("Overall Weak  Data is visible ");
        TrackPage.verifyAOverallWeakOverallHomeworkText();
        TrackPage.clickBackButton();
        LoggerUtils.info("click back Button");
        TrackPage.scrollDown1();
        TrackPage.OverallHomeworkAnalysisClassPageOfAssignHomeworkAnalysisDownData();
        TrackPage.clickOnStudentNameOfHomework(0);
        LoggerUtils.info("click On Student Name Of Homework ");
        TrackPage.verifyStudentAssignedHomeworkData();
        LoggerUtils.info("verify Student Assigned Homework Data");
        TrackPage.clickOnQuestionWiseAnalysisOfStudentButton();
        LoggerUtils.info("QuestionWise Analysis is visible ");
        TrackPage.verifyQuestionWiseAnalysisHomeworkText();
        TrackPage.clickbackButton2();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnOverallWeakPlusOfTestButtonOfStudent();
        LoggerUtils.info("Overall Weak  Data is visible ");
        TrackPage.verifyAOverallWeakHomeworkText();
        TrackPage.clickbackButton2();
        LoggerUtils.info("click back Button");
        TrackPage.clickOnOverallStrongPlusOfTestButtonOfStudent();
        LoggerUtils.info("Overall Strong  Data is visible ");
        TrackPage.verifyAOverallStrongHomeworkText();
        TrackPage.clickbackButton2();
        LoggerUtils.info("click back Button");










    }

    @Test(description = "Verify Indiviual Teach Analysis ",groups = {"regression_suite","TrackTestCases"})
    public void verifyIndividualTeachAnalysisTab(){
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName3,Properties.password3);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Asserting the Track home page URL");
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/track"),"track page URL is not matched");
        LoggerUtils.info("Verify Teach Analysis Section Is Present ");
        TrackPage.clickOnTeachAnalysisButton();
        TrackPage.verifyTeachAnalysisDetails();
        TrackPage.clickOnTeachAnalysisButtonViewMore();
        LoggerUtils.info("View more link is working fine");
        TrackPage.individualTeachAnalysisTab();
        LoggerUtils.info("Verify Teach Analysis Details Section Is Present ");

        TrackPage.clickOnBackButton();
        LoggerUtils.info("click back Button");




    }
    @Test(description = "Verify Outcomes Panel and Effort Insights Data ",groups = {"regression_suite","TrackTestCases"})
    public void verifyOutcomesPanelAndEffortInsightsData() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickOnClassToBeSelect(1);
        LoggerUtils.info("Track page class is been selected successfully  ");
        TrackPage.selectSectionData(1);
        LoggerUtils.info("Track page Section is been selected successfully  ");
        TrackPage.subjectData(1);
        LoggerUtils.info("Track page Subject is been selected Successfully  ");
        TrackPage.clickOnCalendarFilter();
        TrackPage.calendarDateRangeFilterOfTrack();
        LoggerUtils.info("Calender date selected ");
        SchoolAppOps schoolAppOps = new SchoolAppOps();
        TrackPage.todaysDate();
        TrackPage.getYesterdayDateString();
        HashMap<String,String> hashMap = new HashMap<>();
        hashMap = schoolAppOps.getOutcomesPanel(TrackPage.getYesterdayDateString(),TrackPage.todaysDate());
        System.out.println(hashMap);
        //System.out.println(hashMap.get("Syllabus coverage"));
        //TrackPage.percentageValueData(0);
        Assert.assertEquals(hashMap.get("Mastery Improvement")+"%",TrackPage.percentageValueData(0));

        System.out.println("1st Expected value "+ TrackPage.percentageValueData(0));
        Assert.assertEquals(hashMap.get("Syllabus coverage")+"%",TrackPage.percentageValueData(1));
        System.out.println("2st Expected value "+ TrackPage.percentageValueData(1));
        Assert.assertEquals(hashMap.get("Score Improvement")+"%",TrackPage.percentageValueData(2));
        System.out.println("3st Expected value "+ TrackPage.percentageValueData(2));
        Assert.assertEquals(hashMap.get("Behavioural Improvement")+"%",TrackPage.percentageValueData(3));
        Assert.assertEquals(hashMap.get("Class Participation")+"%",TrackPage.percentageValueData(4));
        Assert.assertEquals(hashMap.get("Homework Completion")+"%",TrackPage.percentageValueData(5));


        HashMap<String,String> hashMap2 = new HashMap<>();
        hashMap2 = schoolAppOps.getOutcomesPanel2ndData(TrackPage.getYesterdayDateString(),TrackPage.todaysDate());
        System.out.println( TrackPage.percentageChangeValueData(0));
        Assert.assertEquals("+" +hashMap2.get("Mastery Improvement")+"%",TrackPage.percentageChangeValueData(0));
        Assert.assertEquals("+" +hashMap2.get("Syllabus coverage")+"%",TrackPage.percentageChangeValueData(1));
        Assert.assertEquals("+" +hashMap2.get("Score Improvement")+"%",TrackPage.percentageChangeValueData(2));
        Assert.assertEquals(hashMap2.get("Behavioural Improvement")+"%",TrackPage.percentageValueData(3));
        Assert.assertEquals(hashMap2.get("Class Participation")+"%",TrackPage.percentageValueData(4));
        Assert.assertEquals(hashMap2.get("Homework Completion")+"%","0."+TrackPage.percentageValueData(5));















    }
    @Test(description = "Verify Syllabus Coverage Graph",groups = {"regression_suite","TrackTestCases"})
    public void verifyApiSyllabusCoverageGraph() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickOnClassToBeSelect(2);
        LoggerUtils.info("Track page class is been selected successfully  ");
        TrackPage.selectSectionData(1);
        LoggerUtils.info("Track page Section is been selected successfully  ");
        TrackPage.subjectData(1);
        LoggerUtils.info("Track page Subject is been selected Successfully  ");
        TrackPage.clickOnCalendarFilter();
        TrackPage.calendarDateRangeFilterOfTrack();
        LoggerUtils.info("Calender date selected ");
        SchoolAppOps schoolAppOps = new SchoolAppOps();
        TrackPage.todaysDate();
        TrackPage.getYesterdayDateString();
        List<JSONObject> list = schoolAppOps.getSyllabusCoverage(TrackPage.getYesterdayDateString(),TrackPage.todaysDate());
        //System.out.println(list.get(0).get("planned"));
        //System.out.println(list.get(0).get("actual"));
        /*System.out.println(TrackPage.syllabusCoverageGraphData(0));
        System.out.println(TrackPage.syllabusCoverageGraphData(1));
        System.out.println(TrackPage.syllabusCoverageGraphData(2));
        System.out.println(TrackPage.syllabusCoverageGraphData(3));
        System.out.println(TrackPage.syllabusCoverageGraphData(4));*/
        //TrackPage.scrollDown2();

       // TrackPage.testdatademo();

    }
    @Test(description = "Verify Learning Gaps ",groups = {"regression_suite","TrackTestCases"})
    public void verifyApiLearningGaps() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickOnClassToBeSelect(2);
        LoggerUtils.info("Track page class is been selected successfully  ");
        TrackPage.selectSectionData(1);
        LoggerUtils.info("Track page Section is been selected successfully  ");
        TrackPage.subjectData(1);
        LoggerUtils.info("Track page Subject is been selected Successfully  ");
        TrackPage.clickOnCalendarFilter();
        TrackPage.calendarDateRangeFilterOfTrack();
        LoggerUtils.info("Calender date selected ");
        SchoolAppOps schoolAppOps = new SchoolAppOps();
        TrackPage.todaysDate();
        TrackPage.getYesterdayDateString();
        HashMap<String,String> hashMap = new HashMap<>();
       // hashMap = schoolAppOps.gettrackLearningGapsData(TrackPage.getYesterdayDateString(),TrackPage.todaysDate());
        //System.out.println(hashMap);


    }
    @Test(description = "Verify Teach Analysis Individual page data ",groups = {"regression_suite","TrackTestCases"})
    public void verifyApiTeachAnalysisIndividualPageData() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2,Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickOnClassToBeSelect(1);
        LoggerUtils.info("Track page class is been selected successfully  ");
        TrackPage.selectSectionData(1);
        LoggerUtils.info("Track page Section is been selected successfully  ");
        TrackPage.subjectData(1);
        LoggerUtils.info("Track page Subject is been selected Successfully  ");
        TrackPage.clickOnCalendarFilter();
        TrackPage.calendarDateRangeFilterOfTrack();
        LoggerUtils.info("Calender date selected ");
        SchoolAppOps schoolAppOps = new SchoolAppOps();
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/track"),"track page URL is not matched");
        LoggerUtils.info("Verify Teach Analysis Section Is Present ");
        TrackPage.clickOnTeachAnalysisButton();
        TrackPage.verifyTeachAnalysisDetails();
        List<JSONObject> list = schoolAppOps.getTeachAnalysisTabData(TrackPage.getYesterdayDateString(),TrackPage.todaysDate());
        //System.out.println(list);

    }
    @Test(description = "Verify Achive Analysis Tab of track page  ",groups = {"regression_suite","TrackTestCases"})
    public void verifyAchiveAnalysisTabData() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2, Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickAchieveAnalysisTabOfTrackPage();
        LoggerUtils.info("click Achieve Analysis Tab Of TrackPage");
        TrackPage.verifyAchieveAnalysisTabText();
        LoggerUtils.info("verify Achieve Analysis Tab Text Tab Of TrackPage");
        TrackPage.clickOnJourneyofJourneyName(0);
        LoggerUtils.info("click On Journey of Journey Names Of TrackPage");
        TrackPage.verifyAchieveAnalysisTabClassText();
        LoggerUtils.info("All text are been verified ");
        TrackPage.clickOnAnyStudentName(0);
        LoggerUtils.info("select student ");









    }
    @Test(description = "Verify Achive Analysis Tab of track page  ",groups = {"regression_suite","TrackTestCases"})
    public void verifyAchiveAnalysisTab() {
        loginPage = new LoginPage();
        TrackPage = new TrackPage();
        LoggerUtils.info("Verify track  page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName2, Properties.password2);
        TrackPage.clicktrackButton();
        LoggerUtils.info("Track page visible ");
        TrackPage.clickAchieveAnalysisTabOfTrackPage();
        LoggerUtils.info("click Achieve Analysis Tab Of TrackPage");
        TrackPage.verifyAchieveAnalysisTabText();
        LoggerUtils.info("verify Achieve Analysis Tab Text Tab Of TrackPage");










    }



}
