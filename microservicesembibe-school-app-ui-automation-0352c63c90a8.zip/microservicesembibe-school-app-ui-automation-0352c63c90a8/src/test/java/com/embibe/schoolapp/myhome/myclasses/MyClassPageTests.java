package com.embibe.schoolapp.myhome.myclasses;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.myhome.myclasses.MyClassesPage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Set;

public class MyClassPageTests extends TestBase {
    LoginPage loginPage = null;
    MyHomePage myHomePage = null;
    MyClassesPage myClassesPage = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();
    String jwtToken = null;

    @Test(description = "Verify my classes for teacher",groups = {"regression_suite","myHome_myClasses"})
    public void verifyTeacherClasses(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify my classes for teacher");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number class ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
    }

  // @Test(description = "Verify next slot for the class",groups = {"regression_suite","myHome_myClasses"})
    public void verifyClassNextSlot(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify next slot for the class");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            String subject = classInfo.get("subjectName").toString();
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("Getting Next slot details for "+cls);
            Map<String,Object> slotMap = schoolAppOps.verifyGetTeacherSubjectNextSlot(Embibetoken,cls,subject);
            LocalDateTime starTime = getLocalDateByEpoch(Long.valueOf(slotMap.get("startTime").toString()));
            String studentCount = myClassesPage.getStudentCount(subject);
            LoggerUtils.info("Asserting the Next class details for "+cls);
            Assert.assertTrue(myClassesPage.getNextClassDetails().toString()!=null, "Next class details are empty");
            LoggerUtils.info("Asserting student count for "+cls);
            Assert.assertTrue(studentCount.split(" ")[0].equals(classInfo.get("studentCount").toString()),"Student count is not matching");
            LoggerUtils.info("Verifying Pre class actions is displayed for "+cls);
            Assert.assertTrue(myClassesPage.preClassActionDisplayed(),"Pre class Actions are not displaying");
            LoggerUtils.info("Verifying post class actions is displayed for "+cls);
            Assert.assertTrue(myClassesPage.postClassActionDisplayed(),"Post class Actions are not displaying");
            LoggerUtils.info("Verifying coverage graphs displayed for "+cls);
            Assert.assertTrue(myClassesPage.coverageGraphDisplayed(),"coverage graphs are not displaying");
        }
    }

    @Test(description = "Verify Student count on Class",groups = {"regression_suite","myHome_myClasses"})
    public void verifyClassStudentCount(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify Student count on Class");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        System.out.println("The value of classlist is" +myClassesPage.getClassList());
        System.out.println("API With new response is "+schoolAppOps.getMyClassCount(Embibetoken));
        Assert.assertTrue(myClassesPage.getClassList()==schoolAppOps.getMyClassCount(Embibetoken),"number of classes are not matched . actual value from UI "+myClassesPage.getClassList() +" expected value from api "+myClassesMap.size());
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            String subject = classInfo.get("subjectName").toString();
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("Getting Next slot details for "+cls);
            //System.out.println("the data is "+schoolAppOps.verifyGetTeacherSubjectNextSlot(jwtToken,cls,subject));
            //Map<String,Object> slotMap = schoolAppOps.verifyGetTeacherSubjectNextSlot(jwtToken,cls,subject);
            //LocalDateTime starTime = getLocalDateByEpoch(Long.valueOf(slotMap.get("startTime").toString()));
            String studentCount = myClassesPage.getStudentCount(subject);
            LoggerUtils.info("Asserting student count for "+cls);
            Assert.assertTrue(studentCount.split(" ")[0].equals(classInfo.get("studentCount").toString()),"Student count is not matching");
        }
    }

    @Test(description = "Verify Pre Class Actions",groups = {"regression_suite","myHome_myClasses"})
    public void verifyPreClassActionsOnClass() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify Pre Class Actions on class");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String, Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList() == myClassesMap.size(), "number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls : classes) {
            Map<String, Object> classInfo = myClassesMap.get(cls);
            String subject = classInfo.get("subjectName").toString();
            LoggerUtils.info("Click on class " + cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("Getting Next slot details for " + cls);
            //Map<String, Object> slotMap = schoolAppOps.verifyGetTeacherSubjectNextSlot(jwtToken, cls, subject);
            //LocalDateTime starTime = getLocalDateByEpoch(Long.valueOf(slotMap.get("startTime").toString()));
            LoggerUtils.info("Verifying Pre class actions is displayed for " + cls);
            Assert.assertTrue(myClassesPage.preClassActionDisplayed(), "Pre class Actions are not displaying");

        }
    }
    @Test(description = "Verify Post class actions on class",groups = {"regression_suite","myHome_myClasses"})
    public void verifyPostClassActionOnClass(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify Post class actions on class");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            String subject = classInfo.get("subjectName").toString();
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("Getting Next slot details for "+cls);
            //Map<String,Object> slotMap = schoolAppOps.verifyGetTeacherSubjectNextSlot(jwtToken,cls,subject);
            //LocalDateTime starTime = getLocalDateByEpoch(Long.valueOf(slotMap.get("startTime").toString()));
            LoggerUtils.info("Verifying post class actions is displayed for "+cls);
            Assert.assertTrue(myClassesPage.postClassActionDisplayed(),"Post class Actions are not displaying");

        }
    }
    @Test(description = "Verify coverage of teacher",groups = {"regression_suite","myHome_myClasses"})
    public void verifyCoverageOnClass(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify coverage of teacher");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            String subject = classInfo.get("subjectName").toString();
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("Getting Next slot details for "+cls);
            //Map<String,Object> slotMap = schoolAppOps.verifyGetTeacherSubjectNextSlot(jwtToken,cls,subject);
            //LocalDateTime starTime = getLocalDateByEpoch(Long.valueOf(slotMap.get("startTime").toString()));
            LoggerUtils.info("Verifying coverage graphs displayed for "+cls);
            Assert.assertTrue(myClassesPage.coverageGraphDisplayed(),"coverage graphs are not displaying");
        }
    }
    @Test(description = "Verifying Add and delete books for teacher classes",groups = {"regression_suite","myHome_myClasses"})
    public void verifyAddDeleteBook(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        LoggerUtils.info("Verifying Add and delete books for teacher classes");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
//            Map<String,Object> classInfo = myClassesMap.get(cls);
//            String subject = classInfo.get("subjectName").toString();
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            LoggerUtils.info("Delete books if more than one");
            myClassesPage.scrollDown();
            if (myClassesPage.getBookListSize()>1){
                myClassesPage.deleteBook();
            }
            LoggerUtils.info("Click on add Books");
            myClassesPage.clickOnAddBooks();
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("Select and add book");
            myClassesPage.selectBook();
            myClassesPage.myClassesWait(2000);
            int bookCountBefore= myClassesPage.getBookListSize();
            LoggerUtils.info("Delete Books");
            myClassesPage.deleteBook();
//            int bookCountAfter = myClassesPage.getBookListSize();
//            Assert.assertTrue(bookCountBefore==bookCountAfter+1,"book count is not matched");
            break;
        }
    }

    //@Test(description = "Verify Attendance, track and mail to this group Icons",groups = {"regression_suite","myHome_myClasses"})
    public void verifyAttendanceMailTrackIconsDisplaying(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify Attendance, track and mail to this group Icons");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Verifying attendance Icon on My classes");
        Assert.assertTrue(myClassesPage.attendanceIconDisplayed(),"attendance icon is not displaying");
        LoggerUtils.info("Verifying Track Icon on My classes");
        Assert.assertTrue(myClassesPage.trackIconDisplayed(),"Track icon is not displaying");
        LoggerUtils.info("Verifying mail Icon  on My classes");
        Assert.assertTrue(myClassesPage.mailIconDisplayed(),"attendance icon is not displaying");
    }

    @Test(description = "Verify concept mastery is displaying",groups = {"regression_suite","myHome_myClasses"})
    public void verifyConceptMasteryIsDisplaying(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify concept mastery is displaying");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Verifying concept mastery");
        Assert.assertTrue(myClassesPage.conceptMasteryDisplayed(),"Concept mastery is not displaying");

    }

    //@Test(description = "Verify mail to this group button is working",groups = {"regression_suite","myHome_myClasses"})
    public void verifyMailtoThisGroupButtonWorking(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();

        LoggerUtils.info("Verify mail to this group button is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on mail to this group button");
        myClassesPage.clickOnMailToThisGroupButton();
        LoggerUtils.info("Verify user is navigated to Inbox page");
        Assert.assertTrue(myClassesPage.verifyPage("/inbox/compose/announcement"),"User is not navigated to Inbox page");
    }
    @Test(description = "Verify Books available to this class",groups = {"regression_suite","myHome_myClasses"})
    public void verifyBooksAvailableToThisClass(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        LoggerUtils.info("Verify mail to this group button is working");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Verify the books available to this class header is visible");
        Assert.assertTrue(myClassesPage.isBooksAvailableHeaderTextDisplayed(),"Books available to this class header is not displaying");
        LoggerUtils.info("Verify add books button is displaying");
        Assert.assertTrue(myClassesPage.isAddBookOptionIsDisplayed(),"Add books option is not displaying");
    }



}
