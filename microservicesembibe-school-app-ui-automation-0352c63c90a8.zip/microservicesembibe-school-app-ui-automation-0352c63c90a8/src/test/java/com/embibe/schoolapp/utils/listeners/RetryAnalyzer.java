package com.embibe.schoolapp.utils.listeners;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

public class RetryAnalyzer implements IRetryAnalyzer {
    int iterate = 0;
    int retryLimit = 2;

    @Override
    public boolean retry(ITestResult iTestResult) {
        if (iterate < retryLimit)
            try {
                iterate++;
                return true;
            } catch (Exception e) {

            }
        return false;
    }
}
