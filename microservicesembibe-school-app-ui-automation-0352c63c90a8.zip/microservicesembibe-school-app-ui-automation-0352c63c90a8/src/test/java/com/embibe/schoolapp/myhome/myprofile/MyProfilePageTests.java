package com.embibe.schoolapp.myhome.myprofile;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.myhome.myinbox.MyInboxPage;
import com.embibe.schoolapp.pages.myhome.myprofile.MyProfilePage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class MyProfilePageTests extends TestBase {
    LoginPage loginPage = null;
    MyHomePage myHomePage = null;
    MyProfilePage myProfilePage = null;
    String jwtToken = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();

    @Test(description = "Verify my Profile page ",groups = {"regression_suite","myHome_myProfile"})
    public void verifyMyProfilePage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myProfilePage = new MyProfilePage();
        jwtToken="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJsYXN0TmFtZSI6Ikt1bWFyICAiLCJ0aW1lX3N0YW1wIjoiMjAyMS0wOS0xMyAxMTozODo1MyBVVEMiLCJzdWJfb3JnYW5pemF0aW9uX2lkIjoxLCJtb2JpbGUiOiI5MDAwMDE3ODc5Iiwicm9vdE9yZ0lkIjoiNjBjMWUzZDEzMzVmNWE1ZDQ0NmY2YmNlIiwiZmlyc3ROYW1lIjoiUmFrZXNoIiwib3JnVHlwZSI6IlNjaG9vbCIsInBhcmVudE9yZ0lkIjoiNjBjMWU1NjkzMzVmNWE1ZDQ0NmY2YmQyIiwicGVyc29uYVR5cGUiOiJUZWFjaGVyIiwib3JnYW5pemF0aW9uX2lkIjoxLCJhZG1pbklkIjoiNjBjMjI5NDQ4NDdiZGE3ZTE0Mzk3YTE1IiwiaWQiOjE1MDAwNDUwMTIsImVtYWlsIjoicmFqZXNoa0BlbWJpYmUuY29tIn0.ZxTjNWbTT8WRTwVy6kMtg0pOweMh80rM8b9Aae7ksJlIi4QMniKvNH2tfjtRspeJ4HKwCEo0PMPCMDumLQ0P0A";
        LoggerUtils.info("Verify my Profile page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Profile module");
        myProfilePage.clickOnProfile();
        LoggerUtils.info("Verifying Profile page URL");
        Assert.assertTrue( myProfilePage.verifyProfilePageURL(Properties.baseUrl+"/school/home/profile"),"My inbox page url is not matched");
        Map<String,Object> personalDetails = schoolAppOps.getPersonalDetails(Embibetoken);
        LoggerUtils.info("Validating teacher personal details");
        Assert.assertTrue(myProfilePage.getEmail().equals(personalDetails.get("emailId").toString()),"email id is not matched");
        Assert.assertTrue(myProfilePage.getFullname().contains(personalDetails.get("firstName").toString()),"firstName is not matched");
        Assert.assertTrue(myProfilePage.getContactNumber().equals(personalDetails.get("mobileNumber").toString()),"mobileNumber id is not matched");
    }

    @Test(description = "Verify Edit my profile",groups = {"regression_suite","myHome_myProfile"})
    public void verifyEditMyProfile(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myProfilePage = new MyProfilePage();
        String college = "clg"+schoolAppOps.getEpochTimeInSec();
        LoggerUtils.info("Verify Edit my profile");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Profile module");
        myProfilePage.clickOnProfile();
        LoggerUtils.info("Verifying Profile page URL");
        Assert.assertTrue( myProfilePage.verifyProfilePageURL(Properties.baseUrl+"/school/home/profile"),"My inbox page url is not matched");
        LoggerUtils.info("click on edit profile");
        myProfilePage.clickOnEditProfile();
        LoggerUtils.info("set college");
        myProfilePage.setCollege(college);
        LoggerUtils.info("click on save changes");
        myProfilePage.clickOnSaveChanges();
        LoggerUtils.info("click on my Profile");
        myProfilePage.clickOnProfile();
        LoggerUtils.info("Assert college");
        Assert.assertTrue(myProfilePage.getQualification().contains(college),"college is not matched");
    }
    @Test(description = "Verify Teachers load",groups = {"regression_suite","myHome_myProfile"})
    public void verifyTeachersLoad(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myProfilePage = new MyProfilePage();
        LoggerUtils.info("Verify Teachers load");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Profile module");
        myProfilePage.clickOnProfile();
        LoggerUtils.info("Verifying Profile page URL");
        Assert.assertTrue( myProfilePage.verifyProfilePageURL(Properties.baseUrl+"/school/home/profile"),"My inbox page url is not matched");
        LoggerUtils.info("Assert load title");
        Assert.assertTrue(myProfilePage.getTeacherLoadTitle().equals("Teacher load per month"),"Teachers load title not matched");
    }
    @Test(description = "Verify Edit Profile page ",groups = {"regression_suite","myHome_myProfile"})
    public void verifyMyEditProfilePage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myProfilePage = new MyProfilePage();
        jwtToken="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJsYXN0TmFtZSI6Ikt1bWFyICAiLCJ0aW1lX3N0YW1wIjoiMjAyMS0wOS0xMyAxMTozODo1MyBVVEMiLCJzdWJfb3JnYW5pemF0aW9uX2lkIjoxLCJtb2JpbGUiOiI5MDAwMDE3ODc5Iiwicm9vdE9yZ0lkIjoiNjBjMWUzZDEzMzVmNWE1ZDQ0NmY2YmNlIiwiZmlyc3ROYW1lIjoiUmFrZXNoIiwib3JnVHlwZSI6IlNjaG9vbCIsInBhcmVudE9yZ0lkIjoiNjBjMWU1NjkzMzVmNWE1ZDQ0NmY2YmQyIiwicGVyc29uYVR5cGUiOiJUZWFjaGVyIiwib3JnYW5pemF0aW9uX2lkIjoxLCJhZG1pbklkIjoiNjBjMjI5NDQ4NDdiZGE3ZTE0Mzk3YTE1IiwiaWQiOjE1MDAwNDUwMTIsImVtYWlsIjoicmFqZXNoa0BlbWJpYmUuY29tIn0.ZxTjNWbTT8WRTwVy6kMtg0pOweMh80rM8b9Aae7ksJlIi4QMniKvNH2tfjtRspeJ4HKwCEo0PMPCMDumLQ0P0A";
        LoggerUtils.info("Verify my Profile page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on My Profile module");
        myProfilePage.clickOnProfile();
        LoggerUtils.info("Verifying Profile page URL");
        Assert.assertTrue( myProfilePage.verifyProfilePageURL(Properties.baseUrl+"/school/home/profile"),"My inbox page url is not matched");
        Map<String,Object> personalDetails = schoolAppOps.getPersonalDetails(Embibetoken);
        LoggerUtils.info("Validating teacher personal details");
        Assert.assertTrue(myProfilePage.getEmail().equals(personalDetails.get("emailId").toString()),"email id is not matched");
        Assert.assertTrue(myProfilePage.getFullname().contains(personalDetails.get("firstName").toString()),"firstName is not matched");
        Assert.assertTrue(myProfilePage.getContactNumber().equals(personalDetails.get("mobileNumber").toString()),"mobileNumber id is not matched");
        myProfilePage.clickOnEditProfile();

    }
}
