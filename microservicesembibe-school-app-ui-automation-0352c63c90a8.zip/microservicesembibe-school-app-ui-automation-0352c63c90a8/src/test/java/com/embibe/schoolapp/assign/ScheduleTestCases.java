package com.embibe.schoolapp.assign;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.assign.SchedulePage;
import com.embibe.schoolapp.pages.create.CreatePage;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;

import java.util.Set;


public class ScheduleTestCases extends TestBase {
    LoginPage loginPage = null;
    SchedulePage schedulePage = null;
    CreatePage createPage = null;
    MyHomePage myHomePage = null;
    SchoolAppOps schoolAppOps = null;

    @BeforeSuite
            public void resetCalender(){
        schoolAppOps = new SchoolAppOps();
        schoolAppOps.CalenderReset();
    }



    @Test(description = "Verify Assign Schedule Page ", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyAssignSchedulerPage() {
        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);

        schedulePage.clickOnAssign();
        LoggerUtils.info("Asserting the Assign home page URL");
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/assign"), "assign page URL is not matched");
        Assert.assertTrue(schedulePage.isAssignIsPresent(), "Assign button is present on Home page");
        Assert.assertTrue(schedulePage.isSchedule(), "Schedule tab is present on Assign page");
        schedulePage.AssignTabVerification();
        schedulePage.clickOnAssignHomework();
        schedulePage.clickAssignTestTab();
        schedulePage.clickOnScheduleTab();
        schedulePage.VerifyTextOfSchedulePage();
        LoggerUtils.info("Schedule Page texts");
        schedulePage.clickOnCalendarIcon();
        LoggerUtils.info("calender Icon is present and clickable ");






    }

    @Test(description = "Verify Set HomeWork Flow", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlow() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(1);
            LoggerUtils.info("select confirm of Topic Own From Set HomeWork");

            createPage.selectBook(1);
            LoggerUtils.info("Select Book from list");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            //createPage.OpenTheChoosePracticeContentOptions(0);
            createPage.chooseAnyOfPracticeContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            String homeworkname = createPage.randomName();
            createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Set Test flow ", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetTestFlow() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");


            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.ClickSetTest();
            LoggerUtils.info("Click to Set Test");

            createPage.clickEmbibePreset();
            LoggerUtils.info("Click to Embibe Preset");

            schedulePage.verifyTestData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();




            schedulePage.verifyReviewQuestionData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();




            schedulePage.verifyInstructionData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();


            createPage.clickAssignTestButton();
            LoggerUtils.info("click Assign Test Button Button is working ");

            createPage.clickDoneButton();
            LoggerUtils.info("click Done button ");

            schedulePage.clickAssignTestTab();


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Change Chapter Of Set Test flow ", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyChangeChapterOfSetTestFlow() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();

        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.clickOnTextOfSlide();
            LoggerUtils.info("Click on Text of slide  ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickTitle();
            LoggerUtils.info("Click on the Title of the Slide");

            createPage.TitleText();
            LoggerUtils.info("Enter Text in Title ");

            createPage.clickOnTextOfSlide();
            LoggerUtils.info("click on Text in Slide ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.selectformulasOfText();
            LoggerUtils.info("SELECT Formulas Of Slide ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickOnTextOfSlide();
            LoggerUtils.info("Enter Text in body ");

            createPage.clickBodyOfText();
            LoggerUtils.info("Click on the  body ");

            createPage.bodyOfText();
            LoggerUtils.info("Enter Text in body ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");


            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");

            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");

            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");

            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.ClickSetTest();
            LoggerUtils.info("Click to Set Test");

            createPage.clickEmbibePreset();
            LoggerUtils.info("Click to Embibe Preset");

            createPage.clickChangeChapterOfShowTest();
            LoggerUtils.info("click Change Chapter Of Show Test ");

            createPage.SelectChapterOfTheBook(3);
            LoggerUtils.info("Select Chapter Of The Book ");

            createPage.clickCancelButton();
            LoggerUtils.info("Click Cancel Button");

            createPage.clickChangeChapterOfShowTest();
            LoggerUtils.info("click Change Chapter Of Show Test ");

            createPage.SelectChapterOfTheBook(3);
            LoggerUtils.info("Select Chapter Of The Book ");


            createPage.clickSaveButton();
            LoggerUtils.info("Click on save  button");

            schedulePage.verifyTestData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();




            schedulePage.verifyReviewQuestionData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();




            schedulePage.verifyInstructionData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();









            createPage.clickAssignTestButton();
            LoggerUtils.info("click Assign Test Button Button is working ");

            createPage.clickDoneButton();
            LoggerUtils.info("click Done button ");

            schedulePage.clickAssignTestTab();
            LoggerUtils.info("click On Assign Test tab ");


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Show Chapter Of Set Test flow ", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyShowChapterOfSetTestFlow() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");

            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");

            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");

            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");

            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");

            createPage.createLesson();
            LoggerUtils.info("Refresh the page");

            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.clickOnTextOfSlide();
            LoggerUtils.info("click Text Ofn tab ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickTitle();
            LoggerUtils.info("click Title of slide ");

            createPage.TitleText();
            LoggerUtils.info("click On Title  Text tab ");

            createPage.clickOnTextOfSlide();
            LoggerUtils.info("click On Text of Slide  ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is added in page ");

            createPage.selectformulasOfText();
            LoggerUtils.info("Select Formulas of Text ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is added in page ");

            createPage.clickOnTextOfSlide();
            LoggerUtils.info("Click on Text of slide of a page ");

            createPage.clickBodyOfText();
            LoggerUtils.info("Click on Body of slide of a page ");

            createPage.bodyOfText();
            LoggerUtils.info("Enter Text in body ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is added in page ");

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.ClickSetTest();
            LoggerUtils.info("Click to Set Test");

            createPage.clickEmbibePreset();
            LoggerUtils.info("Click to Embibe Preset");


            createPage.chooseShowButtonOptions(1);
            LoggerUtils.info("Click to show button of chapter");
            createPage.SelectVideoOfChapter(2);
            LoggerUtils.info("Select video in show button of chapter");

            createPage.SelectVideoOfChapter(2);
            LoggerUtils.info("De-Select video in show button of chapter");

            createPage.SelectVideoOfChapter(3);
            LoggerUtils.info("Select video in show button of chapter");

            createPage.clickHideButton();
            LoggerUtils.info("Click On Hide Button");


            schedulePage.verifyTestData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();




            schedulePage.verifyReviewQuestionData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();




            schedulePage.verifyInstructionData();
            schedulePage.waiting();
            createPage.clickOnSaveAndContinue();





            createPage.clickAssignTestButton();
            LoggerUtils.info("click Assign Test Button Button is working ");


            createPage.clickDoneButton();
            LoggerUtils.info("click Done button ");

            schedulePage.clickAssignTestTab();
            LoggerUtils.info("click Assign Test Tab ");


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Details of Set Test flow ", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyDetailsSetTestFlow() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");

            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");

            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");

            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");

            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");

            createPage.createLesson();
            LoggerUtils.info("Refresh the page");

            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.clickOnTextOfSlide();

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickTitle();

            createPage.TitleText();

            createPage.clickOnTextOfSlide();

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.selectformulasOfText();

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickOnTextOfSlide();

            createPage.clickBodyOfText();

            createPage.bodyOfText();
            LoggerUtils.info("Enter Text in body ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");


            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.ClickSetTest();
            LoggerUtils.info("Click to Set Test");

            createPage.clickEmbibePreset();
            LoggerUtils.info("Click to Embibe Preset");

            schedulePage.verificationOfTextInShowingTestsAvailablePage();
            LoggerUtils.info("verification Of Text In Showing Tests Available Page");
            schedulePage.verifyIconOfShowingTestsAvailablePage();
            LoggerUtils.info("verification Icon Of Text In Showing Tests Available Page");


            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click on save and continue button");

            schedulePage.verifyReviewQuestionPageData();
            LoggerUtils.info("verify Review Question Page Data");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click on save and continue button");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click on save and continue button");

            schedulePage.verifyAssignTestPageData();
            LoggerUtils.info("verify Assign Test Page Data");

            createPage.clickAssignTestButton();
            LoggerUtils.info("click Assign Test Button Button is working ");

            createPage.clickDoneButton();
            LoggerUtils.info("click Done button ");

            schedulePage.clickAssignTestTab();
            LoggerUtils.info("click Assign Test tab ");


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Details of Assign Test Page", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyApiTeachAnalysisIndividualPageDataverifyDetailsOfAssignTestPage() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");

            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");

            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");

            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");

            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");

            createPage.createLesson();
            LoggerUtils.info("Refresh the page");

            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");

            createPage.clickOnTextOfSlide();

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickTitle();

            createPage.TitleText();

            createPage.clickOnTextOfSlide();

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.selectformulasOfText();

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");

            createPage.clickOnTextOfSlide();

            createPage.clickBodyOfText();

            createPage.bodyOfText();
            LoggerUtils.info("Enter Text in body ");

            createPage.addNewSlideToPage();
            LoggerUtils.info("New Slide is been added ");


            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.ClickSetTest();
            LoggerUtils.info("Click to Set Test");

            createPage.clickEmbibePreset();
            LoggerUtils.info("Click to Embibe Preset");

            schedulePage.verificationOfTextInShowingTestsAvailablePage();
            LoggerUtils.info("verification Of Text In Showing Tests Available Page");
            schedulePage.verifyIconOfShowingTestsAvailablePage();
            LoggerUtils.info("verification Icon Of Text In Showing Tests Available Page");


            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click on save and continue button");

            schedulePage.verifyReviewQuestionPageData();
            LoggerUtils.info("verify Review Question Page Data");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click on save and continue button");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click on save and continue button");

            schedulePage.verifyAssignTestPageData();
            LoggerUtils.info("verify Assign Test Page Data");

            createPage.clickAssignTestButton();
            LoggerUtils.info("click Assign Test Button Button is working ");

            createPage.clickDoneButton();
            LoggerUtils.info("click Done button ");

            schedulePage.clickAssignTestTab();
            LoggerUtils.info("click Assign Test tab ");

            schedulePage.verifyAssignTestPageDataTitle();
            LoggerUtils.info("Assign Page Title Verification");


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Set HomeWork Flow- For Only Topic Type  of Relations-Learning", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForOnlyTopicTypesOfRelationsCase1() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(0);
            LoggerUtils.info("select Only Topic: Types of Relations From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(0);
            LoggerUtils.info("Select Activity Option -Learning ");
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            /*createPage.OpenTheChoosePracticeContentOptions(0);
            LoggerUtils.info("Click and Open The Choose Practice Content Options ");*/

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");



            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.clickAssignHomeworkButton();


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Set HomeWork Flow- For Only Topic Type  of Relations-Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForOnlyTopicTypesOfRelationsCase2() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();

        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(0);
            LoggerUtils.info("select Only Topic: Types of Relations From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.isChangeSelectActivityDisplayed();
            LoggerUtils.info("Scroll Till Activity Displayed");


            createPage.chooseSelectActivityOptions(1);
            LoggerUtils.info("Select Activity Option -Practice ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            //createPage.OpenTheChoosePracticeContentOptions(0);


            createPage.chooseAnyOfPracticeContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");



            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            createPage.clickAssignHomeworkButton();
            LoggerUtils.info("Click Assign HomeWork Button");




        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Set HomeWork Flow- For Only Topic Type  of Relations-Learning & Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForOnlyTopicTypesOfRelationsCase3() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();

        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(0);
            LoggerUtils.info("select Only Topic: Types of Relations From Set HomeWork");

            createPage.selectBook(3);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(2);
            LoggerUtils.info("Select Activity Option -Learning & Practice ");


            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            //createPage.OpenTheChoosePracticeContentOptions(0);
            LoggerUtils.info("Click and Open The Choose Practice Content Options");

            createPage.chooseAnyOfPracticeContentOptions(2);

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");



            String homeworkname = createPage.randomName();

            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            createPage.clickAssignHomeworkButton();
            LoggerUtils.info("Click Assign Homework Button");


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }
    @Test(description = "Verify Set HomeWork Flow- For All 1 Topics covered so far in this Chapter: Relations and Functions-Learning", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForAll1TopicOfRelationsCase1() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();

        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(1);
            LoggerUtils.info("select Only Topic: All 1 Topics covered so far in this Chapter: Relations and Functions Set HomeWork");

            createPage.selectBook(3);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(0);
            LoggerUtils.info("Select Activity Option -Learning ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");


            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            createPage.clickAssignHomeworkButton();


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }
    @Test(description = "Verify Set HomeWork Flow- For All 1 Topics covered so far in this Chapter: Relations and Functions- Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForAll1TopicOfRelationsCase2() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(1);
            LoggerUtils.info("select Only Topic: All 1 Topics covered so far in this Chapter: Relations and Functions Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(1);
            LoggerUtils.info("Select Activity Option - Practice ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            //createPage.OpenTheChoosePracticeContentOptions(0);
            createPage.chooseAnyOfPracticeContentOptions(3);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            String homeworkname = createPage.randomName();

            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            createPage.clickAssignHomeworkButton();




        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }

    @Test(description = "Verify Set HomeWork Flow- All 1 Topics covered so far in this Chapter: Relations and Functions-Learning & Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForAll1TopicOfRelationsCase3() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(1);
            LoggerUtils.info("select Only Topic: All 1 Topics covered so far in this Chapter: Relations and Functions  From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(2);
            LoggerUtils.info("Select Activity Option -Learning & Practice ");


            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");


            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            //createPage.OpenTheChoosePracticeContentOptions(0);
            createPage.chooseAnyOfPracticeContentOptions(3);

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");


            String homeworkname = createPage.randomName();

            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            createPage.clickAssignHomeworkButton();
            LoggerUtils.info("Click Assign Homework Button");


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }
    @Test(description = "Verify Set HomeWork Flow- Whole Chapter: Relations and Functions: Relations and Functions-Learning & Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForWholeChapterOfRelationsCase1() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(2);
            LoggerUtils.info("select Only Topic: Whole Chapter: Relations and Functions  From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(0);
            LoggerUtils.info("Select Activity Option -Learning ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");



            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            createPage.clickAssignHomeworkButton();


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }
    @Test(description = "Verify Set HomeWork Flow- Whole Chapter: Relations and Functions: Relations and Functions-Learning & Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForWholeChapterOfRelationsCase2() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(2);
            LoggerUtils.info("select Only Topic: Whole Chapter: Relations and Functions  From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(1);
            LoggerUtils.info("Select Activity Option - Practice ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            //createPage.OpenTheChoosePracticeContentOptions(2);
            LoggerUtils.info("Click and Open The Choose Practice Content Options");



            createPage.chooseAnyOfPracticeContentOptions(3);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            createPage.clickAssignHomeworkButton();


        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }
    @Test(description = "Verify Set HomeWork Flow- Whole Chapter: Relations and Functions: Relations and Functions-Learning & Practice", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetHomeWorkFlowForWholeChapterOfRelationsCase3() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        if (createPage.getNoTopicsSelectedPeriods() > 0) {
            LoggerUtils.info("Click on no topic selected period");
            createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            //createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");
            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");
            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");

            createPage.chooseConfirmSyllabusOptions(2);
            LoggerUtils.info("select Only Topic: Whole Chapter: Relations and Functions  From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(2);
            LoggerUtils.info("Select Activity Option -Learning & Practice ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.OpenTheChoosePracticeContentOptions(2);
            LoggerUtils.info("Click to open Choose Practice Content Options");



            createPage.chooseAnyOfPracticeContentOptions(3);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");


            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");
            createPage.clickAssignHomeworkButton();
            LoggerUtils.info("Click Assign Homework Button");




        } else {
            LoggerUtils.info("Click on period");
            createPage.clickOnPeriod();
            LoggerUtils.info("Click on View lesson");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("click on more actions");
            createPage.clickOnMoreAction();
            LoggerUtils.info("Click on delete Lesson");
            createPage.clickOnDeleteLesson();
            LoggerUtils.info("Click on view lesson tab");
            createPage.clickOnViewLessonTab();
            Assert.assertTrue(createPage.isCreateLessonButtonDisplayed(), "Create lesson button is not displaying");

        }
    }
    @Test(description = "Verify Assign Schedule Page Periods Data ", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyAssignSchedulerPagePeriodsData() {
        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        schoolAppOps = new SchoolAppOps();
        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);

        schedulePage.clickOnAssign();
        /*LoggerUtils.info("Asserting the Assign home page URL");
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/assign"), "assign page URL is not matched");
        Assert.assertTrue(schedulePage.isAssignIsPresent(), "Assign button is present on Home page");
        Assert.assertTrue(schedulePage.isSchedule(), "Schedule tab is present on Assign page");
        schedulePage.AssignTabVerification();
        LoggerUtils.info("Assign tab data Verification");

        schedulePage.clickOnAssignHomework();
        LoggerUtils.info("Click on Assign Homework Tab");

        schedulePage.clickAssignTestTab();
        LoggerUtils.info("Click on AssignTest Tab");

        schedulePage.clickOnScheduleTab();
        LoggerUtils.info("Click on Schedule Tab");

        schedulePage.chooseCalendarOptions(0);
        LoggerUtils.info("Click on calender data");

        schedulePage.PrePostAssignTabVerification();
        LoggerUtils.info("Pre Post Assign Tab data Verification");

        schedulePage.clickTrackDetailedProgressLink();
        LoggerUtils.info("click Track Detailed Progress Link");*/
        schedulePage.firstAndLastDateOfTheYear();





    }
    @Test(description = "verify Student Side Details For Home`  n work", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyStudentSideDetailsForHomework() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");

        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        schedulePage.select10B(3);

            LoggerUtils.info("Click on no topic selected period");
            //createPage.clickOnNoTopicSelectedPeriod();
            LoggerUtils.info("Validate the topic name text");
            Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
            LoggerUtils.info("Click on View lesson tab");
            createPage.clickOnViewLessonTab();
            LoggerUtils.info("Verify  click on create lesson");
            createPage.clickOnCreateLesson();
            LoggerUtils.info("Add slides to lesson and save ");
            createPage.createLesson();
            LoggerUtils.info("Refresh the page");
            createPage.clickOnCreateBlankLesson();
            LoggerUtils.info("Click on Create Blank Page  ");

            createPage.detailsVerification();
            LoggerUtils.info("ALL Buttons and Details are  in the page");
            createPage.addNewSlideToPage();
            LoggerUtils.info("New Sile is created in the page");
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.clickTitle();
            createPage.TitleText();
            createPage.clickOnTextOfSlide();
            createPage.addNewSlideToPage();
            createPage.selectformulasOfText();
            createPage.addNewSlideToPage();
            createPage.clickOnTextOfSlide();
            createPage.clickBodyOfText();
            createPage.bodyOfText();
            createPage.addNewSlideToPage();

            createPage.selectPreview();
            LoggerUtils.info("preview Of Slide");

            createPage.selectMobileView();
            LoggerUtils.info("Mobile view of Slide");

            createPage.selectDesktopView();
            LoggerUtils.info("Desktop view of Slide");

            createPage.clickBackToSlide();
            LoggerUtils.info("Click back to Slide");

            createPage.clickOnSave();
            LoggerUtils.info("Click to save the  Slide");
            createPage.clickOnBackToPeriod();
            LoggerUtils.info("Click to Back button");

            createPage.clickSaveAndLeave();
            LoggerUtils.info("Click to Save And Leave");

            createPage.getAllPostClassActions();
            LoggerUtils.info("Click to Post and pre classes");

            createPage.clickSetHomework();
            LoggerUtils.info("Click to Set Homework");

            createPage.selectCreateYourOwnFromSetHomeWork();
            LoggerUtils.info("Click to Create Your Own From Set HomeWork");

            schedulePage.clickOnCreateYourOwnHomework();
            LoggerUtils.info("Click to Create Your Own From Set New HomeWork Screen ");


            createPage.chooseConfirmSyllabusOptions(0);
            LoggerUtils.info("select Only Topic: Types of Relations From Set HomeWork");

            createPage.selectBook(2);
            LoggerUtils.info("Select Book from list");

            createPage.chooseSelectActivityOptions(0);
            LoggerUtils.info("Select Activity Option -Learning ");

            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.chooseAnyOfLearnContentOptions(2);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");



            String homeworkname = createPage.randomName();
            createPage.selectAndEnterHomeworkName(homeworkname);
            createPage.clickOnSaveAndContinue();
            LoggerUtils.info("Click Save and Continue");

            createPage.clickAssignHomeworkButton();
            createPage.clickDoneButton();
            schedulePage.clickOnAssignHomeworkTab();

            //createPage.clickOnRandomNamefromAssignHomework(homeworkname);
            schedulePage.waitForSometime();
            schedulePage.clearCache();

            driver.navigate().to(Properties.baseUrlForStudent);
            LoggerUtils.info("Login with Email and Password");
            schedulePage.clickLoginButtonOfStudent();
            schedulePage.clickSignInButton();
            LoggerUtils.info("Click on SignIn With Password");

            schedulePage.selectAndEnterEmail();
            LoggerUtils.info("Enter Email ");

            schedulePage.selectPassword();
            schedulePage.clickSignInButtonOfStudent();

            schedulePage.clickHomePage();
            LoggerUtils.info("Click to HomePage ");

            schedulePage.clickmySchoolsOnStudentApp();

            schedulePage.clickMyAssignments();

            String assignmentName= createPage.verifyAssignmentName();
            System.out.println(assignmentName);

            Assert.assertEquals(homeworkname,assignmentName,"assignmentName Of Student Side and Teacher side are matching ");

            schedulePage.chooseAssignmentAndTestSelectionOptions(0);
            LoggerUtils.info("Select 1st Assignment ");

            schedulePage.clickAssignment();
            LoggerUtils.info("Click On Assignment  ");


            //schedulePage.clickCloseAssignmentWindow();
            LoggerUtils.info("Click to close window ");

            //schedulePage.clickcloseOfSlide();






    }
    @Test(description = "verify Set Adaptive Practice with Choose Other", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetAdaptivePracticeCase4() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        schedulePage.select10B(3);

        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.clickSetHomework();
        LoggerUtils.info("Click to Set Homework");

        createPage.selectCreateYourOwnFromSetHomeWork();
        LoggerUtils.info("Click to Create Your Own From Set HomeWork");
        schedulePage.clickSetAdaptivePractice();
        LoggerUtils.info("Click to set Adaptive Practice ");

        schedulePage.selectConfirmSyllabusOfSetAdaptivePracticeOption(3);
        LoggerUtils.info(" Select All 1 Topics covered so far in this Chapter: Relations and Functions");

        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");


        String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);
        createPage.clickSetAdaptivePracticeButton();
        LoggerUtils.info("click- Set Adaptive Practice Button");

    }
    @Test(description = "verify Set Adaptive Practice with All 1 Topics covered so far in this Chapter: Light : Reflection and Refraction", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetAdaptivePracticeCase1() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();

        schedulePage.select10B(3);



        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.clickSetHomework();
        LoggerUtils.info("Click to Set Homework");

        createPage.selectCreateYourOwnFromSetHomeWork();
        LoggerUtils.info("Click to Create Your Own From Set HomeWork");
        schedulePage.clickSetAdaptivePractice();
        LoggerUtils.info("Click to set Adaptive Practice ");

        schedulePage.selectConfirmSyllabusOfSetAdaptivePracticeOption(1);
        LoggerUtils.info(" Select All 1 Topics covered so far in this Chapter: Relations and Functions");

        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");


        String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);

        createPage.clickSetAdaptivePracticeButton();
        LoggerUtils.info("click- Set Adaptive Practice Button");

    }
    @Test(description = "verify Set Adaptive Practice with Only Topic: Introduction", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetAdaptivePracticeCase2() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();

        schedulePage.select10B(3);

        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.clickSetHomework();
        LoggerUtils.info("Click to Set Homework");

        createPage.selectCreateYourOwnFromSetHomeWork();
        LoggerUtils.info("Click to Create Your Own From Set HomeWork");
        schedulePage.clickSetAdaptivePractice();
        LoggerUtils.info("Click to set Adaptive Practice ");

        schedulePage.selectConfirmSyllabusOfSetAdaptivePracticeOption(0);
        LoggerUtils.info(" Select All 1 Topics covered so far in this Chapter: Relations and Functions");

        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");


        String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);
        createPage.clickSetAdaptivePracticeButton();
        LoggerUtils.info("click- Set Adaptive Practice Button");

    }
    @Test(description = "verify Set Adaptive Practice with Whole Chapter: Light : Reflection and Refraction", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetAdaptivePracticeCase3() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();
        schedulePage.select10B(3);

        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.clickSetHomework();
        LoggerUtils.info("Click to Set Homework");

        createPage.selectCreateYourOwnFromSetHomeWork();
        LoggerUtils.info("Click to Create Your Own From Set HomeWork");
        schedulePage.clickSetAdaptivePractice();
        LoggerUtils.info("Click to set Adaptive Practice ");

        schedulePage.selectConfirmSyllabusOfSetAdaptivePracticeOption(2);
        LoggerUtils.info(" Select All 1 Topics covered so far in this Chapter: Relations and Functions");

        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");


        String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);

        createPage.clickSetAdaptivePracticeButton();
        LoggerUtils.info("click- Set Adaptive Practice Button");

    }
    @Test(description = "verifySetAnAchieveJourney with Whole Chapter: Light : Reflection and Refraction", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetAnAchieveJourneyCase1() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();
        schedulePage.select10B(3);

        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.clickSetHomework();
        LoggerUtils.info("Click to Set Homework");

        createPage.selectCreateYourOwnFromSetHomeWork();
        LoggerUtils.info("Click to Create Your Own From Set HomeWork");
        schedulePage.clickSetAnAchieveJourney();
        LoggerUtils.info("Click to set An Achieve Journey ");

        schedulePage.selectConfirmSyllabusOfSetAnAchieveJourneyOption(0);
        LoggerUtils.info(" Select Whole Chapter: Light : Reflection and Refraction");

        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");


        String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);

        createPage.clickInitiateAchieveJourneyButton();
        LoggerUtils.info("click Initiate Achieve Journey Button");

    }
    @Test(description = "verifySetAnAchieveJourney with Choose Other", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifySetAnAchieveJourneyCase2() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");

        createPage.clickNextCalanderArrow();
        schedulePage.select10B(3);

        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.clickSetHomework();
        LoggerUtils.info("Click to Set Homework");

        createPage.selectCreateYourOwnFromSetHomeWork();
        LoggerUtils.info("Click to Create Your Own From Set HomeWork");
        schedulePage.clickSetAnAchieveJourney();
        LoggerUtils.info("Click to set An Achieve Journey ");

        schedulePage.selectConfirmSyllabusOfSetAnAchieveJourneyOption(1);
        LoggerUtils.info(" Select Choose Other");

        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");


        String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);
        LoggerUtils.info("Select and enter Random name ");

        createPage.clickInitiateAchieveJourneyButton();
        LoggerUtils.info("click Initiate Achieve Journey Button");

    }
    @Test(description = "verify Student Side Details For Home`  n work", groups = {"regression_suite", "assign_Schedule_Module"})
    public void verifyStudentSideDetailsForTest() {

        loginPage = new LoginPage();
        schedulePage = new SchedulePage();
        createPage = new CreatePage();
        myHomePage = new MyHomePage();

        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");

        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on My Create module");
        myHomePage.clickOnCreate();
        LoggerUtils.info("Verifying Create  page URL");
        Assert.assertTrue(createPage.verifyCreatePageURL(Properties.baseUrl + "/create"), "Lesson create url is not matched");
        LoggerUtils.info("Verify no topics selected periods are there");
        createPage.clickNextCalanderArrow();
        schedulePage.select10B(3);

        LoggerUtils.info("Click on no topic selected period");
        //createPage.clickOnNoTopicSelectedPeriod();
        LoggerUtils.info("Validate the topic name text");
        Assert.assertTrue(createPage.getTopicName().trim().equals("No topic available"), "Topic name text is not matched");
        LoggerUtils.info("Click on View lesson tab");
        createPage.clickOnViewLessonTab();
        LoggerUtils.info("Verify  click on create lesson");
        createPage.clickOnCreateLesson();
        LoggerUtils.info("Add slides to lesson and save ");
        createPage.createLesson();
        LoggerUtils.info("Refresh the page");
        createPage.clickOnCreateBlankLesson();
        LoggerUtils.info("Click on Create Blank Page  ");

        createPage.detailsVerification();
        LoggerUtils.info("ALL Buttons and Details are  in the page");
        createPage.addNewSlideToPage();
        LoggerUtils.info("New Sile is created in the page");
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.clickTitle();
        createPage.TitleText();
        createPage.clickOnTextOfSlide();
        createPage.addNewSlideToPage();
        createPage.selectformulasOfText();
        createPage.addNewSlideToPage();
        createPage.clickOnTextOfSlide();
        createPage.clickBodyOfText();
        createPage.bodyOfText();
        createPage.addNewSlideToPage();

        createPage.selectPreview();
        LoggerUtils.info("preview Of Slide");

        createPage.selectMobileView();
        LoggerUtils.info("Mobile view of Slide");

        createPage.selectDesktopView();
        LoggerUtils.info("Desktop view of Slide");

        createPage.clickBackToSlide();
        LoggerUtils.info("Click back to Slide");

        createPage.clickOnSave();
        LoggerUtils.info("Click to save the  Slide");
        createPage.clickOnBackToPeriod();
        LoggerUtils.info("Click to Back button");
        createPage.clickSaveAndLeave();
        LoggerUtils.info("Click to Save And Leave");
        createPage.getAllPostClassActions();
        LoggerUtils.info("Click to Post and pre classes");

        createPage.ClickSetTest();
        LoggerUtils.info("Click to Set Test");

        createPage.clickEmbibePreset();
        LoggerUtils.info("Click to Embibe Preset");

        schedulePage.verifyTestData();
        schedulePage.waiting();

        createPage.clickChangeChapterOfShowTest();
        LoggerUtils.info("click Change Chapter Of Show Test ");

        createPage.SelectChapterOfTheBook(3);
        LoggerUtils.info("Select Chapter Of The Book ");

        createPage.clickCancelButton();
        LoggerUtils.info("Click Cancel Button");

        createPage.clickChangeChapterOfShowTest();
        LoggerUtils.info("click Change Chapter Of Show Test ");


        createPage.SelectChapterOfTheBook(2);
        LoggerUtils.info("Select Chapter Of The Book ");


        createPage.clickSaveButton();
        LoggerUtils.info("Click on save  button");




        createPage.clickOnSaveAndContinue();




        schedulePage.verifyReviewQuestionData();
        schedulePage.waiting();
        createPage.clickOnSaveAndContinue();




        schedulePage.verifyInstructionData();
        schedulePage.waiting();
        createPage.clickOnSaveAndContinue();



        createPage.clickAssignTestButton();
        LoggerUtils.info("click Assign Test Button Button is working ");

        createPage.clickDoneButton();
        LoggerUtils.info("click Done button ");

        schedulePage.clickAssignTestTab();
        LoggerUtils.info("click On Assign Test tab ");


        /*String homeworkname = createPage.randomName();
        createPage.selectAndEnterHomeworkName(homeworkname);
        createPage.clickOnSaveAndContinue();
        LoggerUtils.info("Click Save and Continue");*/

        /*createPage.clickAssignHomeworkButton();
        createPage.clickDoneButton();
        schedulePage.clickOnAssignHomeworkTab();*/
        //createPage.clickOnRandomNamefromAssignHomework(homeworkname);
        schedulePage.waitForSometime();
        schedulePage.clearCache();
        driver.navigate().to(Properties.baseUrlForStudent);
        LoggerUtils.info("Login with Email and Password");
        schedulePage.clickLoginButtonOfStudent();
        schedulePage.clickSignInButton();
        LoggerUtils.info("Click on SignIn With Password");

        schedulePage.selectAndEnterEmail();
        LoggerUtils.info("Enter Email ");

        schedulePage.selectPassword();
        schedulePage.clickSignInButtonOfStudent();

        schedulePage.clickHomePage();
        LoggerUtils.info("Click to HomePage ");

        schedulePage.clickmySchoolsOnStudentApp();

        schedulePage.chooseAssignmentAndTestSelectionOptions(4);
        LoggerUtils.info("Select 1st Assignment ");

        schedulePage.clickAssignment();
        LoggerUtils.info("Click On Assignment  ");


        schedulePage.selectCheckboxIHaveReadAndUnderstoodTheInstructions();
        LoggerUtils.info("Click to understand checkbox  ");

        schedulePage.clickStartNow();
        LoggerUtils.info("Click to Start now button  ");







    }

    }









