package com.embibe.schoolapp.login;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginPageTests extends TestBase {

    LoginPage loginPage = null;
    MyHomePage myHomePage = null;

    @Test(description = "Verifying Login page fields",groups = {"regression_suite","login_tests"})
    public void verifyLoginPage(){
        loginPage = new LoginPage();
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Verifying Login page fields");
        Assert.assertTrue(loginPage.isEmailTextBoxDisplayed(),"Email text box is not there ");
        Assert.assertTrue(loginPage.isPasswordTextBoxDisplayed(),"Password text box is not there ");
        Assert.assertTrue(loginPage.isSignInButtonDisplayed(),"Sign in button is not there ");
        Assert.assertTrue(loginPage.isSignInWithGoogleAuthButtonDisplayed(),"Login with GoogleAuth button is not there ");
    }
    @Test(description = "Verifying teachers login",groups = {"regression_suite","login_tests"})
    public void verifyLogin(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        LoggerUtils.info("Verifying Login Page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        LoggerUtils.info(("Verify the Home page URL is matching"));
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
    }

}
