package com.embibe.schoolapp.myhome.attendance;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.myhome.attendance.AttendancePage;
import com.embibe.schoolapp.pages.myhome.myclasses.MyClassesPage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Test;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AttendancePageTests extends TestBase {
    LoginPage loginPage = null;
    MyHomePage myHomePage = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();
    MyClassesPage myClassesPage = null;
    AttendancePage attendancePage = null;

    String jwtToken = null;



    @Test(description = "Verify attendance page",groups = {"regression_suite","myHome_attendance"})
    public void verifyMyInboxPage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();
        LoggerUtils.info("Verify attendance page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on Attendance module");
        myClassesPage.clickOnAttendanceButton();
        LoggerUtils.info("Assert the attendance header is present");
        Assert.assertTrue(attendancePage.isAttendanceHeaderDisplaying(),"Attendance header is not showing");
    }
    @Test(description = "Verify tick attendance as present",groups = {"regression_suite","myHome_attendance"})
    public void verifyTickAttendanceAsPresent(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();

        LoggerUtils.info("Verify tick attendance as present");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on Attendance module");
        myClassesPage.clickOnAttendanceButton();
        LoggerUtils.info("Assert the attendance header is present");
        Assert.assertTrue(attendancePage.isAttendanceHeaderDisplaying(),"Attendance header is not showing");
        LoggerUtils.info("Verify Students present for the class");
        if (attendancePage.getStudentsCount()>0){
            LoggerUtils.info("Verify is attendance ticked as present");
            String value = attendancePage.getAttendanceStatus();
            System.out.println("the attendance satus "+value);
            if (!value.contains("active")){
                LoggerUtils.info("tick attendance as present");
                attendancePage.clickToPresent();
                LoggerUtils.info("validate attendance marked as present");
                Assert.assertTrue(attendancePage.getAttendanceStatus().contains("active"),"Attendance is not ticked as present");
            }else {
                LoggerUtils.info("tick attendance as absent");
                attendancePage.clickToAbsent();
                LoggerUtils.info("tick attendance as present");
                attendancePage.clickToPresent();
                LoggerUtils.info("validate attendance marked as present");
                Assert.assertTrue(attendancePage.getAttendanceStatus().contains("active"),"Attendance is not ticked as present");
            }
        }else {
            LoggerUtils.info("There is no students to tick present");
        }

    }
    @Test(description = "Verify tick attendance as absent",groups = {"regression_suite","myHome_attendance"})
    public void verifyTickAttendanceAsAbsent(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();

        LoggerUtils.info("Verify tick attendance as absent");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on Attendance module");
        myClassesPage.clickOnAttendanceButton();
        LoggerUtils.info("Assert the attendance header is present");
        Assert.assertTrue(attendancePage.isAttendanceHeaderDisplaying(),"Attendance header is not showing");
        LoggerUtils.info("Verify Students present for the class");
        if (attendancePage.getStudentsCount()>0){
            LoggerUtils.info("Verify is attendance ticked as present");
            String value = attendancePage.getAttendanceStatus();
            System.out.println("the attendance satus "+value);
            if (value.contains("active")){
                LoggerUtils.info("tick attendance as present");
                attendancePage.clickToAbsent();
                LoggerUtils.info("validate attendance marked as present");
                Assert.assertTrue(!attendancePage.getAttendanceStatus().contains("active"),"Attendance is not ticked as present");
            }else {
                LoggerUtils.info("tick attendance as Present");
                attendancePage.clickToPresent();
                LoggerUtils.info("tick attendance as absent");
                attendancePage.clickToAbsent();
                LoggerUtils.info("validate attendance marked as Absent");
                Assert.assertTrue(!attendancePage.getAttendanceStatus().contains("active"),"Attendance is not ticked as Absent");
            }
        }else {
            LoggerUtils.info("There is no students to tick Absent");
        }
    }

    @Test(description = "Verify Search Student in Attendance Page",groups = {"regression_suite","myHome_attendance"})
    public void verifySearchStudentInAttendancePage(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();

        LoggerUtils.info("Verify tick attendance as absent");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on Attendance module");
        myClassesPage.clickOnAttendanceButton();
        LoggerUtils.info("Assert the attendance header is present");
        Assert.assertTrue(attendancePage.isAttendanceHeaderDisplaying(),"Attendance header is not showing");
        LoggerUtils.info("Validating Search option in Attendance page");
        attendancePage.setSearchStudent("Studnet");
        LoggerUtils.info("Validate Search Student count based on search Key");
        Assert.assertTrue(attendancePage.getStudentsCount()==1,"Student count is not matched");
    }

    @Test(description = "Verify attendance percentage",groups = {"regression_suite","myHome_attendance"})
    public void verifyAttendancePercentages(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();

        LoggerUtils.info("Verify attendance percentage");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            int studentCount = Integer.parseInt(classInfo.get("studentCount").toString());
            if (studentCount>0){
                LoggerUtils.info("click on attendance button");
                myClassesPage.clickOnAttendanceButton();
//            Map<String,Object> teacherInfoMap = schoolAppOps.getTeacherIdAndSchoolId(jwtToken,cls);
//            List<String> percentageMap = schoolAppOps.getAttendancePercentage(jwtToken,teacherInfoMap.get("teacherId").toString(),teacherInfoMap.get("classOrgId").toString(),teacherInfoMap.get("subjectName").toString(),teacherInfoMap.get("schoolId").toString());
                List<String> percentageFromUi = attendancePage.getAttendancePercentageFromUI();
                LoggerUtils.info("validate Assert percentage");
                Assert.assertTrue(percentageFromUi.size()>0,"attendance percentage is not appearing");
                attendancePage.navigateBack();
            }else {
                LoggerUtils.info("there is no students for this class: "+cls);
            }

        }
    }

    @Test(description = "Verify attendance analytics",groups = {"regression_suite","myHome_attendance"})
    public void verifyAttendanceAnalytics(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();

        LoggerUtils.info("Verify attendance analytics");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            LoggerUtils.info("click on attendance button");
            myClassesPage.clickOnAttendanceButton();
            Map<String,Object> teacherInfoMap = schoolAppOps.getTeacherIdAndSchoolId(Embibetoken,cls);
            if (Integer.parseInt(teacherInfoMap.get("studentCount").toString())>0){
                Map<String,Integer> analyticsMap = schoolAppOps.getAttendanceAnalytics(jwtToken, teacherInfoMap.get("teacherId").toString(),teacherInfoMap.get("classOrgId").toString(),teacherInfoMap.get("subjectName").toString(),teacherInfoMap.get("schoolId").toString(),teacherInfoMap.get("subjectKveCode").toString());
              //  Assert.assertTrue(attendancePage.getAttendanceCount()!=null,"attendance total is not present" );
                Assert.assertTrue(attendancePage.getAttendancePercentage()!=null,"attendance percentage is not present" );
                Assert.assertTrue(Integer.parseInt(attendancePage.getPerfectAttendance())==analyticsMap.get("perfectAttendance"),"perfect attendance is not matched");
                Assert.assertTrue(Integer.parseInt(attendancePage.getBelowAvgAttendance())==analyticsMap.get("belowAvg"),"perfect attendance is not matched");
                Assert.assertTrue(attendancePage.getAvgAttendance()!=null,"Avg attendance is not showing");
                attendancePage.navigateBack();
            }else {
                LoggerUtils.info("There is not students for this class :"+cls);
            }

        }
    }
    @Test(description = "Verify attendance analytics",groups = {"regression_suite","myHome_attendance"})
    public void verifyStudentsData(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();
        LoggerUtils.info("Verify attendance analytics");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("getting my classes from backend");
        Map<String, Map<String,Object>> myClassesMap = schoolAppOps.getTeacherClasses(Embibetoken);
        LoggerUtils.info("Validating number classes ");
        Assert.assertTrue(myClassesPage.getClassList()==myClassesMap.size(),"number of classes are not matched");
        Set<String> classes = myClassesMap.keySet();
        for (String cls:classes) {
            Map<String,Object> classInfo = myClassesMap.get(cls);
            LoggerUtils.info("Click on class "+cls);
            myClassesPage.clickOnClassName(cls);
            myClassesPage.myClassesWait(2000);
            int studentCount = Integer.parseInt(classInfo.get("studentCount").toString());
            if (studentCount >0){
                LoggerUtils.info("click on attendance button");
                myClassesPage.clickOnAttendanceButton();
                LoggerUtils.info("Get student count from UI");
                int studentCountFromUi = attendancePage.getStudentsCount();
                System.out.println(studentCount+":"+studentCountFromUi);
                LoggerUtils.info("Assert student count");
                Assert.assertTrue(studentCountFromUi>0,"Student count is not matched");
                attendancePage.navigateBack();
            }else {
                LoggerUtils.info("There is no students for this class:"+cls);
            }

        }
    }
    @Test(description = "get reseller Jwt Token For ShowAPI",groups = {"regression_suite","myHome_attendance"})
    public void verifyNewFlow(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        myClassesPage = new MyClassesPage();
        attendancePage = new AttendancePage();

        schoolAppOps = new SchoolAppOps();
        LoggerUtils.info("Verify Assign Schedule page");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);


        System.out.println(schoolAppOps.getresellerJwtTokenForShowAPI());









    }

}
