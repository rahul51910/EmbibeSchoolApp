package com.embibe.schoolapp.myhome.myschedule;

import com.embibe.schoolapp.TestBase;
import com.embibe.schoolapp.pages.SchoolAppOps;
import com.embibe.schoolapp.pages.create.CreatePage;
import com.embibe.schoolapp.pages.login.LoginPage;
import com.embibe.schoolapp.pages.myhome.MyHomePage;
import com.embibe.schoolapp.pages.myhome.myschedule.MySchedulePage;
import com.embibe.schoolapp.utils.Properties;
import com.embibe.schoolapp.utils.logutils.LoggerUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Map;

public class MyScheduleTests extends TestBase {
    LoginPage loginPage = null;

    CreatePage createPage = null;
    MyHomePage myHomePage = null;
    MySchedulePage mySchedulePage = null;
    String jwtToken = null;
    SchoolAppOps schoolAppOps = new SchoolAppOps();
    @Test(description = "Verify calendar is opening",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyCalendarOnMySchedule(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify calendar is opening");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");
        LoggerUtils.info("Verifying Calendar Icon");
        Assert.assertTrue(mySchedulePage.isCalendarIconDisplaying(),"Calendar Icon is not displaying");
        LoggerUtils.info("Click on calendar icon");
        mySchedulePage.clickOnCalendar();
        LoggerUtils.info("Get Calendar header Text");
        String calHead = mySchedulePage.getCalendarHeaderText();
        System.out.println("cal head text "+calHead);
        LoggerUtils.info("Validating calendar header text");
        Assert.assertTrue(mySchedulePage.getCurrentMonth().toString().toLowerCase().contains(calHead.split(" ")[0].toLowerCase()),"Month is not matched");
        Assert.assertTrue(mySchedulePage.getCurrentYear()==Integer.parseInt(calHead.split(" ")[1]),"Year not matched");
    }
    //@Test(description = "Verify teacher timetable and periods",groups = {"regression_suite","myHome_mySchedule"})
    public void  verifyTeacherTimetableAndPeriods(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();

        LoggerUtils.info("Verify my classes for teacher");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");
        LoggerUtils.info("Get the teacher calendar info from backend ");
        Map<String,Object> timetableInfo = schoolAppOps.getTimeTableDataForTheCurrentWeek(jwtToken);
        LoggerUtils.info("Asserting the total timetable days for the week ");
//        Assert.assertTrue(Integer.parseInt(timetableInfo.get("timeTableDaysForWeek").toString())==mySchedulePage.getTimeTableDays(),"Total timetable day's are not matching");
        Assert.assertTrue(mySchedulePage.getTimeTableDays()==7,"Total timetable day's are not matching");
        LoggerUtils.info("Asserting the total Allotted periods");
//        Assert.assertTrue(Integer.parseInt(timetableInfo.get("totalAllottedPeriods").toString())==mySchedulePage.getTotalAllottedPeriods(),"Total allotted periods are not matching");
        Assert.assertTrue(mySchedulePage.getTotalAllottedPeriods()>1,"Allotted periods are not matched");
        LoggerUtils.info("Asserting total periods per day");
//        Assert.assertTrue(Integer.parseInt(timetableInfo.get("periodsPerDay").toString())==mySchedulePage.getTotalPeriodsPerDay(),"Total allotted periods are not matching");
        Assert.assertTrue(mySchedulePage.getTotalPeriodsPerDay()==10,"Total periods per day is not matching");
    }

    @Test(description = "Verify calendar next week",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyCalendarNextWeek(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify calendar next week");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");
        LoggerUtils.info("Click on calendar next week");
        mySchedulePage.clickOnCalendarNextButton();
        LoggerUtils.info("get next week day");
        int nextWeekday = mySchedulePage.getNextWeekDay();
        LoggerUtils.info("validate the next week calendar contains next week day ");
        Assert.assertTrue(mySchedulePage.isCalendarMovesToNextWeek(nextWeekday)==true,"calendar next week day is not matched");
    }


   // @Test(description = "Verify Today's periods for the teacher",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyTodayPeriods(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        createPage = new CreatePage();
        LoggerUtils.info("Verify Today's periods for the teacher");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");

        LoggerUtils.info("Click on any Active Period");

        mySchedulePage.clickOnAnyAllottedPeriod();
        LoggerUtils.info("Assert the today's periods");
        Map<String,Map<String,Object>> slotInfo = schoolAppOps.verifyTodayPeriods(jwtToken);
        Assert.assertTrue(mySchedulePage.getTodayPeriodsCount() == slotInfo.size(),"Today Periods count is not matched");
    }

    @Test(description = "Verify Today's periods for the teacher",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyClickOnPeriod(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify Today's periods for the teacher");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");
        LoggerUtils.info("Click on any Active Period");
        mySchedulePage.clickOnAnyAllottedPeriod();
        LoggerUtils.info("Verifying navigating teaching page");
        Assert.assertTrue(mySchedulePage.verifyNavigateToTeachPage("teach"),"User is not navigated to teach");
        LoggerUtils.info("Click on pre and post actions tab");
        mySchedulePage.clickOnPreAndPostActionsTab();
        LoggerUtils.info("Asserting Pre and post class actions are visible");
        Assert.assertTrue(mySchedulePage.postClassActionsAreDisplaying(),"Post class actions are not displaying");
        Assert.assertTrue(mySchedulePage.preClassActionsAreDisplaying(),"Pre calss actions are not displaying");
    }
    @Test(description = "Verify class type is updating",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyUpdateClassType(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify class type is updating");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");
        LoggerUtils.info("Verify update class Type");
        Assert.assertTrue(mySchedulePage.isActionUpdated(),"Action is not updated");

    }

    @Test(description = "Verify classes appearing on classes ",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyClassesAppearingOnPeriods(){
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify classes appearing on classes");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl+"/login");
        LoggerUtils.info("Login with Email and Password");
       loginPage.login(Properties.userName,Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl+"/school/home"),"Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        Assert.assertTrue(mySchedulePage.verifySchedulePageURL(Properties.baseUrl+"/school/home/schedule"),"My schedule page URL is not matched");
        LoggerUtils.info("Verify classes on periods");
        Assert.assertTrue(mySchedulePage.isClassesAppearOnPeriods(),"classes are not appearing");

    }
    @Test(description = "Verify classes  ",groups = {"regression_suite","myHome_mySchedule"})
    public void verifyClasses() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify classes appearing on classes");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        mySchedulePage.clickOnClassesDropdown();
        LoggerUtils.info("Click on classes ");

        mySchedulePage.selectClasses(1);
        LoggerUtils.info("Click on classes to be select  ");



    }
    @Test(description = "Verify subject  ",groups = {"regression_suite","myHome_mySchedule"})
    public void verifySubject() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify classes appearing on classes");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");

        mySchedulePage.clicksubjects();

        mySchedulePage.selectSubjects(0);

    }

    @Test(description = "verify Subject And classes Data ",groups = {"regression_suite","myHome_mySchedule"})
    public void verifySubjectAndclassesData() {
        loginPage = new LoginPage();
        myHomePage = new MyHomePage();
        mySchedulePage = new MySchedulePage();
        LoggerUtils.info("Verify classes appearing on classes");
        LoggerUtils.info("Opening School APP Base URL");
        openUrl(Properties.baseUrl + "/login");
        LoggerUtils.info("Login with Email and Password");
        loginPage.login(Properties.userName, Properties.password);
        Assert.assertTrue(loginPage.verifyPage(Properties.baseUrl + "/school/home"), "Home page URL is not matched");
        LoggerUtils.info("Click on MySchedule module");
        mySchedulePage.clickOnMySchedule();
        LoggerUtils.info("Validating my schedule ");
        mySchedulePage.clickOnClassesDropdown();
        LoggerUtils.info("Click on classes ");

        mySchedulePage.selectClasses(1);
        LoggerUtils.info("Click on classes to be select  ");

        mySchedulePage.clicksubjects();

        mySchedulePage.selectSubjects(0);

    }






}
