
package com.embibe.schoolapp.api.show;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ShowHelper {

    @SerializedName("treeLevel")
    @Expose
    private Integer treeLevel;
    @SerializedName("orgStep")
    @Expose
    private Integer orgStep;
    @SerializedName("userStep")
    @Expose
    private Integer userStep;
    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("testAppSubOrganizationId")
    @Expose
    private Integer testAppSubOrganizationId;
    @SerializedName("parentOrganizationId")
    @Expose
    private String parentOrganizationId;
    @SerializedName("rootOrganizationId")
    @Expose
    private String rootOrganizationId;
    @SerializedName("adminId")
    @Expose
    private String adminId;
    @SerializedName("idbmsOrgType")
    @Expose
    private String idbmsOrgType;
    @SerializedName("orgProfileCompletionPercentage")
    @Expose
    private Double orgProfileCompletionPercentage;
    @SerializedName("personalDetails")
    @Expose
    private PersonalDetails personalDetails;
    @SerializedName("loginOptions")
    @Expose
    private LoginOptions loginOptions;
    @SerializedName("orgDetails")
    @Expose
    private OrgDetails orgDetails;
    @SerializedName("classDetails")
    @Expose
    private List<ClassDetail> classDetails = null;
    @SerializedName("subjects")
    @Expose
    private List<String> subjects = null;

    public Integer getTreeLevel() {
        return treeLevel;
    }

    public void setTreeLevel(Integer treeLevel) {
        this.treeLevel = treeLevel;
    }

    public Integer getOrgStep() {
        return orgStep;
    }

    public void setOrgStep(Integer orgStep) {
        this.orgStep = orgStep;
    }

    public Integer getUserStep() {
        return userStep;
    }

    public void setUserStep(Integer userStep) {
        this.userStep = userStep;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getTestAppSubOrganizationId() {
        return testAppSubOrganizationId;
    }

    public void setTestAppSubOrganizationId(Integer testAppSubOrganizationId) {
        this.testAppSubOrganizationId = testAppSubOrganizationId;
    }

    public String getParentOrganizationId() {
        return parentOrganizationId;
    }

    public void setParentOrganizationId(String parentOrganizationId) {
        this.parentOrganizationId = parentOrganizationId;
    }

    public String getRootOrganizationId() {
        return rootOrganizationId;
    }

    public void setRootOrganizationId(String rootOrganizationId) {
        this.rootOrganizationId = rootOrganizationId;
    }

    public String getAdminId() {
        return adminId;
    }

    public void setAdminId(String adminId) {
        this.adminId = adminId;
    }

    public String getIdbmsOrgType() {
        return idbmsOrgType;
    }

    public void setIdbmsOrgType(String idbmsOrgType) {
        this.idbmsOrgType = idbmsOrgType;
    }

    public Double getOrgProfileCompletionPercentage() {
        return orgProfileCompletionPercentage;
    }

    public void setOrgProfileCompletionPercentage(Double orgProfileCompletionPercentage) {
        this.orgProfileCompletionPercentage = orgProfileCompletionPercentage;
    }

    public PersonalDetails getPersonalDetails() {
        return personalDetails;
    }

    public void setPersonalDetails(PersonalDetails personalDetails) {
        this.personalDetails = personalDetails;
    }

    public LoginOptions getLoginOptions() {
        return loginOptions;
    }

    public void setLoginOptions(LoginOptions loginOptions) {
        this.loginOptions = loginOptions;
    }

    public OrgDetails getOrgDetails() {
        return orgDetails;
    }

    public void setOrgDetails(OrgDetails orgDetails) {
        this.orgDetails = orgDetails;
    }

    public List<ClassDetail> getClassDetails() {
        return classDetails;
    }

    public void setClassDetails(List<ClassDetail> classDetails) {
        this.classDetails = classDetails;
    }

    public List<String> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<String> subjects) {
        this.subjects = subjects;
    }

}
