package com.embibe.schoolapp.utils;

public class Properties {
    private static final PropertiesReader propertiesReader = new PropertiesReader();
    public static final String baseUrl = propertiesReader.getBaseUrl();
    public static final String BROWSER_STACK_USERNAME = propertiesReader.getBrowserStackUsername();
    public static final String BROWSER_STACK_KEY = propertiesReader.getBrowserStackKey();
    public static final String showBasePath = propertiesReader.getShowBasePath();
    public static final String preProdBaseUrl = propertiesReader.getPreProdBaseUrl();
    public static final String teacherNextSlotBasePath = propertiesReader.getTeacherNextSlotBasePath();
    public static final String teacherCalendarBasePath = propertiesReader.getTeacherCalendarBasePath();
    public static final String todayPeriodsBasePath = propertiesReader.getTodayPeriodsBasePath();
    public static final String filesSharedBasePath = propertiesReader.getFilesSharedBasePath();
    public static final String inboxMessagesBasePath = propertiesReader.getInboxMessagesBasePath();
    public static final String userProfileBasePath = propertiesReader.getUserProfileBasePath();
    public static final String myStudentsBasePath = propertiesReader.getMyStudentsBasePath();
    public static final String attendanceRetrieveBasePath = propertiesReader.getAttendanceRetrieveBasePath();
    public static final String attendanceAnalyticsBasePath = propertiesReader.getAttendanceAnalyticsBasePath();
    public static final String userName=propertiesReader.getUserName();
    public static final String password= propertiesReader.getPassword();
    public static final String userName2= propertiesReader.getSecondUsername();
    public static final String password2= propertiesReader.getSecondPassword();

    public static final String userName3= propertiesReader.getThirdUsername();
    public static final String password3= propertiesReader.getThirdPassword();
    public static final String jwtResellerToken= propertiesReader.getResellerToken();
    public static final String schoolId= propertiesReader.getSchoolId();
    public static final String myClassesBasePath=propertiesReader.getMyClassBasePath();
    public static final String trackOverViewBasePath=propertiesReader.getTrackOverViewBasePath();
    public static final String classID = propertiesReader.getClassID();
    public static final String embibeToken = propertiesReader.getEmbibeToken();
    public static final String origin =propertiesReader.getOrigin();
    public static final String orgId = propertiesReader.getOrgId();
    public static final String kvCode = propertiesReader.getKvCode();
    public static final String locale = propertiesReader.getlocal();
    public static final String SyllabusCoverageBasePath = propertiesReader.gettrackSyllabusCoverageBasePath();
    public static final String LearningGapsBasePath = propertiesReader.gettrackLearningGapsBasePath();
    public static final String trackTeachAnalysisBasePath=propertiesReader.gettrackTeachAnalysisBasePath();
    public static final String trackTeachfilter=propertiesReader.getFilter();
    public static final String trackDataSize=propertiesReader.getSize();
    public static final String getOffset=propertiesReader.getOffset();
    public static final String trackTestAnalysisBasePath=propertiesReader.getTestAnalysisBasePath();
    public static final String trackStudentWiseAnalysisBasePath=propertiesReader.gettracleStudentWiseAnalysisBasePath();
    public static final String calenderUploadBasePath=propertiesReader.getCalenderUploadBasePath();
    public static final String resellerJWTTokenForCalender=propertiesReader.getResellerJWTTokenForCalender();
    public static final String baseUrlForStudent = propertiesReader.baseUrlForStudent();
    public static final String userNameOfStudent = propertiesReader.userNameOfStudent();
    public static final String passwordOfStudent = propertiesReader.passwordOfStudent();

    public static final String attendanceSearch = propertiesReader.attendanceSearch();

    public static final String availableOrg = propertiesReader.availableOrg();

    public static final String basePathOfUserAuth=propertiesReader.basePathOfUserAuth();

    public static final String device_id=propertiesReader.deviceId();

    public static final String assignAnalysisBasePath=propertiesReader.assignAnalysisBasePath();
}
