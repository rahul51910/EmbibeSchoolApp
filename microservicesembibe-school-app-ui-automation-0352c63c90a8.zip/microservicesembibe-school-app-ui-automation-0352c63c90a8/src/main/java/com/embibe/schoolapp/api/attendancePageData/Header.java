
package com.embibe.schoolapp.api.attendancePageData;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Header {

    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("label")
    @Expose
    private String label;
    @SerializedName("required")
    @Expose
    private Boolean required;
    @SerializedName("valueType")
    @Expose
    private String valueType;
    @SerializedName("visibility")
    @Expose
    private Boolean visibility;
    @SerializedName("isAggregatable")
    @Expose
    private Boolean isAggregatable;
    @SerializedName("editable")
    @Expose
    private Boolean editable;
    @SerializedName("isPreFilled")
    @Expose
    private Boolean isPreFilled;
    @SerializedName("rootAttribute")
    @Expose
    private Boolean rootAttribute;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public Boolean getRequired() {
        return required;
    }

    public void setRequired(Boolean required) {
        this.required = required;
    }

    public String getValueType() {
        return valueType;
    }

    public void setValueType(String valueType) {
        this.valueType = valueType;
    }

    public Boolean getVisibility() {
        return visibility;
    }

    public void setVisibility(Boolean visibility) {
        this.visibility = visibility;
    }

    public Boolean getIsAggregatable() {
        return isAggregatable;
    }

    public void setIsAggregatable(Boolean isAggregatable) {
        this.isAggregatable = isAggregatable;
    }

    public Boolean getEditable() {
        return editable;
    }

    public void setEditable(Boolean editable) {
        this.editable = editable;
    }

    public Boolean getIsPreFilled() {
        return isPreFilled;
    }

    public void setIsPreFilled(Boolean isPreFilled) {
        this.isPreFilled = isPreFilled;
    }

    public Boolean getRootAttribute() {
        return rootAttribute;
    }

    public void setRootAttribute(Boolean rootAttribute) {
        this.rootAttribute = rootAttribute;
    }

}
