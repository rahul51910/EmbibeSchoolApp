package com.embibe.schoolapp.pages.track;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class TrackPage extends BasePage {
    SoftAssert softAssert=null;

    public TrackPage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
        softAssert=new SoftAssert();
    }

    @FindBy(xpath = "//a[text()='Track']")
    private WebElement trackButton;

    @FindBy(xpath = "//a[text()='Average Mastery Improvement']")
    private WebElement averageMasteryImprovementpage;

    @FindBy(xpath = "//img[@class='back-icon']")
    private WebElement backNavigationButton;

    @FindBy(xpath = "//div[@class=\"input  \"]/div[1]")
    private WebElement trackClasses;

    @FindBy(xpath = "//div[text()='Mastery Improvement']/following-sibling::div/div[@class=\"value \"]")
    private WebElement masteryImprovementValue;

    @FindBy(xpath = "//div[text()='See details']")
    private List<WebElement> seeDetails;

    @FindBy(xpath = "//div[@class='value ']")
    private List<WebElement> percentageValue;

    @FindBy(xpath = "//div[@class='value-perc']")
    private List<WebElement> percentageChangeValue;

    @FindBy(xpath = "//div[text()='Average Mastery Improvement']")
    private WebElement averageMasteryImprovementSection;



    @FindBy(xpath = "(//div[contains(text(),'Syllabus Coverage')])[1]")
    private WebElement syllabusCovrageSection;

    @FindBy(xpath = "//div[text()='Syllabus Coverage']")
    private WebElement syllabusCoverageTrackPage;

    @FindBy(xpath = "//div[text()='Score Improvement']")
    private WebElement scoreImprovementSection;

    @FindBy(xpath = "//div[text()='Behavioural Improvement']")
    private WebElement behaviouralImprovementSection;

    @FindBy(xpath = "//div[text()='Class Participation']")
    private WebElement classParticipationSection;

    @FindBy(xpath = "//div[text()='Homework Completion']")
    private WebElement homeworkCompletionSection;

    @FindBy(xpath = "//section[text()='Learning Outcomes Achieved as per National Curriculum Framework']")
    private WebElement learingOutcomesValue;

    @FindBy(xpath = "//img[@class=\"right-arrow\"]")
    private WebElement learingOutcomesArror;

    @FindBy(xpath = "//section[@class='sc-pjUWf iGYXoE']//span[text()='View More Details']")
    private WebElement syllabusCoverageViewMore;

    @FindBy(xpath = "(//*[contains(text(),'View More Details')])[3]")
    private WebElement learningGapsViewMore;

    @FindBy(xpath = "//div[text()='Teach Analysis']")
    private WebElement teachAnalysisSection;

    @FindBy(xpath = "//*[contains(text(),'Overall Class Behaviour ')]")
    private WebElement overallClassBehaviourTryingHardText;

    @FindBy(xpath = "(//*[contains(text(),'IDK')])[2]")
    private WebElement inControlText;

    @FindBy(xpath = "//h1[text()='Marathon']")
    private WebElement marathonText;

    @FindBy(xpath = "//*[contains(text(),'Trying Hard')]")
    private WebElement tryingHarderText;


    @FindBy(xpath = "//div[text()='Assign Analysis - Homework']")
    private WebElement assignAnalysisHomeworkSection;


    @FindBy(xpath = "//div[text()='Assign Analysis - Test']")
    private WebElement assignAnalysisTestSection;

    @FindBy(xpath = "(//*[contains(text(),'Test Analysis')])[3]")
    private WebElement assigntesttext;

    @FindBy(xpath = "//div[text()='Student-wise Analysis']")
    private WebElement studentWiseAnalysisSection;

    @FindBy(xpath = "//div[text()='Attendance Analysis']")
    private WebElement attendanceAnalysisSection;

    @FindBy(xpath = "//div[text()='Overall Performance']")
    private WebElement overallPerformanceSection;

    @FindBy(xpath = "//div[text()='By Mastery till date']")
    private WebElement byMastertilldate;

    @FindBy(xpath = "//div[text()='By Topic']")
    private WebElement byTopic;

    @FindBy(xpath = "//div[text()='Student-wise Mastery']")
    private WebElement studentWiseMaster;

    @FindBy(xpath = "//div[text()='Mastery Improved']")
    private WebElement masteryImproved;

    @FindBy(xpath = "//div[text()='Mastery Dropped']")
    private WebElement masteryDropped;

    @FindBy(xpath = "//div[text()='Mastery Unchanged']")
    private WebElement masterUnchanged;

    @FindBy(xpath = "//div[text()='By Period Count till date']")
    private WebElement byPeriodCountTillDate;

    @FindBy(xpath = "//div[text()='By Periods Progress']")
    private WebElement byPeriodsProgress;

    @FindBy(xpath = "(//div[(text()='Syllabus Coverage')])[2]")
    private WebElement syllabusCoverage;

    @FindBy(xpath = "//div[text()='Average Score Improvement']")
    private WebElement averageScoreImprovementPage;

    @FindBy(xpath = "//div[text()='By Average Scores till date']")
    private WebElement byAverageScoreTillDate;

    @FindBy(xpath = "//div[text()='By Test']")
    private WebElement byTest;

    @FindBy(xpath = "//div[text()='Student-wise Score Improvement']")
    private WebElement studentWiseScoreImprovement;

    @FindBy(xpath = "//div[text()='Score Improved']")
    private WebElement scoreImprovement;

    @FindBy(xpath = "//div[text()='Score Dropped']")
    private WebElement scoreDropped;

    @FindBy(xpath = "//div[text()='Score Unchanged']")
    private WebElement scoreUnchanged;

    @FindBy(xpath = "//div[text()='Average Behavioural Improvement']")
    private  WebElement averageBehaviouralImprovement;

    @FindBy(xpath = "//*[contains(text(),'By Behaviour till date')]")
    private WebElement byBehaviourTillDate;

    @FindBy(xpath = "//div[text()='By Behaviour']")
    private WebElement byBehaviour;

    @FindBy(xpath = "//div[text()='Student-wise Behavioural Improvement']")
    private WebElement studentwiseBehaviouralImprovement;

    @FindBy(xpath = "//div[text()='Behaviour Improved']")
    private WebElement behaviorImproved;

    @FindBy(xpath = "//div[text()='Behaviour Dropped']")
    private WebElement behaviorDropped;

    @FindBy(xpath = "//div[text()='Behaviour Unchanged']")
    private WebElement behaviorUnchanged;

    @FindBy(xpath = "//div[text()='Average Class Participation']")
    private WebElement averageClassParticipation;

    @FindBy(xpath = "//div[text()='By Participation till date']")
    private WebElement byParticipationTillDate;

    @FindBy(xpath = "//div[text()='By Participation']")
    private WebElement byParticipation;

    @FindBy(xpath = "//div[text()='Student-wise Class Participation']")
    private WebElement studentWiseClassParticipation;

    @FindBy(xpath = "//div[text()='Participation Improved']")
    private WebElement participationImproved;

    @FindBy(xpath = "//div[text()='Participation Dropped']")
    private WebElement participationDropped;

    @FindBy(xpath = "//div[text()='Participation Unchanged']")
    private WebElement participationUnchanged;

    @FindBy(xpath = "//div[text()='Average Homework Completion']")
    private WebElement averageHomeworkCompletion;

    @FindBy(xpath = "//div[text()='By Completion till date']")
    private WebElement byCompletionTillDate;

    @FindBy(xpath = "//div[text()='By Completion']")
    private WebElement byCompletion;

    @FindBy(xpath = "//div[text()='Student-wise Homework Completion']")
    private WebElement studentWiseHomeworkCompletion;

    @FindBy(xpath = "//div[text()='Completion Improved']")
    private WebElement completionImproved;

    @FindBy(xpath = "//div[text()='Completion Dropped']")
    private WebElement completionDropped;

    @FindBy(xpath = "//div[text()='Completion Unchanged']")
    private WebElement completionUnchanged;

    @FindBy(xpath = "//*[contains(@src,'mastery_improvement.2a8bf18a.svg')]")
    private WebElement masterImprovementIcon;

    @FindBy(xpath = "//*[contains(@src,'syllabus_coverage.16d23a05.svg')]")
    private WebElement syllabusCoverageIcon;

    @FindBy(xpath = "//*[contains(@src,'score_improvement.c3b7c2f3.svg')]")
    private WebElement scoreImprovementSectionIcon;

    @FindBy(xpath = "//*[contains(@src,'behavioural_improvement.49e0ccbf.svg')]")
    private WebElement behaviouralImprovementSectionIcon;

    @FindBy(xpath = "//*[contains(@src,'class_participation.b08d8aab.svg')]")
    private WebElement classParticipationSectionIcon;

    @FindBy(xpath = "//*[contains(@src,'homework_completion.cec930ab.svg')]")
    private WebElement homeworkCompletionSectionIcon;

    @FindBy(xpath = "//*[contains(@src,'icon_lg_occured.a0e2e409.svg')]")
    private WebElement learningGapsOccurredIcon;

    @FindBy(xpath = "//*[contains(@src,'icon_lg_remediated.fa2a899a.svg')]")
    private WebElement learningGapsRemediatedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAIxJREFUGFdjZNgYd4GBgUEfiPGBBwz+ixQZiVTMwPCPyZERq3HrEwQYmP7tB8oZwOWxKkZR+P8jAwMjP1gDhmJ0hf+YHYA2nMdUjE1h4IILQD/9R1WMSyFIFYpifAoxFG+MawCK1TMwAD0DciPIamSAZrIB0BMNQN82YCiEmHwAaJABg/9iAezhjCMuAeb2UYRtYIdnAAAAAElFTkSuQmCC'])")
    private WebElement scoreImprovedIcon;

    @FindBy(xpath = "//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAJJJREFUGFeF0e0NQDAQBuC7WIBJsAEbWEQYRcIiJsAGXcV/yXlR0laLf70+7qssda1IRHgYcnI+aduYtq1BeMH9zMByGO57Nq2GEzFniI+4r7zYgStFUcFdp144BM/qZhtf0MIolWCYu8entDnHkxkbUXoYL7QzXymC0IfdVd/nGasrjzYUImlI6fgKHFsP8fMD7SYJXwwOE4SKAAAAAElFTkSuQmCC']")
    private WebElement scoreDroppedIcon;

    @FindBy(xpath = "//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAACCAYAAABsfz2XAAAABHNCSVQICAgIfAhkiAAAABlJREFUCFtj9LL7eoqBgcEUiIkBpxlJ1QAAhb8GkQozcmQAAAAASUVORK5CYII=']")
    private WebElement scoreUnchangedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAIxJREFUGFdjZNgYd4GBgUEfiPGBBwz+ixQZiVTMwPCPyZERq3HrEwQYmP7tB8oZwOWxKkZR+P8jAwMjP1gDhmJ0hf+YHYA2nMdUjE1h4IILQD/9R1WMSyFIFYpifAoxFG+MawCK1TMwAD0DciPIamSAZrIB0BMNQN82YCiEmHwAaJABg/9iAezhjCMuAeb2UYRtYIdnAAAAAElFTkSuQmCC'])[2]")
    private  WebElement masteryImprovedIcon;

    @FindBy(xpath = "//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAJJJREFUGFeF0e0NQDAQBuC7WIBJsAEbWEQYRcIiJsAGXcV/yXlR0laLf70+7qssda1IRHgYcnI+aduYtq1BeMH9zMByGO57Nq2GEzFniI+4r7zYgStFUcFdp144BM/qZhtf0MIolWCYu8entDnHkxkbUXoYL7QzXymC0IfdVd/nGasrjzYUImlI6fgKHFsP8fMD7SYJXwwOE4SKAAAAAElFTkSuQmCC']")
    private WebElement masteryDroppedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAACCAYAAABsfz2XAAAABHNCSVQICAgIfAhkiAAAABlJREFUCFtj9LL7eoqBgcEUiIkBpxlJ1QAAhb8GkQozcmQAAAAASUVORK5CYII='])")
    private WebElement masterUnchangedIcon;

    @FindBy(xpath = "(//img[@src='https://d34jbachbupkhk.cloudfront.net/track/static/media/behavioural_improvement.49e0ccbf.svg'])")
    private WebElement behaviouralImprovementIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAIxJREFUGFdjZNgYd4GBgUEfiPGBBwz+ixQZiVTMwPCPyZERq3HrEwQYmP7tB8oZwOWxKkZR+P8jAwMjP1gDhmJ0hf+YHYA2nMdUjE1h4IILQD/9R1WMSyFIFYpifAoxFG+MawCK1TMwAD0DciPIamSAZrIB0BMNQN82YCiEmHwAaJABg/9iAezhjCMuAeb2UYRtYIdnAAAAAElFTkSuQmCC'])[2]")
    private WebElement behaviourImprovedIcon;

    @FindBy(xpath = "//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAJJJREFUGFeF0e0NQDAQBuC7WIBJsAEbWEQYRcIiJsAGXcV/yXlR0laLf70+7qssda1IRHgYcnI+aduYtq1BeMH9zMByGO57Nq2GEzFniI+4r7zYgStFUcFdp144BM/qZhtf0MIolWCYu8entDnHkxkbUXoYL7QzXymC0IfdVd/nGasrjzYUImlI6fgKHFsP8fMD7SYJXwwOE4SKAAAAAElFTkSuQmCC']")
    private WebElement behaviourDroppedIcon;

    @FindBy(xpath = "//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAACCAYAAABsfz2XAAAABHNCSVQICAgIfAhkiAAAABlJREFUCFtj9LL7eoqBgcEUiIkBpxlJ1QAAhb8GkQozcmQAAAAASUVORK5CYII=']")
    private  WebElement behaviourUnchangedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAIxJREFUGFdjZNgYd4GBgUEfiPGBBwz+ixQZiVTMwPCPyZERq3HrEwQYmP7tB8oZwOWxKkZR+P8jAwMjP1gDhmJ0hf+YHYA2nMdUjE1h4IILQD/9R1WMSyFIFYpifAoxFG+MawCK1TMwAD0DciPIamSAZrIB0BMNQN82YCiEmHwAaJABg/9iAezhjCMuAeb2UYRtYIdnAAAAAElFTkSuQmCC'])[2]")
    private WebElement participationImprovedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAJJJREFUGFeF0e0NQDAQBuC7WIBJsAEbWEQYRcIiJsAGXcV/yXlR0laLf70+7qssda1IRHgYcnI+aduYtq1BeMH9zMByGO57Nq2GEzFniI+4r7zYgStFUcFdp144BM/qZhtf0MIolWCYu8entDnHkxkbUXoYL7QzXymC0IfdVd/nGasrjzYUImlI6fgKHFsP8fMD7SYJXwwOE4SKAAAAAElFTkSuQmCC'])")
    private  WebElement participationDroppedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAACCAYAAABsfz2XAAAABHNCSVQICAgIfAhkiAAAABlJREFUCFtj9LL7eoqBgcEUiIkBpxlJ1QAAhb8GkQozcmQAAAAASUVORK5CYII='])")
    private WebElement participationUnchangedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAIxJREFUGFdjZNgYd4GBgUEfiPGBBwz+ixQZiVTMwPCPyZERq3HrEwQYmP7tB8oZwOWxKkZR+P8jAwMjP1gDhmJ0hf+YHYA2nMdUjE1h4IILQD/9R1WMSyFIFYpifAoxFG+MawCK1TMwAD0DciPIamSAZrIB0BMNQN82YCiEmHwAaJABg/9iAezhjCMuAeb2UYRtYIdnAAAAAElFTkSuQmCC'])[3]")
    private WebElement completionImprovedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAsAAAALCAYAAACprHcmAAAABHNCSVQICAgIfAhkiAAAAJJJREFUGFeF0e0NQDAQBuC7WIBJsAEbWEQYRcIiJsAGXcV/yXlR0laLf70+7qssda1IRHgYcnI+aduYtq1BeMH9zMByGO57Nq2GEzFniI+4r7zYgStFUcFdp144BM/qZhtf0MIolWCYu8entDnHkxkbUXoYL7QzXymC0IfdVd/nGasrjzYUImlI6fgKHFsP8fMD7SYJXwwOE4SKAAAAAElFTkSuQmCC'])")
    private WebElement completionDroppedIcon;

    @FindBy(xpath = "(//img[@src='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAwAAAACCAYAAABsfz2XAAAABHNCSVQICAgIfAhkiAAAABlJREFUCFtj9LL7eoqBgcEUiIkBpxlJ1QAAhb8GkQozcmQAAAAASUVORK5CYII='])")
    private WebElement completionUnchangedIcon;

    @FindBy(xpath = "(//*[contains(@src,'5df2f62d-d326-4cab-90ef-63dfaa4a9e2f.gif')])[2]")
    private WebElement overallClassBehaviourTryingHardImage;

    @FindBy(xpath = "((//*[contains(@src,'31ead107-ee2d-4116-814f-7f92cc9851ae.gif')]))")
    private WebElement tryingHarderImage;

    @FindBy(xpath = "(//img[@src='https://d34jbachbupkhk.cloudfront.net/ekam/static/media/MARATHONER.5cf3bd48.png'])")
    private WebElement marathonImage;

    @FindBy(xpath = "(//img[@src='https://d34jbachbupkhk.cloudfront.net/ekam/static/media/IN_CONTROL.d756cd65.png'])")
    private WebElement inControlImage;

    @FindBy(xpath = "//div[text()='Outcomes Panel']")
    private WebElement outcomesPanel;

    @FindBy(xpath = "//div[text()='Effort Insights']")
    private WebElement effortInsights;

    @FindBy(xpath = "//div[text()='Topic Name']")
    private WebElement topicNameOfSyllabusCoverage;

    @FindBy(xpath = "//div[text()='Progress']")
    private WebElement progressOfSyllabusCoverage;

    @FindBy(xpath = "//div[text()='Avg Time Spent']")
    private WebElement avgTimeSpentOfSyllabusCoverage;

    @FindBy(xpath = "//div[text()='Avg Time Spent On Learn']")
    private WebElement avhTimeSpentOnLearnOfSyllabusCoverage;

    @FindBy(xpath = "//div[text()='Avg Time Spent On Practice']")
    private WebElement avgTimeSpentOnPracticeOfSyllabusCoverage;

    @FindBy(xpath = "//div[text()='Avg Time Spent On Test']")
    private WebElement avgTimeSpentOnTestOfSyllabusCoverage;

    @FindBy(xpath = "(//span[text()='View More Details'])[2]")
    private WebElement ViewMoreDetailsOfLearningGaps;

    @FindBy(xpath = "//span[text()='View More Details']")
    private  WebElement teachAnalysisSectionViewMoreDetails;

    @FindBys({@FindBy(xpath = "//*[contains(@class,'ellipsis padding-left-32')]")})
    private List<WebElement>  selectStudent;

    @FindBy(xpath = "(//*[contains(text(),'Weak Topics Analysis')])[1]")
    private WebElement WeakTopicsAnalysisText;

    @FindBy(xpath = "(//*[contains(text(),'Strong Topics Analysis')])[1]")
    private WebElement StrongTopicsAnalysisText;

    @FindBy(xpath = "(//*[contains(text(),'Sincerity Score')])[3]")
    private WebElement SincerityScoreText;

    @FindBy(xpath = "(//*[contains(text(),'Average Time Spent')])[1]")
    private WebElement AverageTimeSpentText;

    @FindBy(xpath = "(//*[contains(text(),'Question-wise Analysis')])")
    private WebElement QuestionwiseAnalysisText;

    @FindBy(xpath = "//*[text()='Average Score']")
    private WebElement AverageScoreText;

    @FindBy(xpath = "(//*[text()='Test Score'])[1]")
    private WebElement testScoreText;


    @FindBy(xpath = "(//*[contains(text(),'Top Skill Analysis')])[2]")
    private WebElement TopSkillAnalysisText;

    @FindBy(xpath = "(//*[contains(text(),'Question-wise Analysis')])")
    private WebElement AvgAttemptTypeAnalysisOverallText;

    @FindBy(xpath = "(//*[contains(text(),'Average Time Spent of Class')])")
    private WebElement AvgTimeSpentofClassText;

    @FindBy(xpath = "(//*[contains(text(),'Class Weak Topics Analysis')])")
    private WebElement OverallWeakText;

    @FindBy(xpath = "(//*[contains(text(),'Class Strong Topics Analysis')])")
    private WebElement OverallStrongText;

    @FindBy(xpath = "(//*[contains(text(),'Class Sincerity Score')])[2]")
    private WebElement ClassSincerityScoreText;

    @FindBy(xpath = "(//*[contains(text(),'Class Top Skill Analysis')])")
    private WebElement ClassTopSkillAnalysisText;

    @FindBy(xpath = "(//*[contains(text(),'Avg. Class Score')])[2]")
    private WebElement AvgClassScoreText;

    @FindBy(xpath = "//*[contains(text(),'Achieve Analysis')]")
    private WebElement achieveAnalysisTabOfTrackPage;












    @FindBy(xpath = "//div[@class='name']")
    private WebElement userName;

    @FindBy(xpath = "//div[text()='My Profile']")
    private WebElement myProfile;

    @FindBy(xpath = "//div[text()='Help and support']")
    private WebElement helpAndSupport;

    @FindBy(xpath = "//div[text()='Logout']")
    private WebElement logout;

    @FindBy(xpath = "//div[text()='Overall Learning Behaviours']")
    private WebElement overallLearningBehavioursText;

    @FindBy(xpath = "//span[text()='Test Name']")
    private WebElement testNameOfAssignAnalysisTest;

    @FindBy(xpath = "//span[text()='% Avg. Score']")
    private WebElement avgScoreOfAssignAnalysisTest;

    @FindBy(xpath = "//span[text()='Avg. Marks']")
    private WebElement avgMarksOfAssignAnalysisTest;

    @FindBy(xpath = "//span[text()='% Submission']")
    private WebElement submissionOfAssignAnalysisTest;

    @FindBy(xpath = "//span[text()='Test Type']")
    private WebElement testTypeOfAssignAnalysisTest;

    @FindBy(xpath = "//span[text()='Date']")
    private WebElement dateOfTeachAnalysis;

    @FindBy(xpath = "//span[text()='Period Count']")
    private WebElement periodCountOfTeachAnalysis;

    @FindBy(xpath = "//span[text()='Chapter Name']")
    private WebElement chapterNameOfTeachAnalysis;

    @FindBy(xpath = "//span[text()='Topic Name']")
    private WebElement topicNameOfTeachAnalysis;

    @FindBy(xpath = "//span[text()='Class Attendance']")
    private WebElement classAttendanceOfTeachAnalysis;

    @FindBy(xpath = "//span[text()='Class Participation']")
    private WebElement classParticipationOfTeachAnalysis;

    @FindBy(xpath = "//span[text()='Practice Questions In Class']")
    private  WebElement practiceQuestionInClassOfIndividualTeachAnalysis;

    @FindBy(xpath = "//span[text()='Vocal']")
    private WebElement vocalOfIndividualTeachAnalysis;

    @FindBy(xpath = "//span[text()='Attentive']")
    private  WebElement attentiveOfIndividualTeachAnalysis;

    @FindBys({@FindBy(xpath = "//div[@class='homework-name']")})
    private List<WebElement> selectAssignmentName;

    @FindBys({@FindBy(xpath = "//*[contains(@class,'custom-ellipsis padding-left-32')]")})
    private List<WebElement> studentName;



    @FindBy(xpath = "//span[text()='Practice Accuracy On Class Questions']")
    private WebElement practiceAccuracyOnClassQuestionsOfIndividualTeachAnalysis;

    @FindBy(xpath = "//span[text()='Assignment Name']")
    private WebElement assignmentNameOfHomework;

    @FindBy(xpath = "//span[text()='Due Date']")
    private WebElement dueDateOfHomework;

    @FindBy(xpath = "//span[text()='Avg. Accuracy']")
    private WebElement avgAccuracyOfHomework;

    @FindBy(xpath = "//span[text()='Submission']")
    private WebElement submissionOfHomework;

    @FindBy(xpath = "//span[text()='Homework Type']")
    private WebElement homeworkTypeOfHomework;

    @FindBy(xpath = "//span[text()='Student Name']")
    private WebElement studentNameOfStudentWiseAnalysis;

    @FindBy(xpath = "//span[text()='Class Rank']")
    private WebElement classRankOfStudentWiseAnalysis;

    @FindBy(xpath = "//span[text()='Performance']")
    private WebElement performanceOfStudentWiseAnalysis;

    @FindBy(xpath = "//span[text()='Videos Watched']")
    private WebElement videosWatchedOfStudentWiseAnalysis;

    @FindBy(xpath = "//span[text()='Questions Practiced']")
    private WebElement questionsPracticedOfStudentWiseAnalysis;

    @FindBy(xpath = "//span[text()='Total Time']")
    private WebElement totalTimeOfStudentWiseAnalysis;

    @FindBy(xpath = "//span[text()='% of Improvement']")
    private WebElement percentageOfImprovementOfStudentWiseAnalysis;

    @FindBy(xpath = "//div[text()='The most powerful education intelligence you will ever experience.']")
    private WebElement text1;

    @FindBy(xpath = "//div[text()='Improvement Insights in this period']")
    private WebElement text2;

    @FindBy(xpath = "(//div[text()='Students Improvement in this period'])[1]")
    private WebElement text3;

    @FindBy(xpath = "(//div[text()='Students Improvement in this period'])[2]")
    private WebElement text4;

    @FindBy(xpath = "(//div[text()='Students Improvement in this period'])[3]")
    private WebElement text5;

    @FindBy(xpath = "(//div[text()='Students Improvement in this period'])[4]")
    private WebElement text6;

    @FindBy(xpath = "(//div[text()='Students Improvement in this period'])[5]")
    private WebElement text7;

    @FindBy(xpath = "(//div[text()='Students Improvement in this period'])[6]")
    private WebElement text8;

    @FindBy(xpath = "(//div[text()='Overall Syllabus Coverage for 12th CBSE-A - Mathematics'])")
    private  WebElement text9;

    @FindBy(xpath = "(//div[text()='Learning Gaps Identified and Resolved for Class 12A in Mathematics'])")
    private WebElement text10;

    @FindBy(xpath = "//div[text()='Concept Mastery of Class 12A for Mathematics']")
    private WebElement text11;

    @FindBy(xpath = "//div[text()='Average Score of Class 12A for Tests Taken in Mathematics']")
    private WebElement text12;

    @FindBy(xpath ="//h3[text()='The students in your class are finding it difficult to succeed often, despite putting in a lot of effort.']")
    private WebElement text13;

    @FindBy(xpath = "//h3[text()='Students are putting the needed effort and succeeding often.']")
    private WebElement text14;

    @FindBy(xpath = "//h3[text()='Students have amazing stamina and can focus for a long duration at a stretch.']")
    private WebElement text15;

    @FindBy(xpath = "//h3[text()='Students are putting a lot of effort and still unable to succeed often.']")
    private WebElement text16;

    @FindBy(xpath = "//span[text()='List Of Outcomes']")
    private WebElement listOfOutcomesOnLearningOutcomesIndividually;

    @FindBy(xpath = "//span[text()='Total Student Outcomes']")
    private WebElement totalStudentOutcomesOnLearningOutcomesIndividually;

    @FindBy(xpath = "//*[contains(text(),'Total Time Spent')]")
    private WebElement avgTimeSpentOnLearningOutcomesIndividually;

    @FindBy(xpath = "//*[contains(text(),'%Time Spent on Learn')]")
    private WebElement avgTimeSpentOnLearnOnLearningOutcomesIndividually;

    @FindBy(xpath = "//*[contains(text(),'%Time Spent on Practice')]")
    private WebElement avgTimeSpentOnPracticeOnLearningOutcomesIndividually;

    @FindBy(xpath = "//*[contains(text(),'%Time Spent on Test')]")
    private WebElement avgTimeSpentOnTestOnLearningOutcomesIndividually;

    @FindBy(xpath = "//div[@class='date-range-wrapper']")
    private WebElement calenderdateRangeFilter;

    @FindBy(xpath = "//div[@class='drs-calendar right']")
    private WebElement rightCalendar;

    @FindBy(xpath = "(//div[@class='input  '])[1]")
    private WebElement classDropdown;

    /*@FindBy(xpath = "(//div[ text()='12th CBSE'])[2]")
    private WebElement classDropdownFilterSelect;*/

    @FindBys({@FindBy(xpath = "//div[@class='options']")})
    private List<WebElement> classDropdownFilterSelect;



    @FindBy(xpath = "(//div[@class='input  '])[2]")
    private WebElement sectionDropdown;

    @FindBys({@FindBy(xpath = "//div[@class='dropdown-options animate']//div[@class='options']")})
    private List<WebElement> sectionDropdownFilterSelect;

    @FindBy(xpath = "(//div[@class='input  '])[2]")
    private WebElement subjectDropdown;

    @FindBys({@FindBy(xpath = "//div[@class='dropdown-options animate']//div[@class='options']")})
    private List<WebElement> subjectDropdownFilterSelect;

    @FindBy(xpath = "//p[text()='Avg. Attempt Type Analysis']")
    private  WebElement avgAttemptTypeAnalysisOnOverallTestAnalysis;

    @FindBy(xpath = "//p[text()='Improve Score of Students']")
    private  WebElement improveScoreOfStudentsOnOverallTestAnalysis;

    @FindBy(xpath = "(//*[contains(text(),'Avg. Class Accuracy')])")
    private  WebElement avgClassScoreOnOverallTestAnalysis;

    @FindBy(xpath = "(//*[contains(text(),'Average Score')])")
    private WebElement averageScoreOnOverallTestAnalysis;

    @FindBy(xpath = "(//*[contains(text(),'Avg. Class Score')])")
    private WebElement avgClassScoreOnOverallTestAnalysis1;

    @FindBy(xpath = "//p[text()='Avg. Attempt Type Analysis']")
    private  WebElement AvgAttemptTypeAnalysisOnOverallTestAnalysis;

    @FindBy(xpath = "//p[text()='Class Top Skill Analysis']")
    private  WebElement classTopSkillAnalysisOnOverallTestAnalysis;

    @FindBy(xpath = "(//p[text()='Class Sincerity Score' ])[1]")
    private  WebElement classSincerityScorePOSITIVEBEHAVIOUROnOverallTestAnalysis;

    @FindBy(xpath = "(//p[text()='Class Sincerity Score' ])[2]")
    private  WebElement classSincerityScoreNEGATIVEBEHAVIOUROnOverallTestAnalysis;

    @FindBy(xpath = "//p[text()='Overall Strong ' ]")
    private  WebElement overallStrongOnOverallTestAnalysis;

    @FindBy(xpath = "//p[text()='Overall Weak ' ]")
    private  WebElement overallWeakOnOverallTestAnalysis;

    @FindBys({@FindBy(xpath = "//div[@class='custom-ellipsis']")})
    private List<WebElement> anyTestNameOfAssignAnalysisTest;

    @FindBy(xpath = "//p[text()='Avg. Time Spent of Class']")
    private WebElement avgTimeSpentofClassOnOverallTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'Student Name')]")
    private WebElement studentNameOnOverallTestAnalysis;

    @FindBy(xpath = "//span[text()='Average Score']")
    private WebElement averageScoreOnOverallTestAnalysis1;

    @FindBy(xpath = "(//*[contains(text(),'Performance')])[3]")
    private WebElement performanceOnOverallTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'% Homework Accuracy')]")
    private WebElement homeworkAccuracyOnOverallHomeworkAnalysisClass;

    @FindBy(xpath = "(//*[contains(text(),'Attempt Type')])[2]")
    private WebElement attemptTypeOnOverallHomeworkAnalysisClass;

    @FindBy(xpath = "//*[contains(text(),'Time Spent in minutes')]")
    private WebElement timespentInMinofOverallHomeworkAnalysisClass;

    @FindBy(xpath = "//span[text()='Time Spent']")
    private WebElement timeSpentOnOverallTestAnalysis;

    @FindBy(xpath = "//div[@class='dropdown-options animate']//div[@class='options']")
    private List<WebElement>  classSelection;

    @FindBy(xpath = "(//div[text()='Topic'])[1]")
    private WebElement topicOfSyllabusCoverage;

    @FindBy(xpath = "(//div[text()='Topic'])[2]")
    private WebElement firstTopicOfSyllabusCoverage;

    @FindBy(xpath = "(//div[text()='Chapter'])")
    private WebElement chapterOfSyllabusCoverage;

    @FindBy(xpath = "((//*[local-name()='svg' ])[15]/*[local-name()='g'][6]/*[local-name()='g'][2]/*[local-name()='path'])[2]")
    private WebElement syllabusCoverageGraphActual;

    @FindBy(xpath = "(//*[local-name()='svg' ])[15]/*[local-name()='g'][6]/*[local-name()='g'][4]/*[local-name()='path']")
    private List<WebElement> syllabusCoverageGraphPlanned;

    @FindBy(xpath = "//*[contains(text(),'Current Score')]")
    private WebElement currentScoreOfTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'Potential Score')]")
    private WebElement potentialScoreOfTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'QuestionWise Analysis')]")
    private WebElement questionWiseAnalysisOfTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'Top Skill Analysis')]")
    private WebElement topSkillAnalysisOfTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'Avg. Time Spent')]")
    private WebElement avgTimeSpendOfTestAnalysis;

    @FindBy(xpath = "(//*[contains(text(),'Sincerity Score')])[1]")
    private WebElement sincerityScorePositiveOfTestAnalysis;

    @FindBy(xpath = "(//*[contains(text(),'Sincerity Score')])[2]")
    private WebElement sincerityScoreNegativeOfTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'Overall Strong ')]")
    private WebElement overallStrongOfTestAnalysis;

    @FindBy(xpath = "//*[contains(text(),'Overall Weak ')]")
    private WebElement overallWeakOfTestAnalysis;

    @FindBy(xpath = "//p[text()='Score']")
    private WebElement scoreOfTestAnalysis;

    @FindBy(xpath = "//*[name()='tspan' and contains(@x,'0')]")
    private List<WebElement> plusButton;

    @FindBy(xpath = "(//*[contains(text(),'Homework Analysis')])[3]")
    private WebElement homeworkAnalysisText;

    @FindBy(xpath = "//*[contains(text(),'Accuracy')]")
    private WebElement accuracyofStudent;

    @FindBy(xpath = "//*[contains(text(),'Top Skill Analysis')]")
    private WebElement topskillOfStudent;

    @FindBy(xpath = "(//*[contains(text(),'Sincerity Score')])[1]")
    private WebElement sincerityscorepositiveOfStudent;

    @FindBy(xpath ="(//*[contains(text(),'Sincerity Score')])[2]")
    private WebElement sincerityscorenegativeOfStudent;

    @FindBy(xpath = "//*[contains(text(),'Overall Strong ')]")
    private WebElement overallStrongOfStudent;

    @FindBy(xpath = "//*[contains(text(),'Overall Weak ')]")
    private WebElement overallWeakOfStudent;

    @FindBy(xpath = "//*[contains(text(),'Avg. Time Spent')]")
    private WebElement avgTimeSpentOfStudent;

    @FindBy(xpath = "//*[contains(text(),'QuestionWise Analysis')]")
    private WebElement questionWiseAnalysisOfStudent;

    @FindBy(xpath = "//*[contains(text(),'can achieve a higher grade')]")
    private WebElement textOfStudent;

    @FindBy(xpath = "//img[@alt='backarrow']")
    private WebElement backbutton;

    @FindBy(xpath = "(//img[@alt='backarrow'])[2]")
    private WebElement backbutton2;

    @FindBy(xpath = "//*[contains(text(),'Avg. Class Accuracy')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgClassAccuracyPlusButton;

    @FindBy(xpath = "//*[contains(text(),'Avg. Attempt Type Analysis')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgAttemptTypePlusButton;

    @FindBy(xpath = "//*[contains(text(),'Avg. Time Spent of Class')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgTimeSpentOfClassPlusButton;

    @FindBy(xpath = "//*[contains(text(),'Class Sincerity Score')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement ClassSincerityScorePlusButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Strong ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallStrongPlusButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Weak ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallWeakPlusButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Strong ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallStrongPlusOfSudentButton;

    @FindBy(xpath = "//*[contains(text(),'QuestionWise Analysis')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement QuestionWiseAnalysisOfStudentButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Weak ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallWeakOfSudentButton;

    @FindBy(xpath = "//*[contains(text(),'Avg. Class Score')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgClassScorePlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Avg. Time Spent of Class')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgTimeSpentofClassPlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Avg. Attempt Type Analysis')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgAttemptTypeAnalysisPlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Class Sincerity Score')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement ClassSincerityScorePlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Strong ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallStrongPlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Weak ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallWeakPlusOfTestButton;

    @FindBy(xpath = "(//*[contains(text(),'Score')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')])[1]")
    private WebElement ScorePlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'QuestionWise Analysis')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement QuestionWiseAnalysisPlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Top Skill Analysis')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement TopSkillAnalysisPlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Sincerity Score')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement SincerityScorePlusOfTestButton;

    @FindBy(xpath = "//*[contains(text(),'Overall Strong ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallStrongPlusOfTestButtonOfStudent;

    @FindBy(xpath = "//*[contains(text(),'Overall Weak ')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement OverallWeakPlusOfTestButtonOfStudent;

    @FindBy(xpath = "//*[contains(text(),'Avg. Time Spent')]//parent::div/following-sibling::div//*[name()='tspan' and contains(text(),'+')]")
    private WebElement AvgTimeSpentPlusOfTestButton;

    @FindBy(xpath = "(//*[text()='Avg. Class Accuracy'])[2]")
    private WebElement AvgClassAccuracyOverallHomeworkText;

    @FindBy(xpath = "(//*[text()='Question-wise Analysis'])")
    private WebElement AvgAttemptTypeAnalysisOverallHomeworkText;

    @FindBy(xpath = "(//*[text()='Average Time Spent of Class'])")
    private WebElement AvgTimeSpentofClassHomeworkText;

    @FindBy(xpath = "(//*[text()='Class Sincerity Score'])[3]")
    private WebElement ClassSincerityScoreOverallHomeworkText;

    @FindBy(xpath = "(//*[text()='Class Strong Topics Analysis'])")
    private WebElement OverallStrongOverallHomeworkText;

    @FindBy(xpath = "(//*[text()='Class Weak Topics Analysis'])")
    private WebElement OverallWeakOverallHomeworkText;

    @FindBy(xpath = "(//*[text()='QuestionWise Analysis'])")
    private WebElement QuestionWiseAnalysisHomeworkText;

    @FindBy(xpath = "(//*[text()='Strong Topics Analysis'])")
    private WebElement OverallStrongHomeworkText;

    @FindBy(xpath = "(//*[text()='Weak Topics Analysis'])")
    private WebElement OverallWeakHomeworkText;

    @FindBy(xpath = "(//*[contains(text(),'Achieve Analysis')])[2]")
    private WebElement AchieveAnalysisTextOfAchieve;

    @FindBy(xpath = "//*[contains(text(),'Journey Name')]")
    private WebElement journeyNameTextOfAchieve;

    @FindBy(xpath = "//*[contains(text(),'Assigned Date')]")
    private WebElement assignedDateTextOfAchieve;

    @FindBy(xpath = "//*[contains(text(),'Chapter Name')]")
    private WebElement chapterNameTextOfAchieve;

    @FindBy(xpath = "(//*[contains(text(),'Completion')])[2]")
    private WebElement completionTextOfAchieve;

    @FindBy(xpath = "(//*[contains(text(),'Class Mastery')])")
    private WebElement classMasteryTextOfAchieve;

    @FindBy(xpath = "(//*[contains(text(),'Avg. Time Spent')])")
    private WebElement avgTimeSpendTextOfAchieve;

    @FindBy(xpath = "(//*[contains(text(),'Avg. Behaviour')])")
    private WebElement avgBehaviourTextOfAchieve;

    @FindBys({@FindBy(xpath = "(//*[contains(@class,'td-row-wrapper')])")})
    private List<WebElement> journeyNamesOfAchieve;

    @FindBy(xpath = "//*[contains(text(),'Achieve Analysis - Class')]")
    private WebElement achieveAnalysisClassTextOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Chapter Name')]")
    private WebElement chapterNameTextOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Number of Topics')]")
    private WebElement numberOfTopicsOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Assigned Date')]")
    private WebElement assignedDateTextOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Student Type')]")
    private WebElement studentTypeTextOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Overall Concept Mastery')]")
    private WebElement overallConceptMasteryTextOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Overall Students Progress')]")
    private WebElement overallStudentsProgressTextOfAchieveJourney;

    @FindBy(xpath = "(//*[contains(text(),'Achieve Analysis')])[3]")
    private WebElement achiveAnalysisTextOfAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Student Name')]")
    private WebElement studentNameOfTextAchieveJourney;

    @FindBy(xpath = "(//*[contains(text(),'Starting Mastery')])[2]")
    private WebElement startingMasteryOfTextAchieveJourney;

    @FindBy(xpath = "(//*[contains(text(),'Potential Mastery')])[2]")
    private WebElement potenstailMasteryOfTextAchieveJourney;

    @FindBy(xpath = "(//*[contains(text(),'Current Mastery')])[2]")
    private WebElement currentMasteryOfTextAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Time Spent')]")
    private WebElement timeSpentOfTextAchieveJourney;

    @FindBy(xpath = "//*[contains(text(),'Achievements')]")
    private WebElement achievementsOfTextAchieveJourney;

    @FindBys({@FindBy(xpath = "//*[contains(@class,'td-row-wrapper')]")})
    private List<WebElement> selectStudentName;









































































    public void clicktrackButton() {
        wait(5000);
        trackButton.click();



    }
    public void clickAchieveAnalysisTabOfTrackPage(){
        waitForElementToBeVisible(achieveAnalysisTabOfTrackPage);
        jsClick(achieveAnalysisTabOfTrackPage);
    }


    public void clickBackButton(){
        wait(3000);
        jsClick(backbutton);
    }
    public void clickbackButton2(){
        wait(2000);
        jsClick(backbutton2);
    }
    public void clickOnDropDownButtonOfSyllabusCoverage() {
        jsClick(topicOfSyllabusCoverage);
    }
    public  void  clickOnTeachAnalysisButtonViewMore(){
        jsClick(teachAnalysisSectionViewMoreDetails);
    }

    public void clickOnAnyTestNameofAssignTest(int value){
        wait(5000);
        waitForListOfElementToBeVisible(anyTestNameOfAssignAnalysisTest);
        for (int i = 0; i < anyTestNameOfAssignAnalysisTest.size(); i++) {
            if (i ==value){
                WebElement element = anyTestNameOfAssignAnalysisTest.get(i);
                jsClick(element);
                break;
            }}


    }
    public void clickOnAnyStudentName(int value){
        wait(5000);
        waitForListOfElementToBeVisible(selectStudentName);
        for (int i = 0; i < selectStudentName.size(); i++) {
            if (i ==value){
                WebElement element = selectStudentName.get(i);
                jsClick(element);
                break;
            }}


    }
    public void clickOnJourneyofJourneyName(int value){
        wait(5000);
        waitForListOfElementToBeVisible(journeyNamesOfAchieve);
        for (int i = 0; i < journeyNamesOfAchieve.size(); i++) {
            if (i ==value){
                WebElement element = journeyNamesOfAchieve.get(i);
                jsClick(element);
                break;
            }}


    }
    public void clickOnStudentOfOverallAssignTest(int value){
        wait(5000);
        waitForListOfElementToBeVisible(selectStudent);
        for (int i = 0; i < selectStudent.size(); i++) {
            if (i ==value){
                WebElement element = selectStudent.get(i);
                jsClick(element);
                break;
            }}


    }

    public void clickOnStudentNameOfHomework(int value){
        wait(5000);
        waitForListOfElementToBeVisible(studentName);
        for (int i = 0; i < studentName.size(); i++) {
            if (i ==value){
                WebElement element = studentName.get(i);
                jsClick(element);
                break;
            }}


    }
    public void clickOnAssignmentName(int value){
        wait(5000);
        waitForListOfElementToBeVisible(selectAssignmentName);
        for (int i = 0; i < selectAssignmentName.size(); i++) {
            if (i ==value){
                WebElement element = selectAssignmentName.get(i);
                jsClick(element);
                break;
            }}


    }
    public void clickOnplusButton(int value){
        waitForListOfElementToBeVisible(plusButton);
        wait(2000);
        for (int i = 0; i < plusButton.size(); i++) {
            if (i ==value){
                WebElement element = plusButton.get(i);
                element.click();
                break;
            }}


    }

    public void clickOnmyProfile(){
        jsClick(myProfile);

    }
    public void clickOnAvgTimeSpentPlusOfTestButton(){
        waitForElementToBeVisible(AvgTimeSpentPlusOfTestButton);
        AvgTimeSpentPlusOfTestButton.click();
        //jsClick(AvgTimeSpentPlusOfTestButton);

    }

    public void clickOnQuestionWiseAnalysisOfStudentButton(){
        waitForElementToBeVisible(QuestionWiseAnalysisOfStudentButton);
        QuestionWiseAnalysisOfStudentButton.click();
        //jsClick(AvgTimeSpentPlusOfTestButton);

    }
    public void clickOnOverallWeakPlusOfTestButtonOfStudent(){
        waitForElementToBeVisible(OverallWeakPlusOfTestButtonOfStudent);
        OverallWeakPlusOfTestButtonOfStudent.click();

        //jsClick(OverallWeakPlusOfTestButtonOfStudent);

    }public void clickOnOverallStrongPlusOfTestButtonOfStudent(){
        waitForElementToBeVisible(OverallStrongPlusOfTestButtonOfStudent);
        OverallStrongPlusOfTestButtonOfStudent.click();
        //jsClick(OverallStrongPlusOfTestButtonOfStudent);

    }public void clickOnSincerityScorePlusOfTestButton(){
        waitForElementToBeVisible(SincerityScorePlusOfTestButton);
        SincerityScorePlusOfTestButton.click();
        //jsClick(SincerityScorePlusOfTestButton);

    }public void clickOnTopSkillAnalysisPlusOfTestButton(){
        waitForElementToBeVisible(TopSkillAnalysisPlusOfTestButton);
        TopSkillAnalysisPlusOfTestButton.click();
        //jsClick(TopSkillAnalysisPlusOfTestButton);

    }public void clickOnQuestionWiseAnalysisPlusOfTestButton(){
        wait(2000);
        waitForElementToBeVisible(QuestionWiseAnalysisPlusOfTestButton);
        QuestionWiseAnalysisPlusOfTestButton.click();
        //jsClick(QuestionWiseAnalysisPlusOfTestButton);

    }public void clickOnScorePlusOfTestButton(){
        waitForElementToBeVisible(ScorePlusOfTestButton);
        ScorePlusOfTestButton.click();
        //jsClick(ScorePlusOfTestButton);

    }public void clickOnOverallWeakPlusOfTestButton(){
        waitForElementToBeVisible(OverallWeakPlusOfTestButton);
        OverallWeakPlusOfTestButton.click();
        //jsClick(OverallWeakPlusOfTestButton);

    }public void clickOnOverallStrongPlusOfTestButton(){
        waitForElementToBeVisible(OverallStrongPlusOfTestButton);
        OverallStrongPlusOfTestButton.click();
        //jsClick(OverallStrongPlusOfTestButton);

    }public void clickOnClassSincerityScorePlusOfTestButton(){
        waitForElementToBeVisible(ClassSincerityScorePlusOfTestButton);
        ClassSincerityScorePlusOfTestButton.click();
        //jsClick(ClassSincerityScorePlusOfTestButton);

    }public void clickOnAvgAttemptTypeAnalysisPlusOfTestButton(){
        waitForElementToBeVisible(AvgAttemptTypeAnalysisPlusOfTestButton);
        AvgAttemptTypeAnalysisPlusOfTestButton.click();
        //jsClick(AvgAttemptTypeAnalysisPlusOfTestButton);

    }public void clickOnAvgTimeSpentofClassPlusOfTestButton(){
        waitForElementToBeVisible(AvgTimeSpentofClassPlusOfTestButton);
        AvgTimeSpentofClassPlusOfTestButton.click();
        //jsClick(AvgTimeSpentofClassPlusOfTestButton);

    }public void clickOnAvgClassScorePlusOfTestButton(){
        waitForElementToBeVisible(AvgClassScorePlusOfTestButton);

        AvgClassScorePlusOfTestButton.click();
        //jsClick(AvgClassScorePlusOfTestButton);

    }public void clickOnOverallWeakOfSudentButton(){
        waitForElementToBeVisible(OverallWeakOfSudentButton);
        OverallWeakOfSudentButton.click();
        //jsClick(OverallWeakOfSudentButton);

    }
    public void clickOnOverallStrongPlusOfSudentButton(){
        waitForElementToBeVisible(OverallStrongPlusOfSudentButton);
        OverallStrongPlusOfSudentButton.click();

        //jsClick(OverallStrongPlusOfSudentButton);

    }public void clickOnOverallWeakPlusButton(){
        waitForElementToBeVisible(OverallWeakPlusButton);
        OverallWeakPlusButton.click();
        //jsClick(OverallWeakPlusButton);

    }public void clickOnOverallStrongPlusButton(){
        waitForElementToBeVisible(OverallStrongPlusButton);
        OverallStrongPlusButton.click();
        //jsClick(OverallStrongPlusButton);

    }public void clickOnClassSincerityScorePlusButton(){
        waitForElementToBeVisible(ClassSincerityScorePlusButton);
        ClassSincerityScorePlusButton.click();
        //jsClick(ClassSincerityScorePlusButton);

    }
    public void clickOnAvgAttemptTypePlusButton(){
        waitForElementToBeVisible(AvgAttemptTypePlusButton);
        AvgAttemptTypePlusButton.click();
        //jsClick(AvgAttemptTypePlusButton);

    }
    public void clickOnAvgTimeSpentOfClassPlusButton(){
        waitForElementToBeVisible(AvgTimeSpentOfClassPlusButton);
        AvgTimeSpentOfClassPlusButton.click();
        //jsClick(AvgTimeSpentOfClassPlusButton);

    }
    public void clickOnAvgClassAccuracyPlusButton(){
        waitForElementToBeVisible(AvgClassAccuracyPlusButton);
        AvgClassAccuracyPlusButton.click();
        //jsClick(AvgClassAccuracyPlusButton);

    }
    public void clickuserName(){
        wait(5000);
        jsClick(userName);
    }
    public boolean isTrackIsPresent(){

        boolean flag = false;
        try {
            Assert.assertTrue(trackButton.isEnabled());
            flag = true;

        }
        catch (NoSuchElementException e){

        }
        return flag;


    }
    public void clickOnSeeDetails(int i){
        wait(2000);
        waitForElementToBeVisible(seeDetails.get(i));
        jsClick(seeDetails.get(i));

    }
    public boolean verifyAverageMasteryImprovementSectionIsPresent(){
        boolean flag = false;
        try {
            Assert.assertTrue(averageMasteryImprovementSection.isEnabled());
            flag = true;

        }
        catch (NoSuchElementException e){

        }
        return flag;

    }
    public void clickOnBackButton() {
        wait(2000);
        jsClick(backNavigationButton);

    }

    public void clickOnTeachAnalysisButton() {
        jsClick(teachAnalysisSection);

    }
    public void clickOnAssignAnalysisHomeworkButton() {
        jsClick(assignAnalysisHomeworkSection);

    }
    public void clickOnAssignAnalysisTestButton() {
        jsClick(assignAnalysisTestSection);

    }
    public void clickOnStudentWiseAnalysisButton() {
        jsClick(studentWiseAnalysisSection);

    }
    public void clickOnAttendanceAnalysisButton() {
        jsClick(attendanceAnalysisSection);

    }
    public void clickOnOverallPerformanceButton() {
        jsClick(overallPerformanceSection);

    }
    public void clickOnLearningArrowButton() {
        jsClick(learingOutcomesArror);

    }
    public void clickOnCalendarFilter(){
        jsClick(calenderdateRangeFilter);
        wait(5000);
    }
    public  void clickOnSyllabusCoverageViewMore(){
        jsClick(syllabusCoverageViewMore);
    }
    public void  clickOnLearningGapsViewMore(){
        jsClick(learningGapsViewMore);
    }
    /*public void  selectclassData(){
        jsClick(classDropdown);
        jsClick(classDropdownFilterSelect);
    }*/
    public void clickOnClassToBeSelect(int value){
        jsClick(classDropdown);
        waitForListOfElementToBeVisible(classDropdownFilterSelect);
        for (int i = 0; i < classDropdownFilterSelect.size(); i++) {
            if (i ==value){
                WebElement element = classDropdownFilterSelect.get(i);
                jsClick(element);
                break;
            }}


    }
    public void selectClassData(String class_Name){
        jsClick(classDropdown);
        waitForElementToBeVisible(classSelection.get(0));
        for(int i = 0; i < classSelection.size(); i++){
            if(classSelection.get(i).getText().equalsIgnoreCase(class_Name)){
                classSelection.get(i).click();
                break;
            }
        }
    }
    public String percentageValueData(int index){
       return percentageValue.get(index).getText();
    }
    public String syllabusCoverageGraphData2(int index){
        return syllabusCoverageGraphPlanned.get(index).getText();
    }
    public String percentageChangeValueData(int index){

        return percentageChangeValue.get(index).getText();
    }
    public  void  selectSectionData(int value){
        jsClick(sectionDropdown);
        waitForListOfElementToBeVisible(sectionDropdownFilterSelect);
        for (int i = 0; i < sectionDropdownFilterSelect.size(); i++) {
            WebElement element = sectionDropdownFilterSelect.get(i);
            jsClick(element);
            break;
        }

    }
    public  void  subjectData(int value){
        jsClick(subjectDropdown);
        waitForListOfElementToBeVisible(subjectDropdownFilterSelect);
        for (int i = 0; i < subjectDropdownFilterSelect.size(); i++) {
            WebElement element = subjectDropdownFilterSelect.get(i);
            jsClick(element);
            break;
        }
    }



    public void scrollDown() {
        if (syllabusCovrageSection.isEnabled()) {
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", syllabusCovrageSection);
        }

    }
    public void scrollDownofOverallHomeworkPage() {
        if (homeworkAnalysisText.isEnabled()) {
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", homeworkAnalysisText);
        }

    }
    public void scrollDown1() {
        wait(3000);
        if (homeworkAnalysisText.isEnabled()) {
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", homeworkAnalysisText);
        }
        wait(2000);

    }
    public void scrollDown2(){
        if(syllabusCoverageTrackPage.isEnabled()){
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", syllabusCoverageTrackPage);
        }
    }
    public void scrollDownTill() {
        wait(2000);
        if (assigntesttext.isEnabled()) {
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", assigntesttext);
        }

    }
    public void onlyscroll(){
        if(overallLearningBehavioursText.isEnabled()){
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", overallLearningBehavioursText);
        }
    }
    public boolean averageMasteryImprovementPage(){
        boolean flag = false;
        try {
            Assert.assertTrue(averageMasteryImprovementpage.isEnabled());
            flag = true;

        }
        catch (NoSuchElementException e){

        }
        return flag;


    }

    public void verifyAllTheElementsOnTrackPage(){

        softAssert.assertEquals(outcomesPanel.isDisplayed(),true,"Outcomes Panel' is Not displayed");
        softAssert.assertEquals(effortInsights.isDisplayed(),true,"Outcomes Panel' is Not displayed");

        softAssert.assertEquals(masteryImprovementValue.isDisplayed(),true,"Mastery Improvement VALUE Not Displayed");
        softAssert.assertEquals(seeDetails.get(0).isDisplayed(),true,"See details button  Not Displayed ");

        softAssert.assertEquals(syllabusCovrageSection.isDisplayed(),true,"Syllabus Covrage Section VALUE Not Displayed");
        softAssert.assertEquals(seeDetails.get(1).isDisplayed(),true,"See details button  Not Displayed ");

        softAssert.assertEquals(scoreImprovementSection.isDisplayed(),true,"Score Improvement Section VALUE Not Displayed");
        softAssert.assertEquals(seeDetails.get(2).isDisplayed(),true,"See details button  Not Displayed ");

        softAssert.assertEquals(behaviouralImprovementSection.isDisplayed(),true,"Behavioural Improvement Section VALUE Not Displayed");
        softAssert.assertEquals(seeDetails.get(3).isDisplayed(),true,"See details button  Not Displayed ");

        softAssert.assertEquals(classParticipationSection.isDisplayed(),true,"Class Participation Section VALUE Not Displayed");
        softAssert.assertEquals(seeDetails.get(4).isDisplayed(),true,"See details button  Not Displayed ");

        softAssert.assertEquals(homeworkCompletionSection.isDisplayed(),true,"Homework Completion Section VALUE Not Displayed");
        softAssert.assertEquals(seeDetails.get(5).isDisplayed(),true,"See details button  Not Displayed ");

        softAssert.assertEquals(learingOutcomesValue.isDisplayed(),true,"Learing Outcomes VALUE Not Displayed");
        softAssert.assertEquals(overallLearningBehavioursText.isDisplayed(),true,"overall Learning Behaviours Text is not Present ");

        softAssert.assertEquals(teachAnalysisSection.isDisplayed(),true,"Teach Analysis VALUE Not Displayed");
        softAssert.assertEquals(assignAnalysisHomeworkSection.isDisplayed(),true,"Assign Analysis Homework VALUE Not Displayed");
        softAssert.assertEquals(assignAnalysisTestSection.isDisplayed(),true,"Assign Analysis Test VALUE Not Displayed");
        softAssert.assertEquals(studentWiseAnalysisSection.isDisplayed(),true,"StudentWise Analysis VALUE Not Displayed");
        softAssert.assertEquals(attendanceAnalysisSection.isDisplayed(),true,"Attendance Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallPerformanceSection.isDisplayed(),true,"Overall Performance  VALUE Not Displayed");












        softAssert.assertAll();


    }
    public void verifyLastData(){
        softAssert.assertEquals(overallClassBehaviourTryingHardText.isDisplayed(),true,"overall ClassBehaviour TryingHard Text  VALUE Not Displayed");
        softAssert.assertEquals(inControlText.isDisplayed(),true,"in Control Text VALUE Not Displayed");
        //softAssert.assertEquals(marathonText.isDisplayed(),true,"marathon Text  VALUE Not Displayed");
        softAssert.assertEquals(tryingHarderText.isDisplayed(),true,"trying Harder Text  VALUE Not Displayed");
        //softAssert.assertEquals(marathonText.isDisplayed(),true,"marathon Text  VALUE Not Displayed");
        softAssert.assertAll();

    }
    public void verifyMasteryImprovementModule(){
        wait(2000);
        softAssert.assertEquals(averageMasteryImprovementSection.isDisplayed(),true,"AverageMastery Improvement Text Not Displayed");
        softAssert.assertEquals(byMastertilldate.isDisplayed(),true,"By Master Till Date Text Not Displayed");
        softAssert.assertEquals(byTopic.isDisplayed(),true,"BY Topic text Not Displayed");
        softAssert.assertEquals(studentWiseMaster.isDisplayed(),true,"Student Wise Master text Not Displayed");
        softAssert.assertEquals(masteryImproved.isDisplayed(),true,"Mastery Improved Text Not Displayed");
        softAssert.assertEquals(masteryDropped.isDisplayed(),true,"Mastery Improved Text Not Displayed");
        softAssert.assertEquals(masterUnchanged.isDisplayed(),true,"Mastery Improved Text Not Displayed");


        softAssert.assertAll();


    }
    public void verifySyllabusCoverageModule(){
        softAssert.assertEquals(syllabusCoverageTrackPage.isDisplayed(),true,"Syllabus Coverage  VALUE Not Displayed");
        softAssert.assertEquals(byPeriodCountTillDate.isDisplayed(),true,"By Period Count Till Date VALUE Not Displayed");
        softAssert.assertEquals(byPeriodsProgress.isDisplayed(),true,"By Periods Progress VALUE Not Displayed");
        softAssert.assertEquals(syllabusCoverage.isDisplayed(),true,"Syllabus Coverage VALUE Not Displayed");
        softAssert.assertEquals(topicNameOfSyllabusCoverage.isDisplayed(),true,"topicName Of SyllabusCoverage VALUE Not Displayed");
        softAssert.assertEquals(progressOfSyllabusCoverage.isDisplayed(),true,"progress Of Syllabus Coverage VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpentOfSyllabusCoverage.isDisplayed(),true,"avg Time Spent Of Syllabus Coverage VALUE Not Displayed");
        softAssert.assertEquals(avhTimeSpentOnLearnOfSyllabusCoverage.isDisplayed(),true,"avg Time Spent On Learn Of SyllabusCoverage VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpentOnPracticeOfSyllabusCoverage.isDisplayed(),true,"avgTime Spent On Practice Of SyllabusCoverage Not Displayed");
        softAssert.assertEquals(avgTimeSpentOnTestOfSyllabusCoverage.isDisplayed(),true,"avg Time Spent On Test Of SyllabusCoverage VALUE Not Displayed");


        softAssert.assertAll();


    }
    public void verifyScoreImprovementModule(){
        softAssert.assertEquals(averageScoreImprovementPage.isDisplayed(),true,"Average Score Improvement VALUE Not Displayed");
        softAssert.assertEquals(byAverageScoreTillDate.isDisplayed(),true,"By Average Score Till Date VALUE Not Displayed");
        softAssert.assertEquals(byTest.isDisplayed(),true,"By Test VALUE Not Displayed");
        softAssert.assertEquals(studentWiseScoreImprovement.isDisplayed(),true,"StudentWise Score Improvement  VALUE Not Displayed");
        softAssert.assertEquals(scoreImprovement.isDisplayed(),true,"ScoreImprovement VALUE Not Displayed");
        softAssert.assertEquals(scoreDropped.isDisplayed(),true,"Score Dropped VALUE Not Displayed");
        softAssert.assertEquals(scoreUnchanged.isDisplayed(),true,"Score Unchanged VALUE Not Displayed");
        softAssert.assertAll();

    }
    public void verifyBehaviouralImprovementModule(){
        softAssert.assertEquals(averageBehaviouralImprovement.isDisplayed(),true,"Average Behavioral Improvement VALUE Not Displayed");
        softAssert.assertEquals(byBehaviourTillDate.isDisplayed(),true,"By Behaviour Till Date VALUE Not Displayed");
        softAssert.assertEquals(byBehaviour.isDisplayed(),true,"By Behaviour VALUE Not Displayed");
        softAssert.assertEquals(studentwiseBehaviouralImprovement.isDisplayed(),true,"StudentWise Behavioural Improvement VALUE Not Displayed");
        softAssert.assertEquals(behaviorImproved.isDisplayed(),true,"Behavioural Improved VALUE Not Displayed");
        softAssert.assertEquals(behaviorDropped.isDisplayed(),true,"Behavioural Dropped VALUE Not Displayed");
        softAssert.assertEquals(behaviorUnchanged.isDisplayed(),true,"Behavioural Unchanged VALUE Not Displayed");
        softAssert.assertAll();





    }
    public void verifyClassParticipationModule(){
        softAssert.assertEquals(averageClassParticipation.isDisplayed(),true,"Average Class Participation VALUE Not Displayed");
        softAssert.assertEquals(byParticipationTillDate.isDisplayed(),true,"By Participation Till Date VALUE Not Displayed");
        softAssert.assertEquals(byParticipation.isDisplayed(),true,"by Participation VALUE Not Displayed");
        softAssert.assertEquals(studentWiseClassParticipation.isDisplayed(),true,"studentWise Class Participation VALUE Not Displayed");
        softAssert.assertEquals(participationImproved.isDisplayed(),true,"participation Improved VALUE Not Displayed");
        softAssert.assertEquals(participationDropped.isDisplayed(),true,"participation Dropped VALUE Not Displayed");
        softAssert.assertEquals(participationUnchanged.isDisplayed(),true,"participation Unchanged VALUE Not Displayed");
        softAssert.assertAll();

    }
    public void verifyHomeworkCompletionModule(){
        softAssert.assertEquals(averageHomeworkCompletion.isDisplayed(),true,"Average Homework Completion VALUE Not Displayed");
        wait(10000);
        softAssert.assertEquals(byCompletionTillDate.isDisplayed(),true,"By Completion Till Date VALUE Not Displayed");
        softAssert.assertEquals(byCompletion.isDisplayed(),true,"By Completion VALUE Not Displayed");
        softAssert.assertEquals(studentWiseHomeworkCompletion.isDisplayed(),true,"studentWise Homework Completion VALUE Not Displayed");
        softAssert.assertEquals(completionImproved.isDisplayed(),true,"Completion- Improved VALUE Not Displayed");
        softAssert.assertEquals(completionDropped.isDisplayed(),true,"Completion Dropped VALUE Not Displayed");
        softAssert.assertEquals(completionUnchanged.isDisplayed(),true,"Completion Unchanged VALUE Not Displayed");
        softAssert.assertAll();






    }

    public void verifyIconsOnTrackPage(){
        softAssert.assertEquals(masterImprovementIcon.isDisplayed(),true,"Master Improvement icon Displayed");
        softAssert.assertEquals(syllabusCoverageIcon.isDisplayed(),true,"syllabus Coverage Icon Displayed");
        softAssert.assertEquals(scoreImprovementSectionIcon.isDisplayed(),true,"score Improvement Section Icon Displayed");
        softAssert.assertEquals(behaviouralImprovementIcon.isDisplayed(),true,"behavioural Improved Icon Displayed");
        softAssert.assertEquals(classParticipationSectionIcon.isDisplayed(),true,"class Participation Section Icon Displayed");
        softAssert.assertEquals(homeworkCompletionSectionIcon.isDisplayed(),true,"homework Completion Section Icon Displayed");
        softAssert.assertEquals(learningGapsOccurredIcon.isDisplayed(),true,"learning Gaps Occurred Icon Displayed");
        softAssert.assertEquals(learningGapsRemediatedIcon.isDisplayed(),true,"learning Gaps Remediated Icon Displayed");

        softAssert.assertAll();

    }
    public void verifyMasteryImprovementPageIcons()
    {
        softAssert.assertEquals(masteryImprovedIcon.isDisplayed(),true,"mastery Improved Icon Displayed");
        softAssert.assertEquals(masteryDroppedIcon.isDisplayed(),true,"mastery Dropped Icon Displayed");
        softAssert.assertEquals(masterUnchangedIcon.isDisplayed(),true,"master Unchanged Icon Displayed");
        softAssert.assertAll();
    }
    public void verifyStudentAssignedHomeworkData()
    {
        softAssert.assertEquals(textOfStudent.isDisplayed(),true,"text Of Student text not Displayed");
        softAssert.assertEquals(questionWiseAnalysisOfStudent.isDisplayed(),true,"question Wise Analysi Of Student text not Displayed");
        softAssert.assertEquals(avgTimeSpentOfStudent.isDisplayed(),true,"avg Time Spent Of Student text not Displayed");
        softAssert.assertEquals(overallWeakOfStudent.isDisplayed(),true,"overall Weak Of Student text not Displayed");
        softAssert.assertEquals(overallStrongOfStudent.isDisplayed(),true,"overall Strong Of Student text not Displayed");
        softAssert.assertEquals(sincerityscorenegativeOfStudent.isDisplayed(),true,"sincerity score negative OfStudent text not Displayed");
        softAssert.assertEquals(sincerityscorepositiveOfStudent.isDisplayed(),true,"sincerity score positive Of Student text not Displayed");
        softAssert.assertEquals(topskillOfStudent.isDisplayed(),true,"top skill Of Student text not Displayed");
        softAssert.assertEquals(accuracyofStudent.isDisplayed(),true,"accuracy of Student text not Displayed");
        softAssert.assertAll();
    }
    public void verifyScoreImprovementPageIcons(){
        softAssert.assertEquals(scoreImprovedIcon.isDisplayed(),true,"score Improved Icon Displayed");
        softAssert.assertEquals(scoreDroppedIcon.isDisplayed(),true,"score Dropped IconDisplayed");
        softAssert.assertEquals(scoreUnchangedIcon.isDisplayed(),true,"score Unchanged Icon Displayed");
        softAssert.assertAll();
    }

    public void verifyBehaviouralImprovementPageIcon(){
        softAssert.assertEquals(behaviourImprovedIcon.isDisplayed(),true,"behaviour Improved Icon Displayed");
        softAssert.assertEquals(behaviourDroppedIcon.isDisplayed(),true,"behaviour Dropped Icon Displayed");
        softAssert.assertEquals(behaviourUnchangedIcon.isDisplayed(),true,"behaviour UnchangedIcon Displayed");
        softAssert.assertAll();

    }

    public void verifyClassParticipationPageIcon(){
        softAssert.assertEquals(participationImprovedIcon.isDisplayed(),true,"participation Improved Icon Displayed");
        softAssert.assertEquals(participationDroppedIcon.isDisplayed(),true,"participation Dropped Icon Displayed");
        softAssert.assertEquals(participationUnchangedIcon.isDisplayed(),true,"participation Unchanged Icon Displayed");
        softAssert.assertAll();

    }
    public void verifyHomeworkCompletionPageIcon(){
        softAssert.assertEquals(completionImprovedIcon.isDisplayed(),true,"completion Improved Icon Displayed");
        softAssert.assertEquals(completionDroppedIcon.isDisplayed(),true,"completion Dropped Icon Displayed");
        softAssert.assertEquals(completionUnchangedIcon.isDisplayed(),true,"completion Unchanged Icon Displayed");
        softAssert.assertAll();

    }
    public void verifyOverallLearningBehavioursImages(){
        softAssert.assertEquals(overallClassBehaviourTryingHardImage.isDisplayed(),true,"overall Class Behaviou rTrying Hard Image Displayed");
        //softAssert.assertEquals(marathonImage.isDisplayed(),true,"marathon Image Displayed");
        softAssert.assertEquals(tryingHarderImage.isDisplayed(),true,"trying Harder Image Displayed");
        //softAssert.assertEquals(inControlImage.isDisplayed(),true,"in Control Image Displayed");
        softAssert.assertAll();

    }
    public void verifyMyprofileUsername(){
        wait(5000);
        softAssert.assertEquals(myProfile.isDisplayed(),true,"My Profile is Not Displayed");
        softAssert.assertEquals(helpAndSupport.isDisplayed(),true,"Help and support  Not Displayed");
        softAssert.assertEquals(logout.isDisplayed(),true,"Logout Not Displayed");
        softAssert.assertAll();
    }
    public void verifyAssignAnalysisTestDetails(){
        softAssert.assertEquals(testNameOfAssignAnalysisTest.isDisplayed(),true,"Test name Text on Assign Analysis - Test VALUE Not Displayed");
        softAssert.assertEquals(avgScoreOfAssignAnalysisTest.isDisplayed(),true,"avg score Text on Assign Analysis - Test VALUE Not Displayed");
        softAssert.assertEquals(avgMarksOfAssignAnalysisTest.isDisplayed(),true,"avg marks Text on Assign Analysis - Test VALUE Not Displayed");
        softAssert.assertEquals(submissionOfAssignAnalysisTest.isDisplayed(),true,"Submission Text on Assign Analysis - Test VALUE Not Displayed");
        softAssert.assertEquals(testTypeOfAssignAnalysisTest.isDisplayed(),true,"TestType Text  on Assign Analysis - Test VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyTeachAnalysisDetails(){
        softAssert.assertEquals(dateOfTeachAnalysis.isDisplayed(),true,"date Of Teach Analysis VALUE Not Displayed");
        softAssert.assertEquals(periodCountOfTeachAnalysis.isDisplayed(),true,"period Count Of Teach Analysis VALUE Not Displayed");
        softAssert.assertEquals(chapterNameOfTeachAnalysis.isDisplayed(),true,"chapter Name Of Teach Analysis VALUE Not Displayed");
        softAssert.assertEquals(topicNameOfTeachAnalysis.isDisplayed(),true,"topicName Of TeachAnalys is VALUE Not Displayed");
        softAssert.assertEquals(classAttendanceOfTeachAnalysis.isDisplayed(),true,"class Attendance Of TeachAnalysis VALUE Not Displayed");
        softAssert.assertEquals(classParticipationOfTeachAnalysis.isDisplayed(),true,"class Participation Of Teach Analysis VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyAssignAnalysisHomeworkDetails(){
        softAssert.assertEquals(assignmentNameOfHomework.isDisplayed(),true,"assignment Name Of Homework VALUE Not Displayed");
        softAssert.assertEquals(dueDateOfHomework.isDisplayed(),true,"due Date Of Homework VALUE Not Displayed");
        softAssert.assertEquals(avgAccuracyOfHomework.isDisplayed(),true,"avg Accuracy Of Homework VALUE Not Displayed");
        softAssert.assertEquals(submissionOfHomework.isDisplayed(),true,"submission Of Homework VALUE Not Displayed");
        softAssert.assertEquals(homeworkTypeOfHomework.isDisplayed(),true,"homework Type Of Homework VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyStudentWiseAnalysisDetails(){
        softAssert.assertEquals(studentNameOfStudentWiseAnalysis.isDisplayed(),true,"student Name Of StudentWise Analysis VALUE Not Displayed");
        softAssert.assertEquals(classRankOfStudentWiseAnalysis.isDisplayed(),true,"class Rank Of StudentWise Analysis VALUE Not Displayed");
        softAssert.assertEquals(performanceOfStudentWiseAnalysis.isDisplayed(),true,"performance Of StudentWise Analysis VALUE Not Displayed");
        softAssert.assertEquals(videosWatchedOfStudentWiseAnalysis.isDisplayed(),true,"videos Watched Of StudentWiseAnalysis VALUE Not Displayed");
        softAssert.assertEquals(questionsPracticedOfStudentWiseAnalysis.isDisplayed(),true,"questions Practiced Of StudentWise Analysis VALUE Not Displayed");
        softAssert.assertEquals(totalTimeOfStudentWiseAnalysis.isDisplayed(),true,"total Time Of StudentWise Analysis VALUE Not Displayed");
        softAssert.assertEquals(percentageOfImprovementOfStudentWiseAnalysis.isDisplayed(),true,"percentage Of Improvement Of StudentWiseAnalysis VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void TrackPagetext(){
        softAssert.assertEquals(text1.isDisplayed(),true,"The most powerful education intelligence you will ever experience  Not Displayed");
        softAssert.assertEquals(text2.isDisplayed(),true,"Improvement Insights in this period VALUE Not Displayed");
        softAssert.assertEquals(text3.isDisplayed(),true,"Information that needs your immediate attention  VALUE Not Displayed");
        softAssert.assertEquals(text4.isDisplayed(),true,"Students Improvement in this period VALUE Not Displayed");
        softAssert.assertEquals(text5.isDisplayed(),true,"Students Improvement in this period VALUE Not Displayed");
        softAssert.assertEquals(text6.isDisplayed(),true,"Students Improvement in this period VALUE Not Displayed");
        softAssert.assertEquals(text7.isDisplayed(),true,"Students Improvement in this period Not Displayed");
        softAssert.assertEquals(text8.isDisplayed(),true,"Students Improvement in this period Not Displayed");
        softAssert.assertEquals(text9.isDisplayed(),true,"Overall Syllabus Coverage for 12th CBSE-A - Mathematics Not Displayed");
        softAssert.assertEquals(text10.isDisplayed(),true,"Learning Gaps Identified and Resolved for Class 12A in Mathematics Not Displayed");
        softAssert.assertEquals(text11.isDisplayed(),true,"Concept Mastery of Class 12A for Mathematics Not Displayed");
        softAssert.assertEquals(text12.isDisplayed(),true,"Average Score of Class 12A for Tests Taken in Mathematics Not Displayed");
        softAssert.assertEquals(text13.isDisplayed(),true,"The students in your class are finding it difficult to succeed often, despite putting in a lot of effort Not Displayed");
        softAssert.assertEquals(text14.isDisplayed(),true,"Students are putting the needed effort and succeeding often Not Displayed");
        softAssert.assertEquals(text15.isDisplayed(),true,"Students have amazing stamina and can focus for a long duration at a stretch Not Displayed");
        softAssert.assertEquals(text16.isDisplayed(),true,"Students are putting a lot of effort and still unable to succeed often text Not Displayed");
        softAssert.assertAll();



    }
    public void verifyLearningOutcomesAchievedasperNationalCurriculumFrameworkDetails(){
        softAssert.assertEquals(listOfOutcomesOnLearningOutcomesIndividually.isDisplayed(),true,"list Of Outcomes On Learning Outcomes Individually VALUE Not Displayed");
        softAssert.assertEquals(totalStudentOutcomesOnLearningOutcomesIndividually.isDisplayed(),true,"total Student Outcomes On Learning Outcomes Individually VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpentOnLearningOutcomesIndividually.isDisplayed(),true,"avg Time Spent On Learning Outcomes Individually VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpentOnLearnOnLearningOutcomesIndividually.isDisplayed(),true,"avg Time Spent On Learn On Learning Outcomes Individually VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpentOnPracticeOnLearningOutcomesIndividually.isDisplayed(),true,"avg Time Spent On Practice On Learning OutcomesIndividually VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpentOnTestOnLearningOutcomesIndividually.isDisplayed(),true,"avgTime Spent On Test OnLearning Outcomes Individually VALUE Not Displayed");
        softAssert.assertAll();
    }

    public  void calendarDateRangeFilterOfTrack(){

        DateFormat dateFormat = new SimpleDateFormat("d");
        Calendar cal = Calendar.getInstance();
        String date1 = dateFormat.format(cal.getTime());
        System.out.println("Today's date is "+dateFormat.format(cal.getTime()));
        cal.add(Calendar.DATE, -1);
        String date2 = dateFormat.format(cal.getTime());
        System.out.println("Yesterday's date was "+dateFormat.format(cal.getTime()));

        List<WebElement> elements2=driver.findElements(By.xpath("//td[text()='"+date2+"' and @class='in-range available']|//td[text()='"+date2+"' and @class='weekend in-range available']"));
        elements2.get(0).click();
        wait(5000);

        List<WebElement> element1 = driver.findElements(By.xpath("//td[text()='"+date1+"' and @class='today available']|//td[text()='"+date1+"' and @class='today active end-date in-range available']|//td[text()='"+date1+"' and @class='today weekend active end-date in-range available']|//*[contains(@class,'available')  and text()='"+date1+"']"));
        System.out.println("my value is" + element1.size());
        element1.get(element1.size()-1).click();
        wait(5000);


        driver.findElement(By.xpath("//button[text()='Apply']")).click();
        }
    public void OverallTestAnalysisPageOfAssignTestAnalysis(){
        softAssert.assertEquals(avgClassScoreOnOverallTestAnalysis.isDisplayed(),true,"avg ClassScore On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(improveScoreOfStudentsOnOverallTestAnalysis.isDisplayed(),true,"improve Score Of Students On OverallT est Analysis VALUE Not Displayed");
        softAssert.assertEquals(avgAttemptTypeAnalysisOnOverallTestAnalysis.isDisplayed(),true,"avg Attempt Type Analysis On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classTopSkillAnalysisOnOverallTestAnalysis.isDisplayed(),true,"class Top Skill- Analysis On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classSincerityScorePOSITIVEBEHAVIOUROnOverallTestAnalysis.isDisplayed(),true," class Sincerity Score POSITIVE BEHAVIOUR- On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classSincerityScoreNEGATIVEBEHAVIOUROnOverallTestAnalysis.isDisplayed(),true,"class Sincerity Score NEGATIVE BEHAVIOUR On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallStrongOnOverallTestAnalysis.isDisplayed(),true,"overall Strong On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallWeakOnOverallTestAnalysis.isDisplayed(),true,"overall Weak On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(studentNameOnOverallTestAnalysis.isDisplayed(),true,"studentName On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(avgClassScoreOnOverallTestAnalysis.isDisplayed(),true,"avg Class Score On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(performanceOnOverallTestAnalysis.isDisplayed(),true," performance On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(timeSpentOnOverallTestAnalysis.isDisplayed(),true,"time Spent O nOverall Test Analysis VALUE Not Displayed");
        softAssert.assertAll();

    }
    public void OverallTestAnalysisPageOfAssignTestAnalysis1(){
        wait(50000);
        softAssert.assertEquals(avgClassScoreOnOverallTestAnalysis1.isDisplayed(),true,"avg ClassScore On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(improveScoreOfStudentsOnOverallTestAnalysis.isDisplayed(),true,"improve Score Of Students On OverallT est Analysis VALUE Not Displayed");
        softAssert.assertEquals(avgAttemptTypeAnalysisOnOverallTestAnalysis.isDisplayed(),true,"avg Attempt Type Analysis On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classTopSkillAnalysisOnOverallTestAnalysis.isDisplayed(),true,"class Top Skill- Analysis On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classSincerityScorePOSITIVEBEHAVIOUROnOverallTestAnalysis.isDisplayed(),true," class Sincerity Score POSITIVE BEHAVIOUR- On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classSincerityScoreNEGATIVEBEHAVIOUROnOverallTestAnalysis.isDisplayed(),true,"class Sincerity Score NEGATIVE BEHAVIOUR On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallStrongOnOverallTestAnalysis.isDisplayed(),true,"overall Strong On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallWeakOnOverallTestAnalysis.isDisplayed(),true,"overall Weak On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(studentNameOnOverallTestAnalysis.isDisplayed(),true,"studentName On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(averageScoreOnOverallTestAnalysis1.isDisplayed(),true,"avg Class Score On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(performanceOnOverallTestAnalysis.isDisplayed(),true," performance On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(timeSpentOnOverallTestAnalysis.isDisplayed(),true,"time Spent O nOverall Test Analysis VALUE Not Displayed");
        softAssert.assertAll();

    }
    public void OverallHomeworkAnalysisClassPageOfAssignHomeworkAnalysis(){

        softAssert.assertEquals(avgClassScoreOnOverallTestAnalysis.isDisplayed(),true,"avg ClassScore On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(improveScoreOfStudentsOnOverallTestAnalysis.isDisplayed(),true,"improve Score Of Students On OverallT est Analysis VALUE Not Displayed");
        softAssert.assertEquals(avgAttemptTypeAnalysisOnOverallTestAnalysis.isDisplayed(),true,"avg Attempt Type Analysis On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classTopSkillAnalysisOnOverallTestAnalysis.isDisplayed(),true,"class Top Skill- Analysis On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classSincerityScorePOSITIVEBEHAVIOUROnOverallTestAnalysis.isDisplayed(),true," class Sincerity Score POSITIVE BEHAVIOUR- On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(classSincerityScoreNEGATIVEBEHAVIOUROnOverallTestAnalysis.isDisplayed(),true,"class Sincerity Score NEGATIVE BEHAVIOUR On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallStrongOnOverallTestAnalysis.isDisplayed(),true,"overall Strong On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(overallWeakOnOverallTestAnalysis.isDisplayed(),true,"overall Weak On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertAll();
        wait(3000);

    }
    public void OverallHomeworkAnalysisClassPageOfAssignHomeworkAnalysisDownData(){
        wait(2000);


        softAssert.assertEquals(studentNameOnOverallTestAnalysis.isDisplayed(),true,"studentName On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(timespentInMinofOverallHomeworkAnalysisClass.isDisplayed(),true,"timespent In Min of Overall Homework Analysis Class VALUE Not Displayed");
        softAssert.assertEquals(performanceOnOverallTestAnalysis.isDisplayed(),true," performance On Overall Test Analysis VALUE Not Displayed");
        softAssert.assertEquals(homeworkAccuracyOnOverallHomeworkAnalysisClass.isDisplayed(),true,"homework Accuracy VALUE Not Displayed");
        softAssert.assertEquals(attemptTypeOnOverallHomeworkAnalysisClass.isDisplayed(),true,"attempt TypeO n Overall Homework- Analysis Class VALUE Not Displayed");
        softAssert.assertAll();
        wait(3000);

    }
    public void individualTeachAnalysisTab(){
        wait(2000);
        softAssert.assertEquals(topicNameOfTeachAnalysis.isDisplayed(),true,"topicName Of TeachAnalysis VALUE Not Displayed");
        softAssert.assertEquals(classParticipationOfTeachAnalysis.isDisplayed(),true,"class Participation Of Teach Analysis VALUE Not Displayed");
        softAssert.assertEquals(practiceQuestionInClassOfIndividualTeachAnalysis.isDisplayed(),true,"practice Question- InClass Of Individual Teach AnalysisVALUE Not Displayed");
        softAssert.assertEquals(practiceAccuracyOnClassQuestionsOfIndividualTeachAnalysis.isDisplayed(),true,"practice Accuracy On Class Questions Of Individual TeachAnalysis VALUE Not Displayed");
        softAssert.assertEquals(vocalOfIndividualTeachAnalysis.isDisplayed(),true,"vocal Of Individual Teach Analysis VALUE Not Displayed");
        softAssert.assertEquals(attentiveOfIndividualTeachAnalysis.isDisplayed(),true,"attentive Of Individual Teach Analysis VALUE Not Displayed");
        softAssert.assertAll();



    }

    public String todaysDate(){
        Date yesterday = Calendar.getInstance().getTime();

        // Constructs a SimpleDateFormat using the given pattern
        SimpleDateFormat crunchifyFormat = new SimpleDateFormat("MMM dd yyyy HH:mm:ss.SSS zzz");

        // format() formats a Date into a date/time string.
        String currentTime = crunchifyFormat.format(yesterday);
      //  log("Current Time = " + currentTime);
        long epochTime = 0;

        try {

            // parse() parses text from the beginning of the given string to produce a date.
            Date date = crunchifyFormat.parse(currentTime);

            // getTime() returns the number of milliseconds since January 1, 1970, 00:00:00 GMT represented by this Date object.
             epochTime = date.getTime()/1000;

      //      log("Current Time in Epoch: " + epochTime/1000);

        } catch (ParseException e) {
            e.printStackTrace();
        }
        String todaysTime = String.valueOf(epochTime);

        return todaysTime;
    }
    public Date yesterday() {
        final Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DATE, -1);
        return cal.getTime();
    }

    public String getYesterdayDateString() {
        DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
        System.out.println(dateFormat.format(yesterday()));

        String str = dateFormat.format(yesterday());
        Date date = null;
        try {
            date = dateFormat.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long epoch = date.getTime()/1000;
        String yesterdaytime = String.valueOf(epoch);
        System.out.println(epoch); // 1055545912454
        System.out.println(yesterdaytime);

        return yesterdaytime;

    }
    public void testdatademo(){
        wait(5000);
        String verticalXpath = "(//*[local-name()='svg'])[15]//*[local-name()='g' and @class='highcharts-series-group']//*[local-name()='path']";
        List<WebElement> barlist = (List<WebElement>) driver.findElement(By.xpath(verticalXpath));
        System.out.println("total bars :" +barlist.size());

        /*WebElement ele = syllabusCoverageGraphActual;

//Creating object of an Actions class
        Actions action = new Actions(driver);

//Performing the mouse hover action on the target element.
        action.moveToElement(ele).perform();
        String toolTip=driver.findElement(By.xpath("(//*[@class='highcharts-label highcharts-tooltip highcharts-color-undefined'])[2]/span/div")).getText();

        System.out.println("toolTip text= "+toolTip);*/

    }
    public void verifyWeekTopicText(){
        softAssert.assertEquals(WeakTopicsAnalysisText.isDisplayed(),true,"Weak Topics Analysis Text Analysis VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyStrongTopicsAnalysisText(){
        softAssert.assertEquals(StrongTopicsAnalysisText.isDisplayed(),true,"Strong Topics Analysis Text VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifySincerityScoreText(){
        softAssert.assertEquals(SincerityScoreText.isDisplayed(),true,"SincerityScoreText VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyAverageTimeSpentText(){
        softAssert.assertEquals(AverageTimeSpentText.isDisplayed(),true,"AverageTimeSpentText VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyQuestionwiseAnalysisText(){
        softAssert.assertEquals(QuestionwiseAnalysisText.isDisplayed(),true,"Question wise Analysis Text VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyAverageScoreText(){
        wait(2000);
        softAssert.assertEquals(testScoreText.isDisplayed(),true,"Test Score  Of Individual Test Analysis VALUE Not Displayed");
        softAssert.assertAll();
    }
    public void verifyTopSkillAnalysisText(){
        softAssert.assertEquals(TopSkillAnalysisText.isDisplayed(),true,"Top Skill Analysis Text  VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAvgAttemptTypeAnalysisOverallText(){
        softAssert.assertEquals(AvgAttemptTypeAnalysisOverallText.isDisplayed(),true,"Avg Attempt Type Analysis Overall Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAvgTimeSpentofClassText(){
        softAssert.assertEquals(AvgTimeSpentofClassText.isDisplayed(),true,"Avg Time Spent of Class Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyOverallWeakText(){
        softAssert.assertEquals(OverallWeakText.isDisplayed(),true,"Overall Weak Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyOverallStrongText(){
        softAssert.assertEquals(OverallStrongText.isDisplayed(),true,"Overall Strong Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyClassSincerityScoreText(){
        softAssert.assertEquals(ClassSincerityScoreText.isDisplayed(),true,"Class Sincerity Score Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyClassTopSkillAnalysisText(){
        softAssert.assertEquals(ClassTopSkillAnalysisText.isDisplayed(),true,"Class Top Skill Analysis Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAvgClassScoreText(){
        softAssert.assertEquals(AvgClassScoreText.isDisplayed(),true,"Avg Class Score Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAvgClassAccuracyOverallHomeworkText(){
        softAssert.assertEquals(AvgClassAccuracyOverallHomeworkText.isDisplayed(),true,"Avg Class Accuracy Overall Homework Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAvgAttemptTypeAnalysisOverallHomeworkText(){
        softAssert.assertEquals(AvgAttemptTypeAnalysisOverallHomeworkText.isDisplayed(),true,"Avg Attempt Type Analysis Overall Homework Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAvgTimeSpentofClassHomeworkText(){
        softAssert.assertEquals(AvgTimeSpentofClassHomeworkText.isDisplayed(),true,"Avg Time Spent of Class Homework Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyClassSincerityScoreOverallHomeworkText(){
        softAssert.assertEquals(ClassSincerityScoreOverallHomeworkText.isDisplayed(),true,"Class Sincerity Score Overall Homework Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyOverallStrongOverallHomeworkText(){
        softAssert.assertEquals(OverallStrongOverallHomeworkText.isDisplayed(),true,"Overall Strong Overall Homework Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAOverallWeakOverallHomeworkText(){
        softAssert.assertEquals(OverallWeakOverallHomeworkText.isDisplayed(),true,"Overall Weak Overall Homework Text VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyQuestionWiseAnalysisHomeworkText(){
        wait(2000);
        softAssert.assertEquals(QuestionWiseAnalysisHomeworkText.isDisplayed(),true,"QuestionWiseAnalysisHomeworkText VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAOverallStrongHomeworkText(){
        softAssert.assertEquals(OverallStrongHomeworkText.isDisplayed(),true,"OverallStrongHomeworkText VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAOverallWeakHomeworkText(){
        softAssert.assertEquals(OverallWeakHomeworkText.isDisplayed(),true,"OverallWeakHomeworkText VALUE Not Displayed");
        softAssert.assertAll();
    }

    public void verifyAchieveAnalysisTabText(){
        softAssert.assertEquals(journeyNameTextOfAchieve.isDisplayed(),true,"journey Name Text Of Achieve VALUE Not Displayed");
        softAssert.assertEquals(assignedDateTextOfAchieve.isDisplayed(),true,"assigned Date Text Of Achieve VALUE Not Displayed");
        softAssert.assertEquals(chapterNameTextOfAchieve.isDisplayed(),true,"chapterNameTextOfAchieve VALUE Not Displayed");
        softAssert.assertEquals(completionTextOfAchieve.isDisplayed(),true,"completion Text Of Achieve VALUE Not Displayed");
        softAssert.assertEquals(classMasteryTextOfAchieve.isDisplayed(),true,"class Mastery Text Of Achieve VALUE Not Displayed");
        softAssert.assertEquals(avgBehaviourTextOfAchieve.isDisplayed(),true,"avg Behaviour Text Of Achieve VALUE Not Displayed");
        softAssert.assertEquals(avgTimeSpendTextOfAchieve.isDisplayed(),true,"avg Time Spend Text Of Achieve VALUE Not Displayed");

        softAssert.assertAll();
    }

    public void verifyAchieveAnalysisTabClassText(){
        softAssert.assertEquals(achieveAnalysisClassTextOfAchieveJourney.isDisplayed(),true,"achieve Analysis Class Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(chapterNameTextOfAchieveJourney.isDisplayed(),true,"chapter Name Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(numberOfTopicsOfAchieveJourney.isDisplayed(),true,"number Of Topics Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(assignedDateTextOfAchieveJourney.isDisplayed(),true,"assigned Date Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(studentTypeTextOfAchieveJourney.isDisplayed(),true,"student Type Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(overallConceptMasteryTextOfAchieveJourney.isDisplayed(),true,"overall Concept Mastery Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(overallStudentsProgressTextOfAchieveJourney.isDisplayed(),true,"overall Students Progress Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(achiveAnalysisTextOfAchieveJourney.isDisplayed(),true,"achive Analysis Text Of Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(studentNameOfTextAchieveJourney.isDisplayed(),true,"student Name Of Text Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(startingMasteryOfTextAchieveJourney.isDisplayed(),true,"starting Mastery Of Text Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(potenstailMasteryOfTextAchieveJourney.isDisplayed(),true,"potenstail Mastery Of Text Achieve Journey VALUE Not Displayed");
        softAssert.assertEquals(currentMasteryOfTextAchieveJourney.isDisplayed(),true,"current Mastery Of Text Achieve Journey VALUE Not Displayed");

        softAssert.assertEquals(achievementsOfTextAchieveJourney.isDisplayed(),true,"achievements  Text Of Achieve VALUE Not Displayed");



        softAssert.assertAll();
    }













}











