package com.embibe.schoolapp.pages.myhome.myclasses;


import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.List;

public class MyClassesPage extends BasePage {

    @FindBy(css = ".classes-left-part >div>div")
    private List<WebElement> myClassList;

    String className="//section[@class='classes-left-part ']//div[text()='%s']";

    String studentCount ="//section[@class='classes-right-part']//div[@title='%s']/following-sibling::div";

    @FindBy(xpath = "//div[contains(text(),'Next Class')]/following-sibling::div")
    private WebElement nextClassSubject;

    @FindBy(xpath = "//div[contains(text(),'Next Class')]")
    private WebElement nextClass;

    @FindBy(xpath = "//div[text()='Pre-Class']/..//div[2]/div")
    private WebElement preClass;

    @FindBy(xpath = "//div[text()='Post-Class']/..//div[2]/div")
    private WebElement postClass;

    @FindBy(xpath = "//div[contains(@id,'highcharts')]")
    private WebElement coverageGraph;

    @FindBy(css = ".tooltip-attendance-icon ")
    private WebElement attendanceIcon;

    @FindBy(css = ".tooltip-mail-icon ")
    private WebElement mailIcon;

    @FindBy(css = ".tooltip-track-icon ")
    private WebElement trackIcon;

    @FindBy(xpath = "//div[text()=' Mastery']/../div[1]")
    private WebElement conceptMastery;

    @FindBy(xpath = "//div[text()='Add Books']")
    private WebElement addBooks;

    @FindBy(xpath = "//button/div[text()='Add']")
    private WebElement addButton;

    @FindBy(xpath = "//div[text()='Add']/..")
    private WebElement addButtonRoot;

    @FindBy(xpath = "//section[contains(@class,' equal-space') ]//img[@class='actual-img progressive-image-loaded']")
    private List<WebElement> selectBooksList;

    @FindBy(xpath ="//div[text()='Books available for this class']/..//section/div")
    private List<WebElement> bookList;

    @FindBy(css = ".tooltip-attendance-icon ")
    private WebElement attendanceButton;

    @FindBy(xpath = "//div[text()='Books available for this class']")
    private WebElement booksAvailableText;

    @FindBy(xpath = "//span[text()='Yes, Delete']")
    private WebElement deleteButton;



    public MyClassesPage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }

    public int getClassList(){
        waitForListOfElementToBeVisible(myClassList);
        return myClassList.size();
    }
    public void clickOnClassName(String currentClass){
        WebElement element = driver.findElement(By.xpath(String.format(className,currentClass)));
        waitForElementToBeVisible(element);
        element.click();
    }
    public String getStudentCount(String subject){
        WebElement element = driver.findElement(By.xpath(String.format(studentCount,subject)));
        waitForElementToBeVisible(element);
        String count = element.getText();
        return count;
    }
    public String getNextClassDetails(){
        waitForElementToBeVisible(nextClass);
        return nextClass.getText();
    }
    public Boolean preClassActionDisplayed(){
        return waitForElementToBeDisplay(preClass);
    }
    public Boolean postClassActionDisplayed(){
        return waitForElementToBeDisplay(postClass);
    }
    public Boolean coverageGraphDisplayed(){
        return waitForElementToBeDisplay(coverageGraph);
    }
    public Boolean attendanceIconDisplayed(){
        return waitForElementToBeDisplay(attendanceIcon);
    }
    public Boolean trackIconDisplayed(){
        return waitForElementToBeDisplay(trackIcon);
    }
    public Boolean mailIconDisplayed(){
        return waitForElementToBeDisplay(mailIcon);
    }
    public Boolean conceptMasteryDisplayed(){
        return waitForElementToBeDisplay(conceptMastery);
    }
    public void myClassesWait(int ms){
        wait(ms);
    }

    public void clickOnAddBooks(){
        waitForElementToBeVisible(addBooks);
        jsClick(addBooks);
    }
    public void clickOnAddButton(){
        if (addButton.isDisplayed() && addButton.isEnabled()){
            addButton.click();
        }
    }

    public void selectBook(){
        wait(5000);
        waitForListOfElementToBeVisible(selectBooksList);
        for (int i = 0; i < selectBooksList.size(); i++) {
            WebElement element = selectBooksList.get(i);
            jsClick(element);
            //element.click();
            wait(2000);
            String value = isAddButtonEnabled();
            System.out.println("the value is "+value);
            if (value == null){
                clickOnAddButton();
                break;
            }
        }
    }
    public String isAddButtonEnabled(){
        return addButtonRoot.getAttribute("disabled");
    }

    public int getBookListSize(){
        waitForListOfElementToBeVisible(bookList);
        return bookList.size();
    }
    public void scrollDown() {
        if (booksAvailableText.isEnabled()) {
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", booksAvailableText);
        }

    }
    public void deleteBook(){
        waitForListOfElementToBeVisible(bookList);
        if (bookList.size()>1){
            for (int i = 0; i <bookList.size() ; i++) {
                WebElement element = bookList.get(i);
                jsClick(element);
                wait(2000);
                clickOnDeleteButton();
                break;
            }
        }
    }
    public void clickOnDeleteButton(){
        waitForElementToBeVisible(deleteButton);
        wait(2000);
        deleteButton.click();
    }
    public void clickOnAttendanceButton(){
        waitForElementToBeVisible(attendanceButton);
        attendanceButton.click();
    }
    public void clickOnMailToThisGroupButton(){
        waitForElementToBeVisible(mailIcon);
        mailIcon.click();
    }
    public boolean verifyPage(String str){
        wait(2000);
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.contains(str);
        return  value;
    }
    public boolean isBooksAvailableHeaderTextDisplayed(){
        return waitForElementToBeDisplay(booksAvailableText);
    }
    public boolean isAddBookOptionIsDisplayed(){
        return waitForElementToBeDisplay(addBooks);
    }


}
