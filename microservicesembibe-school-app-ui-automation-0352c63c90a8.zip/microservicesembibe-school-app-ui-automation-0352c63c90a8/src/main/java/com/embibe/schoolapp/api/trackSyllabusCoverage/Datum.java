
package com.embibe.schoolapp.api.trackSyllabusCoverage;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Datum {

    @SerializedName("timestamp")
    @Expose
    private Long timestamp;
    @SerializedName("planned")
    @Expose
    private Double planned;
    @SerializedName("actual")
    @Expose
    private Double actual;

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public Double getPlanned() {
        return planned;
    }

    public void setPlanned(Double planned) {
        this.planned = planned;
    }

    public Double getActual() {
        return actual;
    }

    public void setActual(Double actual) {
        this.actual = actual;
    }

}
