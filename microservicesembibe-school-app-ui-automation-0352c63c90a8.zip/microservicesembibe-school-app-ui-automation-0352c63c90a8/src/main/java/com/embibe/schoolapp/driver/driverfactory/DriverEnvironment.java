package com.embibe.schoolapp.driver.driverfactory;

public class DriverEnvironment {
    public static final String BROWSERSTACK = "browserStack";
    static final String ZALENIUM = "zalenium";
}
