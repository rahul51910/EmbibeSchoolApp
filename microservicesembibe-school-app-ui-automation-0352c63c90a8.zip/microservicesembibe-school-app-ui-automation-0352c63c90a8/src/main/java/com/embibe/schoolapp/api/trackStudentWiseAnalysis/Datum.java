
package com.embibe.schoolapp.api.trackStudentWiseAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Datum {

    @SerializedName("studentName")
    @Expose
    private String studentName;
    @SerializedName("classRank")
    @Expose
    private Integer classRank;
    @SerializedName("performance")
    @Expose
    private String performance;
    @SerializedName("videosWatched")
    @Expose
    private VideosWatched videosWatched;
    @SerializedName("questionsPracticed")
    @Expose
    private QuestionsPracticed questionsPracticed;
    @SerializedName("testTaken")
    @Expose
    private TestTaken testTaken;
    @SerializedName("totalTime")
    @Expose
    private Double totalTime;
    @SerializedName("studentAccuracy")
    @Expose
    private Double studentAccuracy;

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Integer getClassRank() {
        return classRank;
    }

    public void setClassRank(Integer classRank) {
        this.classRank = classRank;
    }

    public String getPerformance() {
        return performance;
    }

    public void setPerformance(String performance) {
        this.performance = performance;
    }

    public VideosWatched getVideosWatched() {
        return videosWatched;
    }

    public void setVideosWatched(VideosWatched videosWatched) {
        this.videosWatched = videosWatched;
    }

    public QuestionsPracticed getQuestionsPracticed() {
        return questionsPracticed;
    }

    public void setQuestionsPracticed(QuestionsPracticed questionsPracticed) {
        this.questionsPracticed = questionsPracticed;
    }

    public TestTaken getTestTaken() {
        return testTaken;
    }

    public void setTestTaken(TestTaken testTaken) {
        this.testTaken = testTaken;
    }

    public Double getTotalTime() {
        return totalTime;
    }

    public void setTotalTime(Double totalTime) {
        this.totalTime = totalTime;
    }

    public Double getStudentAccuracy() {
        return studentAccuracy;
    }

    public void setStudentAccuracy(Double studentAccuracy) {
        this.studentAccuracy = studentAccuracy;
    }

}
