
package com.embibe.schoolapp.api.show;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Subject {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("bookLists")
    @Expose
    private List<String> bookLists = null;
    @SerializedName("bigBooks")
    @Expose
    private List<Object> bigBooks = null;
    @SerializedName("studentCount")
    @Expose
    private Integer studentCount;
    @SerializedName("subjectKveCode")
    @Expose
    private String subjectKveCode;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public List<String> getBookLists() {
        return bookLists;
    }

    public void setBookLists(List<String> bookLists) {
        this.bookLists = bookLists;
    }

    public List<Object> getBigBooks() {
        return bigBooks;
    }

    public void setBigBooks(List<Object> bigBooks) {
        this.bigBooks = bigBooks;
    }

    public Integer getStudentCount() {
        return studentCount;
    }

    public void setStudentCount(Integer studentCount) {
        this.studentCount = studentCount;
    }

    public String getSubjectKveCode() {
        return subjectKveCode;
    }

    public void setSubjectKveCode(String subjectKveCode) {
        this.subjectKveCode = subjectKveCode;
    }

}
