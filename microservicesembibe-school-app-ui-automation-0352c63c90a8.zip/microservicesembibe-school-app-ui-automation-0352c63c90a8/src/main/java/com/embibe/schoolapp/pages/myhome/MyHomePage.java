package com.embibe.schoolapp.pages.myhome;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyHomePage extends BasePage {

    @FindBy(xpath = "//a[text()='My Home']")
    private WebElement myHome;

    @FindBy(xpath = "//a[text()='Create']")
    private WebElement createButton;

    @FindBy(xpath = "//a[text()='Teach']")
    private WebElement teachButton;

    @FindBy(xpath = "//*[contains(text(),'Lesson Library')]")
    private WebElement lessonLibrary;


    public MyHomePage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void clickOnMyHome(){
        wait(5000);
        jsClick(myHome);
    }
    public void clickLessonLibrary(){
        waitForElementToBeVisible(lessonLibrary);
        jsClick(lessonLibrary);
    }

    public boolean isCreateButtonDisplayed(){
        return waitForElementToBeDisplay(createButton);
    }
    public void clickOnCreate(){
        wait(3000);
        jsClick(createButton);
    }

    public void clickOnTeach(){
        wait(2000);
        jsClick(teachButton);
    }

}
