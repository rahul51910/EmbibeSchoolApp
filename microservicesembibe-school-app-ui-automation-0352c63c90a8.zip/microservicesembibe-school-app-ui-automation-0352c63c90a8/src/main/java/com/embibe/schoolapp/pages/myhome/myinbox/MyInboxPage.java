package com.embibe.schoolapp.pages.myhome.myinbox;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import com.embibe.schoolapp.pages.SchoolAppOps;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

import java.util.*;

public class MyInboxPage extends BasePage {

    @FindBy(xpath = "//div[text()='My Inbox']")
    private WebElement myInbox;

    @FindBy(xpath ="//div[text()='Messages']")
    private WebElement messages;

    @FindBy(xpath = "//div[text()='Files Shared']")
    private WebElement filesShared;

    @FindBy(xpath = "//div[text()='My Students']")
    private WebElement myStudents;

    @FindBy(xpath = "//div[text()='INBOX']")
    private WebElement inbox;

    @FindBy(xpath = "//div[text()='SENT']")
    private WebElement sent;

    @FindBy(xpath = "//div[text()='IMPORTANT']")
    private WebElement important;

    @FindBy(xpath = "//div[text()='DRAFTS']")
    private WebElement drafts;

    @FindBy(xpath = "//div[text()='TRASH']")
    private WebElement trash;

    @FindBy(xpath ="//span[text()='+ Compose']" )
    private WebElement compose;


    @FindBy(xpath = "//span[contains(@class,'head')]")
    private WebElement typeOfMailHeader;

    @FindBy(xpath = "//span[contains(@class,'head')]/following-sibling::span")
    private WebElement typeOfMailDesc;

    @FindBy(xpath = "//div[contains(@class,'message-type-box')][1]/div")
    private WebElement announcement;
    @FindBy(xpath = "//div[contains(@class,'message-type-box')][2]/div")
    private WebElement sendNotice;
    @FindBy(xpath = "//div[contains(@class,'message-type-box')][3]/div")
    private WebElement reportCard;
    @FindBy(xpath = "//div[contains(@class,'message-type-box')][4]/div")
    private WebElement noteInADiary;

    @FindBy(xpath = "//span[contains(@class,'cursor-pointer')]")
    private WebElement typeOfMailEditor;

    @FindBy(css = ".tbody-main>div")
    private List<WebElement>  filesList;

    @FindBy(xpath = "//span[text()='Download']")
    private WebElement download;

    @FindBy(xpath = "//span[text()='Forward']")
    private WebElement forward;

    @FindBy(css = ".tbody-main>.td-row-wrapper:nth-child(1)>.td-row>.td-cell:nth-child(1)")
    private WebElement firstAttachment;

    @FindBy(xpath = "//div[text()='Shared files']")
    private WebElement sharedFilePopupHeader;

    @FindBy(xpath = "//div[@data-tooltip='Mark as important']")
    private WebElement markAsImportant;

    @FindBy(xpath = "//div[@data-tooltip='Select all']/div")
    private WebElement selectAll;

    @FindBy(xpath = "//div[@data-tooltip='Mark all as read']")
    private WebElement markAllAsRead;

    @FindBy(xpath = "//div[@data-tooltip='Delete']")
    private WebElement delete;


    @FindBy(css = ".navigation-block>div:nth-child(1)")
    private WebElement navigateBackward;

    @FindBy(css = ".navigation-block>div:nth-child(3)")
    private WebElement navigateForward;

    @FindBy(css = ".pages-info>div")
    private List<WebElement> totalPages;

    @FindBy(css = ".all-threads>div")
    private List<WebElement> threadList;

    @FindBy(xpath = "//span[text()='To:']/..")
    private WebElement to;

    @FindBy(xpath = "//div[text()='All Students']/../following-sibling::div[1]//div[@class='sender-details']/div")
    private List<WebElement> groupsList;

    @FindBy(xpath ="//div[text()='All Students']/../following-sibling::div[2]//div[@class='sender-details']/div")
    private List<WebElement> studentList;

    @FindBy(xpath = "//span[contains(@class,'cursor-pointer')]/..")
    private WebElement getTypeOfMailTextOnCompose;

    @FindBy(xpath = "//div[contains(@class,'sender-header-title-wrapper')]/div")
    private WebElement getSenderHeaderText;

    @FindBy(xpath = "//div[text()='Groups']")
    private WebElement groups;

    @FindBy(css = ".all-threads>div:nth-child(1)>table>tbody>tr:nth-child(1)>td:nth-child(4)>div>span:nth-child(1)")
    private WebElement getSubjectOfFirstMail;

    @FindBy(xpath = "//div[text()='All Students']/../following-sibling::div[2]//span[text()='Select All']/preceding-sibling::div")
    private WebElement selectAllStudents;

    @FindBy(xpath = "//div[text()='All Students']/../following-sibling::div[1]//span[text()='Select All']/preceding-sibling::div")
    private WebElement selectAllGroups;

    @FindBy(xpath = "//span[text()='Save and Continue']")
    private WebElement saveAndContinue;

    @FindBy(xpath = "//input[@placeholder='Enter Subject']")
    private WebElement enterSubject;

    @FindBy(xpath = "//iframe[@class='cke_wysiwyg_frame cke_reset']")
    private WebElement bodyFrame;

    @FindBy(xpath = "//body[contains(@class,'cke_editable')]")
    private WebElement mailBody;

    @FindBy(xpath = "//div[text()='Send']")
    private WebElement send;

    @FindBy(xpath = "//div[text()='All Students']/../following-sibling::div[2]//div[@class='sender-details']/div[1]/div[2]")
    private WebElement firstStudent;

    @FindBy(css = ".all-threads>div:nth-child(1)>table>tbody>tr:nth-child(1)>td:nth-child(1)>div")
    private WebElement selectFirstMessage;

    @FindBy(css = ".all-threads>div:nth-child(1)>table>tbody>tr:nth-child(1)>td:nth-child(7)>span:nth-child(2)")
    private WebElement deleteFirstMessage;

    @FindBy(css = ".tbody-main>.td-row-wrapper:nth-child(1)>.td-row>div:nth-child(1) div:nth-child(2)")
    private WebElement firstAttachmentName;

    @FindBy(xpath = "//span[text()='Add Student']")
    private WebElement addStudentButton;

    @FindBy(xpath = "//input[@placeholder='First Name']")
    private WebElement firstNameOfAddStudent;

    @FindBy(xpath = "//input[@placeholder='Last Name']")
    private WebElement lastNameOfAddStudent;

    @FindBy(xpath = "//input[@placeholder='Mobile number']")
    private WebElement mobileNumberOfAddStudent;

    @FindBy(xpath = "//div[@class='arrow-icon-wrapper ']")
    private WebElement selectClassArrow;

    @FindBys({@FindBy(xpath = "//div[@class='options']")})
    private List<WebElement> optionOfSelectClass;


    @FindBy(css = ".tbody-main>div")
    private List<WebElement> myClasses;

    @FindBy(xpath = "//div[text()='Today']/../table/tbody/tr")
    private List<WebElement> getTodayMessages;

    @FindBy(xpath = "//div[@class='normal-cell'][1]")
    private WebElement firstNameOfClass;

    @FindBy(xpath = "//*[contains(@title,'Name')]//*[name()='svg']")
    private WebElement nameSort;

    @FindBy(xpath = "(//*[contains(@class,'td-row')])[2]")
    private WebElement className;

    @FindBy(xpath = "//*[contains(@title,'Student Name')]//*[name()='svg']")
    private WebElement studentNameSort;

    @FindBy(xpath = "//span[text()='Submit']")
    private WebElement addStudentButtonOfDetails;








    SchoolAppOps schoolAppOps = new SchoolAppOps();
    public MyInboxPage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void clickOnMyInboxMenu(){
        waitForElementToBeVisible(myInbox);
        myInbox.click();
    }
    public void clickStudentSort(){
        wait(2000);
        waitForElementToBeVisible(studentNameSort);
        studentNameSort.click();
    }
    public void clickSortButton(){
        wait(2000);
        waitForElementToBeVisible(nameSort);
        nameSort.click();
    }
    public void clickClassName(){
        wait(2000);
        waitForElementToBeVisible(className);
        jsClick(className);
    }

    public boolean verifySchedulePageURL(String str){
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.equals(str);
        return  value;
    }

    public boolean isMessagesTabDisplaying(){
        return waitForElementToBeDisplay(messages);
    }
    public boolean isFilesSharedTabDisplaying(){
        return waitForElementToBeDisplay(filesShared);
    }
    public boolean isMyStudentsTabDisplaying(){
        return waitForElementToBeDisplay(myStudents);
    }

    public boolean isInboxTabDisplaying(){
        return waitForElementToBeDisplay(inbox);
    }
    public boolean isSentTabDisplaying(){
        return waitForElementToBeDisplay(sent);
    }
    public boolean isImportantTabDisplaying(){
        return waitForElementToBeDisplay(important);
    }
    public boolean isDraftsTabDisplaying(){
        return waitForElementToBeDisplay(drafts);
    }
    public boolean isTrashTabDisplaying(){
        return waitForElementToBeDisplay(trash);
    }

    public void clickOnCompose(){
        waitForElementToBeVisible(compose);
        compose.click();
        wait(1000);
    }
    public void clickAddStudentButton(){
        waitForElementToBeVisible(addStudentButton);
        jsClick(addStudentButton);

    }
    public void clickAddStudentButtonOfDetails(){
        waitForElementToBeVisible(addStudentButtonOfDetails);
        jsClick(addStudentButtonOfDetails);
        wait(5000);
    }
    public void clickFirstNameOfClass(){
        wait(10000);
        waitForElementToBeVisible(firstNameOfClass);
        jsClick(firstNameOfClass);
    }

    public String getTypeOfMailHeaderText(){
        wait(20000);
        waitForElementToBeVisible(typeOfMailHeader);
        return typeOfMailHeader.getText();
    }
    public String getTypeOfMailDescText(){
        waitForElementToBeVisible(typeOfMailDesc);
        return typeOfMailDesc.getText();
    }

    public String getAnnouncementText(){
        waitForElementToBeVisible(announcement);
        return announcement.getText();
    }
    public String getReportCardText(){
        waitForElementToBeVisible(reportCard);
        return reportCard.getText();
    }
    public String getSendNoticeText(){
        waitForElementToBeVisible(sendNotice);
        return sendNotice.getText();
    }
    public String getNoteInDiaryText(){
        waitForElementToBeVisible(noteInADiary);
        return noteInADiary.getText();
    }
    public void clickOnAnnouncement(){
        waitForElementToBeVisible(announcement);
        announcement.click();
    }
    public void clickOnTypeOfMailEditor(){
        waitForElementToBeVisible(typeOfMailEditor);
        typeOfMailEditor.click();
    }
    public void clickOnFilesShared(){
        waitForElementToBeVisible(filesShared);
        filesShared.click();
    }

    public int getFilesSharedCount(){
        waitForListOfElementToBeVisible(filesList);
        return filesList.size();
    }
    public void clickOnSharedFile(){
        waitForElementToBeVisible(firstAttachment);
        firstAttachment.click();
    }
    public Boolean isSharedFilePopupHeaderDisplaying(){
        wait(3000);
        return  waitForElementToBeDisplay(sharedFilePopupHeader);
    }

    public void clickOnDownload(){
        wait(20000);
        waitForElementToBeVisible(download);
        download.click();
        wait(3000);
    }
    public void clickOnForward(){
        wait(20000);
        waitForElementToBeVisible(forward);
        forward.click();
    }
    public boolean isDownloadButtonIsDisplaying(){
      return waitForElementToBeDisplay(download);
    }
    public boolean isForwardButtonIsDisplaying(){
        return waitForElementToBeDisplay(forward);
    }

    public void clickOnInboxSent(){
        waitForElementToBeVisible(sent);
        sent.click();
    }
    public void clickOnInboxTab(){
        waitForElementToBeVisible(inbox);
        inbox.click();
    }
    public void clickOnTrash(){
        waitForElementToBeVisible(trash);
        trash.click();
    }
    public void clickOnDrafts(){
        waitForElementToBeVisible(drafts);
        drafts.click();
    }
    public void clickOnImportant(){
        waitForElementToBeVisible(important);
        important.click();
    }

    public void clickOnSelectAll(){
        wait(17000);
//        waitForElementToBeClickable(selectAll);
//        selectAll.click();
        jsClick(selectAll);
    }
    public boolean isMarkAsImportantOptionDisplaying(){
        return waitForElementToBeDisplay(markAsImportant);
    }
    public boolean isMarkAsReadOptionIsDisplaying(){
        return waitForElementToBeDisplay(markAllAsRead);
    }
    public boolean isDeleteOptionAvailable(){
        return waitForElementToBeDisplay(delete);
    }
    public String isNavigateForwardActive(){
        scrollToView(navigateForward);
        waitForElementToBeVisible(navigateForward);
        return navigateForward.getAttribute("active");
    }
    public String getNavigateBackActive(){
        scrollToView(navigateForward);
        waitForElementToBeVisible(navigateBackward);
        return navigateBackward.getAttribute("active");
    }
    public void clickOnNavigateForward(){
        scrollToView(navigateForward);
        waitForElementToBeVisible(navigateForward);
        jsClick(navigateForward);
    }
    public void selectRecommendedAllVideo(int value){
        waitForListOfElementToBeVisible(optionOfSelectClass);
        for (int i = 0; i < optionOfSelectClass.size(); i++) {
            WebElement element = optionOfSelectClass.get(i);
            jsClick(element);
            break;
        }


    }
    public boolean verifyIsMessagesAvailable(){
        boolean flag = false;
        try{
//           waitForListOfElementToBeVisible(totalPages,2);
            wait(5000);
           if (totalPages.size()>0){
               flag = true;
           }
        }catch (Exception exception){
            if (getTotalMessagesFromUI()>0){
                flag = true;
            }else {
                flag = false;
            }
            exception.printStackTrace();

        }finally {
            return flag;
        }
    }
    public boolean validateTotalMessages(String collection,String jwtToken){
        boolean flag = false;
        try{
//         waitForListOfElementToBeVisible(totalPages,2);
         if (totalPages.size()>0){
             for (int i =1; i <=totalPages.size(); i++) {
               int totalMessage =  schoolAppOps.getMessages(collection,jwtToken,i,10);
               int totalMessageFromUI = getTotalMessagesFromUI();
               System.out.println("total messages from backend"+totalMessage);
               System.out.println("total messages from UI"+totalMessageFromUI);
               if (totalMessage == totalMessageFromUI){
                   flag = true;

               }else {
                   flag = false;
                   break;
               }
               clickOnNavigateForward();
               wait(2000);
             }
         }
         else {
             flag = false;
         }
        }catch (Exception e){
             if(getTotalMessagesFromUI()>0) {
                int totalMessage = schoolAppOps.getMessages(collection, jwtToken, 1, 10);
                int totalMessageFromUI = getTotalMessagesFromUI();
                System.out.println(totalMessageFromUI);
                System.out.println(totalMessage);
                if (totalMessage == totalMessageFromUI) {
                    flag = true;

                } else {
                    flag = false;
                }
            }
            e.printStackTrace();
        }finally {
            return flag;
        }
    }
    public int getTotalMessagesFromUI(){
        int total = 0;
        try{
//            waitForListOfElementToBeVisible(threadList,5);
            for (int i = 1; i <=threadList.size(); i++) {
                List<WebElement> elements = driver.findElements(By.cssSelector(".all-threads>div:nth-child("+i+")>table>tbody>tr"));
                total = total+ elements.size();
            }
        }catch (Exception exception){
            exception.printStackTrace();

        }finally {
            return total;
        }
    }

    public void clickOnMailTo(){
        waitForElementToBeVisible(to);
        to.click();
    }
    public int getStudentsSizeWhileCompose(){
        waitForListOfElementToBeVisible(studentList);
        return studentList.size();
    }
    public int getGroupsSizeWhileCompose(){
        waitForListOfElementToBeVisible(groupsList);
        return groupsList.size();
    }
    public String getTypeOfMailTypeTextOnCompose(){
        waitForElementToBeVisible(getTypeOfMailTextOnCompose);
        return  getTypeOfMailTextOnCompose.getText();
    }
    public String getSenderHeaderText(){
        waitForElementToBeVisible(getSenderHeaderText);
        return getSenderHeaderText.getText();
    }
    public void clickOnGroups(){
        waitForElementToBeVisible(groups);
        groups.click();
    }
    public String getSubjectOfFirstMail(){
        waitForElementToBeVisible(getSubjectOfFirstMail);
        return getSubjectOfFirstMail.getText();
    }
    public void clickOnSelectAllStudents(){
        waitForElementToBeVisible(selectAllStudents);
        selectAllStudents.click();
    }
    public void clickOnSelectAllGroups(){
        waitForElementToBeVisible(selectAllGroups);
        selectAllGroups.click();
    }
    public void clickOnSaveAndContinue(){
        waitForElementToBeVisible(saveAndContinue);
        saveAndContinue.click();;
    }
    public void setMailSubject(String sub){
        waitForElementToBeVisible(enterSubject);
        enterSubject.sendKeys(sub);
    }
    public void setMailBody(String body){
        WebElement element = driver.findElement(By.tagName("iframe"));
        driver.switchTo().frame(element);
        waitForElementToBeVisible(mailBody);
        mailBody.sendKeys(body);
        driver.switchTo().defaultContent();
    }
    public void clickOnSend(){
        waitForElementToBeVisible(send);
        send.click();
    }
    public void selectSingleStudent(){
       waitForElementToBeVisible(firstStudent);
       firstStudent.click();
    }
    public void selectFirstMessage(){
        waitForElementToBeVisible(selectFirstMessage);
        selectFirstMessage.click();
    }
    public void deleteFirstMessage(){
        waitForElementToBeVisible(deleteFirstMessage);
        deleteFirstMessage.click();
        wait(3000);
    }
    public String getFirstAttachmentName(){
        waitForElementToBeVisible(firstAttachmentName);
        return firstAttachmentName.getText();
    }
    public void clickOnMyStudents(){
        waitForElementToBeVisible(myStudents);
        myStudents.click();
        wait(5000);
    }
    public int getClassCount(){
        waitForListOfElementToBeVisible(myClasses);
        return myClasses.size();
    }

    public Set<String> getClassNames(){
        Set<String> set = new LinkedHashSet<>();
        waitForListOfElementToBeVisible(myClasses);
        for (int i = 1; i <=myClasses.size() ; i++) {
            WebElement element = driver.findElement(By.cssSelector(".tbody-main .td-row-wrapper:nth-child("+i+") .td-row .td-cell:nth-child(1) >div>div>div"));
            set.add(element.getText());
        }
        return set;
    }
    public Set<String> getSubjectsNames(){
        Set<String> set = new LinkedHashSet<>();
        waitForListOfElementToBeVisible(myClasses);
        for (int i = 1; i <=myClasses.size() ; i++) {
            WebElement element = driver.findElement(By.cssSelector(".tbody-main .td-row-wrapper:nth-child("+i+") .td-row .td-cell:nth-child(2) >div>div>div"));
            set.add(element.getText());
        }
        return set;
    }
    public Set<String> getStudentStrength(){
        Set<String> set = new LinkedHashSet<>();
        waitForListOfElementToBeVisible(myClasses);
        for (int i = 1; i <=myClasses.size() ; i++) {
            WebElement element = driver.findElement(By.cssSelector(".tbody-main .td-row-wrapper:nth-child("+i+") .td-row .td-cell:nth-child(3) >div>div>div"));
            set.add(element.getText());
        }
        return set;
    }
    public String getStudentStrengthByClass(String className){
        WebElement element = driver.findElement(By.xpath("//div[text()='"+className+"']/../../../../div[3]/div/div/div"));
        waitForElementToBeVisible(element);
        return element.getText();
    }
    public void clickOnClassName(String className){
        WebElement element = driver.findElement(By.xpath("//div[text()='"+className+"']"));
        waitForElementToBeVisible(element);
        wait(2000);
        element.click();
        wait(2000);
    }
    public boolean getStudentNames(Map<String, Map<String,Object>> myClassesMap,String resellerJWTToken){
        boolean flag = false;
        Set<String> classes = myClassesMap.keySet();
        for (String className:classes) {
            Map<String,Object> classDetails = myClassesMap.get(className);
            String classId = classDetails.get("classId").toString();
            String subjectKvCode = classDetails.get("subjectKvCode").toString();
            Map<String,List<String>> allStudents = schoolAppOps.getStudentDetails(resellerJWTToken,classId,subjectKvCode);
            WebElement element = driver.findElement(By.xpath("//div[text()='"+className+"']"));
            element.click();
                List<String> list = new ArrayList<>();
                List<WebElement> totalStudents = driver.findElements(By.xpath("//div[text()='"+className+"']/../../../../following-sibling::div//div[@class='tbody-main']/div"));
                for (int j = 1; j <=totalStudents.size(); j++) {
                   try{
                       WebElement student = driver.findElement(By.xpath("//div[text()='"+className+"']/../../../../following-sibling::div//div[@class='tbody-main']/div["+j+"]/div/div[3]/div/div/div"));
                       list.add(student.getText());
                   }catch (Exception e){

                   }
                }
                if(list.containsAll(allStudents.get(classId))){
                    flag = true;
                }else {
                    flag = false;
                }
        }
    return flag;
    }
    public int getTodayMessagesCount(){
        int total =0;
        wait(5000);
        try{
            waitForListOfElementToBeVisible(getTodayMessages);
            total =getTodayMessages.size();
        }catch (Exception e){
            total =0;
        }
        finally {
            return total;
        }

    }
    public void selectTheClassArrow(){
        waitForElementToBeVisible(selectClassArrow);
        jsClick(selectClassArrow);
    }

    public void scrollDown() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("window.scrollBy(0,1000)", "");
        wait(2000);
    }
    public void selectAndEnterFirstName(String name){
        wait(3000);
        waitForElementToBeVisible(firstNameOfAddStudent);
        jsClick(firstNameOfAddStudent);
        firstNameOfAddStudent.clear();
        firstNameOfAddStudent.sendKeys(name);


    }
    public void selectAndEnterLastName(String name){
        wait(3000);
        waitForElementToBeVisible(lastNameOfAddStudent);
        jsClick(lastNameOfAddStudent);
        lastNameOfAddStudent.clear();
        lastNameOfAddStudent.sendKeys(name);


    }
    public void selectMobileNumber(String number){


        wait(3000);
        waitForElementToBeVisible(mobileNumberOfAddStudent);
        jsClick(mobileNumberOfAddStudent);
        mobileNumberOfAddStudent.sendKeys(number);

    }
    public String randomMobileNumberGenerate(){
        Random rd = new Random();
        int rdNum;
        String m = "";
        for(int i = 0; i < 10; i++){
            rdNum = rd.nextInt(10);
            m  = m+Integer.toString(rdNum);

        }
        System.out.println(m);
        return m;
    }
    public String numberVerification(){
        String s = String.valueOf(driver.findElement(By.xpath("//*[contains(text(),'"+randomMobileNumberGenerate()+"')]")));
        System.out.println(s);
        return s;



    }
    public void waitingScreen(){
        wait(10000);
    }
}
