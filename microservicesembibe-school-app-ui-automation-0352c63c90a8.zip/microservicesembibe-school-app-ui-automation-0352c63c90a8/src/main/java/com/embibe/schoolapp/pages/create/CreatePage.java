package com.embibe.schoolapp.pages.create;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class CreatePage extends BasePage {
    SoftAssert softAssert=null;



    @FindBy(xpath = "//div[text()='Choose a class to Teach']")
    private WebElement createPageText;

    @FindBy(xpath = "//div[contains(@class,'content-grid-wrapper')]/div")
    private List<WebElement> timeTableDays;



    @FindBy(xpath = "//span[text()='Yes, Delete']")
    private WebElement yesDelete;

    @FindBy(xpath = "//div[contains(@class,'period-slot-container')]")
    private List<WebElement> totalAllottedPeriodsOnCurrentWeek;


    @FindBy(xpath = "//div[contains(@class,'tt-main-content')]/div/div[1]/div")
    private List<WebElement> totalPeriodsForTheDay;

    @FindBy(xpath = "//div[text()='No Topics Selected']")
    private List<WebElement> noTopicsSelected;

    @FindBy(xpath = "//div[contains(@class,'name-wrapper')]/div")
    private WebElement  topicName;

    @FindBy(xpath = "//div[contains(@class,'schedule-tab')]/div[1]")
    private WebElement preAndPostActionsTab;

    @FindBy(xpath = "//div[contains(@class,'schedule-tab')]/div[1]")
    private WebElement viewLessonTab;

    @FindBy(xpath = "//div[text()='Pre and Post Class Actions']")
    private WebElement preandPostActionsTab;

    @FindBy(xpath = "//div[text()='POST-CLASS ACTIONS']/following-sibling::div")
    private List<WebElement> postClassActions;

    @FindBy(xpath = "//div[text()='PRE-CLASS ACTIONS']/following-sibling::div")
    private List<WebElement> preClassActions;



    @FindBy(xpath = "//div[@class='picture']")
    private List<WebElement> layoutTemplates;

    @FindBy(xpath = "//div[text()='Choose Topic & Create a Lesson']")
    private WebElement createLesson;

    @FindBy(xpath = "//div[text()='Create Blank Lesson']")
    private WebElement createBlankLesson;

    @FindBy(xpath = "//div[text()='Change the Topic']/..")
    private WebElement changeTopic;

    @FindBy(xpath = "//*[contains(text(),'Save & Leave')]")
    private WebElement saveAndLeave;

    @FindBy(xpath = "//div[text()='Continue to Create Lesson']/..")
    private WebElement continueToCreateLesson;

    @FindBy(xpath = "//div[text()='Continue to Edit Lesson']/..")
    private WebElement continueToEditLesson;

    @FindBy(xpath = "(//div[@class='assignment-title'])[1]")
    private WebElement titleOfAssignment;



    @FindBy(css = ".el-title")
    private WebElement selectBookTitle;

    @FindBy(css = ".el-desc-title:nth-child(1)")
    private WebElement bookTitle;

    @FindBy(css = ".el-desc-title:nth-child(2)")
    private WebElement authorName;

    @FindBy(css = ".el-c-s")
    private WebElement className;

    @FindBy(xpath = "//div[@class='el-c-s']/following-sibling::div/div[1]/div")
    private WebElement videoDuration;

    @FindBy(xpath = "//div[@class='el-c-s']/following-sibling::div/div[2]/div")
    private WebElement bookDuration;

    @FindBy(xpath = "//div[@role='dialog']//div[@class='nl-h']")
    private WebElement cooboCreateLessonHeader;

    @FindBy(xpath = "//span[text()='Back to Lesson']")
    private WebElement blankButton;

    @FindBy(css = ".sp-cards>div")
    private List<WebElement> recommendedAssets;

    @FindBy(css = ".slide-plus-icon:nth-child(1)")
    private WebElement addSlide;

    @FindBy(xpath = "//span[text()='Save']")
    private WebElement save;

    //@FindBy(xpath = "//div[contains(@class,'p-s-title')]")
    @FindBys(@FindBy(xpath = "//div[contains(@class,'p-s-title')]"))
    private List<WebElement> totalPeriods;

    @FindBy(css = ".duration")
    private WebElement slidesCount;

    @FindBy(css = ".slides-wrapper>div")
    private List<WebElement> totalSides;

    @FindBy(xpath = "//img[@class = 'icon-m-a']")
    private WebElement moreAction;

    @FindBy(xpath = "//div[contains(@class,'dropdownContainer')]/div[1]")
    private WebElement editTopic;

    @FindBy(xpath = "//div[@class='d-flex align-items-center']")
    private WebElement editLesson;

    @FindBy(xpath = "//div[contains(@class,'dropdownContainer')]/div[3]")
    private WebElement deleteLesson;

    @FindBy(css =".main-title")
    private WebElement getEditTopicTitle;

    @FindBy(xpath = "//span[text()='OK, Continue']")
    private WebElement okButton;

    @FindBy(xpath = "//span[text()='Assign Homework']")
    private WebElement assignHomeworkButton;

    @FindBy(xpath = "//div[text()='Mark Completed']")
    private WebElement markCompleted;


    @FindBy(xpath = "//div[text()='Publish Lesson']")
    private WebElement publishLesson;

    @FindBy(xpath = "//div[text()='Unpublish Lesson']")
    private WebElement unpublishLesson;

    @FindBy(xpath = "//div[text()='Back to Period']")
    private WebElement backToPeriod;

    @FindBy(xpath = "(//*[name()='i' and @class ='slide-plus-icon'] )[1]")
    private WebElement addSlideButton;

    @FindBy(xpath = "//*[name()='div'  and @data-tip='Delete slide']")
    private WebElement deleteButtonOfSlide;

    @FindBy(xpath = "//*[name()='div'  and @data-tip='Toggle visibility']" )
    private WebElement toggleVisibilityOfSlide;

    @FindBy(xpath = "//*[name()='div'  and @data-tip='Duplicate slide']" )
    private WebElement duplicateSlideOfSlide;

    @FindBy(xpath = "//*[name()='div'  and @data-tip='Slide background']" )
    private WebElement slideBackgroundOfSlide;

    @FindBy(xpath = "//*[name()='div'  and @data-tip='Teacher notes']" )
    private WebElement teacherNotesOfSlide;

    @FindBy(xpath = "//div[text()='Recommended']")
    private WebElement recommendedOfSlide;

    @FindBy(xpath = "//div[text()='Templates']")
    private WebElement templatesOfSlide;

    @FindBy(xpath = "//div[text()='Text']")
    private WebElement textOfSlide;

    @FindBy(xpath = "//div[text()='Image']")
    private WebElement ImageOfSlide;

    @FindBy(xpath = "//div[text()='Video']")
    private WebElement VideoOfSlide;

    @FindBy(xpath = "//div[text()='3D Model']")
    private WebElement threeDModelOfSlide;

    @FindBy(xpath = "//div[text()='Question']" )
    private WebElement questionOfSlide;

    @FindBy(xpath = "//div[text()='Extras']" )
    private WebElement extrasOfSlide;

    @FindBy(xpath = "//div[text()='Help']")
    private WebElement helpOfSlide;

    @FindBys({@FindBy(xpath = "//div[@class='asset-img-section animation-hidden media-preloader-new media-preloader is-loading']")})
    private List<WebElement> recommendedImages;

    @FindBys({@FindBy(xpath = "//div[@class='sp-card-wrapper ']")})
    private List<WebElement> recommendedVideos;



    @FindBy(xpath = "//span[text()='Preview']")
    private WebElement previewOfSlide;


    @FindBy(xpath = "(//div[text()='View all '])[1]")
    private WebElement viewAllofSlide;

    @FindBy(xpath = "//*[contains(@class,'btn-right')]")
    private WebElement mobileViewOfSlide;

    @FindBy(xpath = "//*[contains(text(),'Desktop')]")
    private WebElement desktopViewOfSlide;

    @FindBy(xpath = "//*[contains(text(),'Back to editor')]")
    private  WebElement backToEditorOfSlide;

    @FindBy(xpath = "(//div[@class='sp-card'])")
    private List<WebElement> recommendedAllVideo;

    @FindBy(xpath = "//div[@class='sc-fznzqM kcMtBa checkbox checkbox-main ']")
    private List<WebElement> choosePracticeContentOptions;

    @FindBys({@FindBy(xpath = "//div[@class='topic font-size-16 font-weight-600 cursor-pointer']")})
    private List<WebElement> openChoosePracticeContentOptions;

    @FindBy(xpath = "//div[text()='Create']")
    private WebElement CreateButton;

    @FindBy(xpath = "//div[@class='quiz-result']")
    private List<WebElement> recommendedQuestions;

    @FindBy(xpath="//div[text()='View All Results']")
    private WebElement viewAllResults;

    @FindBy(xpath ="//div[@class='templates-item ']")
    private List<WebElement> themes;

    @FindBys({@FindBy(xpath = "//i[@class='layout-icon ']")})
    private List<WebElement> activeThemes;

    @FindBy(xpath = "//div[text()='Title']")
    private WebElement titleOfText;

    @FindBy(xpath = "//*[contains(text(),'Copy')]")
    private WebElement meetlink;

    @FindBy(xpath = "//*[contains(text(),'Start Teaching')]")
    private WebElement startTeaching;
    @FindBy(xpath = "//div[text()='Body']")
    private WebElement bodyOfText;

    @FindBy(xpath = "//div[text()='Chemistry']")
    private WebElement formulasOfText;

    @FindBy(xpath = "//div[@class='d-flex']")
    private List<WebElement> tableOfText;

    @FindBy(xpath = "//img[@class='asset-card-img']")
    private List<WebElement> recommendedImageOfImages;

    @FindBy(xpath = "//div[@class='option']")
    private List<WebElement> CategoriesAndLanguageOfVideo;

    @FindBy(xpath = "//div[@class='anim-thumbs ']")
    private List<WebElement> VideoOfVideo;

    @FindBy(xpath = "//div[text()='Upload']")
    private WebElement upload;

    @FindBy(xpath = "//div[@class='sp-card']")
    private List<WebElement> ThreeDModelAnimationModels;

    @FindBy(xpath="//div[@class='quiz-result']")
    private List<WebElement> QuestionOfQuestionSlide;

    @FindBy(xpath = "//button[@class='editor-radio-option ']")
    private List<WebElement> difficultyLevelOfQuestionSlide;

    @FindBy(xpath = "//div[text()='Custom']")
    private WebElement customeQuiz;

    @FindBy(xpath = "(//*[contains(@id,'Layer_1')])[2]")
    private WebElement nextcalanderArrow;

    @FindBy(xpath = "on-off-button ")
    private WebElement onOfButton;

    @FindBy(xpath = "//div[@class='card-wrapper sp-card']")
    private  List<WebElement> extrasOfExtraSlide;

    @FindBy(xpath = "//div[@role=\"textbox\"]")
    private WebElement textEnter;
    ////*[@id="main-texteditor"]/div/div/div/div[2]/div[2]/div/p

    @FindBy(xpath = "//div[text()='SET HOMEWORK']")
    private WebElement setHomework;

    @FindBy(xpath = "(//div[text()='CREATE YOUR OWN'])[1]")
    private WebElement setHomeworkCreateYourOwn;

    @FindBy(xpath = "(//span[text()='All 0 Topics covered so far in this Chapter: Light : Reflection and Refraction'])")
    private WebElement All0TopicFromConfirmSyllabus;

    @FindBys({@FindBy(xpath = "//span[@class='font-size-14 font-weight-500 margin-14']")})
    private List<WebElement> confirmSyllabus;

    @FindBy(xpath = "//span[text()='Save & Continue']")
    private WebElement saveAndContinue;

    @FindBys({@FindBy(xpath = "//div[@class='tile-mask']")})
    private List<WebElement> chooseLearnContentOptions;


    @FindBy(xpath = "//input[@placeholder=\"Please Enter homework Name\"]")
    private WebElement enterHomeworkName;

    @FindBys({@FindBy(xpath = "//div[@class='progressive-img-cont scale-height']")})
    private List<WebElement> selectBook;


    @FindBys({@FindBy(xpath="//div[@class='sc-pRDlx gLUvDa']//div[@class='inner-circle']")})
    private List<WebElement> selectActivity;

    @FindBy(xpath = "//div[text()='SET TEST']")
    private WebElement SelectSetTest;

    @FindBy(xpath = "(//div[text()='EMBIBE '])[2]")
    private WebElement embibePreset;

    @FindBy(xpath = "//span[text()='Assign Test']")
    private WebElement assignTestButton;

    @FindBy(xpath = "//span[text()='Done']")
    private WebElement doneButton;

    @FindBy(xpath = "//span[text()='Previous']")
    private WebElement previousButton;

    @FindBy(xpath = "//span[text()='Change ']")
    private WebElement changeChapterOfShowTest;

    @FindBys({@FindBy(xpath = "//div[@class='sc-fznzqM kcMtBa checkbox checkbox-main each-option-checkbox']")})
    private List<WebElement> chapterOfBook;

    @FindBy(xpath = "//span[text()='Save']")
    private WebElement saveButton;

    @FindBys({@FindBy(xpath = "//div[text()='Show']")})
    private List<WebElement> showButton;

    @FindBy(xpath = "//div[text()='Hide']")
    private WebElement hideButton;

    @FindBy(xpath = "//*[contains(text(),'Add')]")
    private WebElement addQuestionButton;

    @FindBys({ @FindBy(xpath = "//img[@class='preload-img blur']")})
    private List<WebElement> showVideosOfChapter;

    @FindBy(xpath = "//span[text()='Cancel']")
    private WebElement cancelButtonOfChangeChapter;

    @FindBy(xpath = "//div[text()='Step 3 - Select Activity']")
    private WebElement selectActivityText;

    @FindBy(xpath = "//span[text()='Initiate Achieve Journey']")
    private WebElement initiateAchieveJourneyButton;

    @FindBy(xpath = "//span[text()='Set Adaptive Practice']")
    private WebElement setAdaptivePracticeButton;

    @FindBy(xpath = "//*[name()='path' and contains(@d,'M41 20.5C4')]")
    private WebElement settingOfMeetingTeacherside;

    @FindBy(xpath = "//*[contains(text(),'Done')]")
    private WebElement donebutton;

    @FindBy(xpath = "//*[name()='circle' and contains(@cx,'25')]")
    private WebElement videoOfMeet;

    @FindBy(xpath = "//div[@class='welcome-modal__video-controls']//div[3]//*[name()='svg']")
    private WebElement micOfMeet;

    @FindBy(xpath = "(//*[contains(text(),'Start')])[2]")
    private WebElement startTheClassButton;

    @FindBy(xpath = "//*[contains(text(),'Unlock room')]")
    private WebElement unlockRoom;

    @FindBy(xpath = "//*[contains(text(),' Mute all')]")
    private WebElement muteAll;

    @FindBy(xpath = "//*[contains(text(),'Lower All Hands')]")
    private WebElement lowerAllHands;

    @FindBy(xpath = "//*[contains(text(),'Lesson')]")
    private WebElement lessonData;

    @FindBys({@FindBy(xpath = "//*[contains(@class,'sc-qXFrf izcutE')]//*[contains(@class,' checkbox  checkbox-main')]")})
    private List<WebElement> selectChapters;

    @FindBys({@FindBy(xpath = "//*[contains(@class,'sc-qXFrf jiZlaA')]//*[contains(@class,' checkbox  checkbox-main')]")})
    private List<WebElement> selectTopic;












    public void clickTitle(){

        jsClick(titleOfText);
    }
    public void clickAddButton(){
        jsClick(addQuestionButton);
    }

    public void clickDoneButtonOfTeachMeet(){
        waitForElementToBeVisible(donebutton);
        jsClick(donebutton);
    }

    public void clickStartTheClassButton(){
        waitForElementToBeVisible(startTheClassButton);
        jsClick(startTheClassButton);
    }
    public void clicksettingOfMeetingTeacherside(){
        waitForElementToBeVisible(settingOfMeetingTeacherside);
        jsClick(settingOfMeetingTeacherside);
    }
    public void clickStartTeaching(){
        waitForElementToBeVisible(startTeaching);
        jsClick(startTeaching);
    }
    public void clickInitiateAchieveJourneyButton(){
        waitForElementToBeVisible(initiateAchieveJourneyButton);
        jsClick(initiateAchieveJourneyButton);
    }
    public void clickSaveAndLeave(){
        wait(5000);
        waitForElementToBeVisible(saveAndLeave);
        jsClick(saveAndLeave);
    }

    public void clickMeetLink(){
        waitForElementToBeVisible(meetlink);
        jsClick(meetlink);
    }
    public void clickSetAdaptivePracticeButton(){
        waitForElementToBeVisible(setAdaptivePracticeButton);
        jsClick(setAdaptivePracticeButton);
    }

    public void clickNextCalanderArrow(){
        wait(5000);
        waitForElementToBeVisible(nextcalanderArrow);
        //jsClick(nextcalanderArrow);
        nextcalanderArrow.click();
        wait(5000);
    }

    public void clickCancelButton(){
        jsClick(cancelButtonOfChangeChapter);
    }
    public void clickHideButton(){
        jsClick(hideButton);
    }
    public void clickChangeChapterOfShowTest(){
        wait(2000);
        waitForElementToBeVisible(changeChapterOfShowTest);
        jsClick(changeChapterOfShowTest);
    }
    public void clickAssignHomeworkButton(){
        waitForElementToBeVisible(assignHomeworkButton);
        wait(3000);
        jsClick(assignHomeworkButton);
    }

    public void clickSetHomework(){
        jsClick(setHomework);
    }
    public void clickPreviousButton(){
        waitForElementToBeVisible(previousButton);
        jsClick(previousButton);
    }
    public void selectCreateYourOwnFromSetHomeWork(){
        waitForElementToBeVisible(setHomeworkCreateYourOwn);
        wait(2000);
        jsClick(setHomeworkCreateYourOwn);
        wait(15000);
    }
    public void clickEmbibePreset(){
        wait(2000);
        waitForElementToBeVisible(embibePreset);
        jsClick(embibePreset);
    }
    public void clickSaveButton(){
        wait(2000);
        waitForElementToBeVisible(saveButton);
        jsClick(saveButton);
    }
    public void clickDoneButton(){
        waitForElementToBeVisible(doneButton);
        jsClick(doneButton);
    }
    public void clickAssignTestButton(){
        waitForElementToBeVisible(assignTestButton);
        jsClick(assignTestButton);
    }
    public void selectAll0TopicFromConfirmSyllabus(){

        waitForElementToBeVisible(All0TopicFromConfirmSyllabus);
        jsClick(All0TopicFromConfirmSyllabus);
    }
    public void ClickSetTest(){
        waitForElementToBeVisible(SelectSetTest);

        jsClick(SelectSetTest);
    }
    public void clickOnSaveAndContinue(){
        wait(2000);
        waitForElementToBeVisible(saveAndContinue);
        jsClick(saveAndContinue);
        wait(10000);
    }
    public void selectMobileView(){
        wait(5000);
        jsClick(mobileViewOfSlide);
        //mobileViewOfSlide.click();

    }
    public void selectDesktopView(){
        wait(3000);
        jsClick(desktopViewOfSlide);}
    public void selectAndEnterHomeworkName(String homeworkname){
        wait(3000);
        waitForElementToBeVisible(enterHomeworkName);
        jsClick(enterHomeworkName);
        enterHomeworkName.clear();
        enterHomeworkName.sendKeys(homeworkname);


    }


    public void TitleText(){
        wait(3000);
        jsClick(textEnter);
        //textEnter.click();
        wait(3000);
        waitForElementToBeVisible(textEnter);


        textEnter.sendKeys("Title name can be any thing ");

    }
    public void clickBodyOfText(){
        wait(3000);
        jsClick(bodyOfText);
    }
    public void bodyOfText(){
        wait(3000);
        textEnter.sendKeys("New Body is been selected");
    }

    public void selectformulasOfText(){
        waitForElementToBeVisible(formulasOfText);
        jsClick(formulasOfText);
    }
    public void selectPreview(){jsClick(previewOfSlide);}
    public void clickBackToSlide(){jsClick(backToEditorOfSlide);}


    public void chooseAnyOfLearnContentOptions(int value){
        waitForListOfElementToBeVisible(chooseLearnContentOptions);
        for (int i = 0; i < chooseLearnContentOptions.size(); i++) {
            WebElement element = chooseLearnContentOptions.get(i);
            wait(5000);
            jsClick(element);
            break;
        }


    }
    public void chooseChaptersFromTheList(int value){
        waitForListOfElementToBeVisible(selectChapters);
        for (int i = 0; i < selectChapters.size(); i++) {
            WebElement element = selectChapters.get(i);
            wait(5000);
            jsClick(element);
            break;
        }


    }
    public void chooseTopicFromTheList(int value){
        waitForListOfElementToBeVisible(selectTopic);
        for (int i = 0; i < selectTopic.size(); i++) {
            WebElement element = selectTopic.get(i);
            wait(5000);
            jsClick(element);
            break;
        }


    }
    public void chooseTemplateLayoutOptions(int value){
        waitForListOfElementToBeVisible(activeThemes);
        for (int i = 0; i < activeThemes.size(); i++) {
            WebElement element = activeThemes.get(i);
            wait(5000);
            jsClick(element);
            break;
        }


    }
    public void chooseConfirmSyllabusOptions(int value){
        waitForListOfElementToBeVisible(confirmSyllabus);
        for (int i = 0; i < confirmSyllabus.size(); i++) {
            if (i ==value){
            WebElement element = confirmSyllabus.get(i);
            wait(5000);
            jsClick(element);
            break;
        }}


    }
    public void chooseSelectActivityOptions(int value){
        wait(5000);
        waitForListOfElementToBeVisible(selectActivity);
        for (int i = 0; i < selectActivity.size(); i++) {
            if (i ==value){


            WebElement element = selectActivity.get(i);
            jsClick(element);
            break;
        }}


    }
    public void OpenTheChoosePracticeContentOptions(int value){
        wait(5000);
        waitForListOfElementToBeVisible(openChoosePracticeContentOptions);
        for (int i = 0; i < openChoosePracticeContentOptions.size(); i++) {
            if (i ==value){


                WebElement element = openChoosePracticeContentOptions.get(i);
                jsClick(element);
                break;
            }}


    }

    public void SelectVideoOfChapter(int value){
        waitForListOfElementToBeVisible(showVideosOfChapter);
        for (int i = 0; i < showVideosOfChapter.size(); i++) {
            if (i ==value){
            WebElement element = showVideosOfChapter.get(i);
            waitForElementToBeVisible(element);
            jsClick(element);
            break;
        }}


    }
    public void SelectChapterOfTheBook(int value){
        wait(2000);
        waitForListOfElementToBeVisible(chapterOfBook);
        for (int i = 0; i < chapterOfBook.size(); i++) {
            if (i ==value){
            WebElement element = chapterOfBook.get(i);
            waitForElementToBeVisible(element);
            jsClick(element);
            break;
        }}


    }
    public void chooseShowButtonOptions(int value){
        waitForListOfElementToBeVisible(showButton);
        for (int i = 0; i < showButton.size(); i++) {
            if (i ==value){
            WebElement element = showButton.get(i);
            jsClick(element);
            break;
        }}


    }
    public void selectBook(int value){
        wait(10000);
        waitForListOfElementToBeVisible(selectBook);
        for (int i = 0; i < selectBook.size(); i++) {
            if (i ==value){
            WebElement element = selectBook.get(i);
            jsClick(element);
            break;
        }}


    }
    public void chooseAnyOfPracticeContentOptions(int value){
        wait(2000);
        waitForListOfElementToBeVisible(choosePracticeContentOptions);
        for (int i = 0; i < choosePracticeContentOptions.size(); i++) {
            if (i ==value){
            WebElement element = choosePracticeContentOptions.get(i);
            jsClick(element);
            break;
        }}


    }
    public void selectExtrasOfExtraSlide(int value){
        waitForListOfElementToBeVisible(extrasOfExtraSlide);
        for (int i = 0; i < extrasOfExtraSlide.size(); i++) {
            if (i ==value){
            WebElement element = extrasOfExtraSlide.get(i);
            jsClick(element);
            break;
        }}


    }


    public void selectDifficultyLevelOfQuestionSlide(int value){
        waitForListOfElementToBeVisible(difficultyLevelOfQuestionSlide);
        for (int i = 0; i < difficultyLevelOfQuestionSlide.size(); i++) {
            if (i ==value){
            WebElement element = difficultyLevelOfQuestionSlide.get(i);
            jsClick(element);
            break;
        }}


    }














    public CreatePage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
        softAssert=new SoftAssert();

    }
    public boolean verifyCreatePageURL(String str){
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.equals(str);
        return  value;
    }

    public String getCreatePageText(){
        waitForElementToBeVisible(createPageText);
        return createPageText.getText();
    }
    public int getTimeTableDays(){
        waitForListOfElementToBeVisible(timeTableDays);
        return timeTableDays.size();
    }
    public void addNewSlideToPage(){
        wait(5000);
        jsClick(addSlideButton);
    }
    public void deleteSlideOnPage(){
        wait(5000);
        jsClick(deleteButtonOfSlide);
    }

    public void clickCreateButtonOnPage(){
        waitForElementToBeVisible(CreateButton);
        jsClick(CreateButton);
    }

    public int getTotalAllottedPeriods(){
        waitForListOfElementToBeVisible(totalAllottedPeriodsOnCurrentWeek);
        return totalAllottedPeriodsOnCurrentWeek.size();
    }
    public int getTotalPeriodsPerDay(){
        int total= 0;
        try {
            waitForListOfElementToBeVisible(totalPeriodsForTheDay);
            total= totalPeriodsForTheDay.size();
        }catch (Exception e){

        }finally {
            return  total;
        }

    }
    public int getNoTopicsSelectedPeriods(){
        int total =0;
        try{
//            waitForListOfElementToBeVisible(noTopicsSelected);
            total = noTopicsSelected.size();
        }catch (Exception e){

        }finally {
            return total;
        }

    }
    public void clickOnNoTopicSelectedPeriod(){
        waitForListOfElementToBeVisible(noTopicsSelected);
        for (int i = 0; i < noTopicsSelected.size(); i++) {
            WebElement element = noTopicsSelected.get(i);
            jsClick(element);
            break;
        }
    }
    public void selectLayoutTemplates(int value){
        waitForListOfElementToBeVisible(layoutTemplates);
        for (int i = 0; i < layoutTemplates.size(); i++) {
            WebElement element = layoutTemplates.get(i);
            jsClick(element);
            break;
        }

    }

    public String getTopicName(){
        waitForPageToLoad();
        waitForElementToBeVisible(topicName);
        return topicName.getText();
    }
    public String getPreAndPostActionsTabText(){
        waitForElementToBeVisible(preandPostActionsTab);
        return preandPostActionsTab.getText();
    }
    public String getViewLessonTabText(){
        waitForElementToBeVisible(viewLessonTab);
        return viewLessonTab.getText();
    }
    public void clickOnPreAndPostActionTab(){
        waitForElementToBeVisible(preAndPostActionsTab);
        preAndPostActionsTab.click();
    }

    public void clickOnViewLessonTab(){
        waitForElementToBeVisible(viewLessonTab);
        jsClick(viewLessonTab);
    }

    public boolean isViewLessonTabAvailable(){
        return waitForElementToBeDisplay(viewLessonTab);
    }

    public List<String> getAllPreClassActions(){
        List<String> preActList = new ArrayList<>();
        jsClick(preandPostActionsTab);
        waitForListOfElementToBeVisible(preClassActions);
        for (int i = 1; i <=preClassActions.size() ; i++) {
            WebElement element = driver.findElement(By.xpath("//div[text()='PRE-CLASS ACTIONS']/following-sibling::div["+i+"]/div[1]"));
            preActList.add(element.getText().trim().split("\n")[0]);
        }
        return preActList;

    }
    public List<String> getAllPostClassActions(){
        List<String> postActList = new ArrayList<>();
        preandPostActionsTab.click();
        //jsClick(preandPostActionsTab);
        waitForListOfElementToBeVisible(postClassActions);
        for (int i = 1; i <=postClassActions.size() ; i++) {
            WebElement element = driver.findElement(By.xpath("//div[text()='POST-CLASS ACTIONS']/following-sibling::div["+i+"]/div[1]"));
            postActList.add(element.getText().trim().split("\n")[0]);
        }
        return postActList;
    }

    public boolean isCreateLessonButtonDisplayed(){
        return waitForElementToBeDisplay(createLesson);
    }
    public void clickOnCreateLesson(){
        wait(5000);
        waitForElementToBeVisible(createLesson);
        createLesson.click();
        wait(2000);
    }
    public void clickOnCreateBlankLesson(){
        wait(5000);
        waitForElementToBeVisible(createBlankLesson);
        jsClick(createBlankLesson);
    }
    public boolean isChangeTopicButtonDisplayed(){
        scrollToView(changeTopic);
        return waitForElementToBeDisplay(changeTopic);
    }
    public boolean isChangeSelectActivityDisplayed(){
        scrollToView(selectActivityText);
        return waitForElementToBeDisplay(selectActivityText);
    }
    public boolean isContinueToCreateLessonDisplayed(){
        scrollToView(continueToCreateLesson);
        return waitForElementToBeDisplay(continueToCreateLesson);
    }
    public boolean isContinueToEditLessonDisplayed(){
        scrollToView(continueToEditLesson);
        return waitForElementToBeDisplay(continueToEditLesson);
    }
    public void clickOnContinueToCreateLesson(){
        wait(2000);
        waitForElementToBeVisible(continueToCreateLesson);
        jsClick(continueToCreateLesson);
        wait(4000);
    }

    public String getSelectBookTitle(){
        waitForElementToBeVisible(selectBookTitle);
        return selectBookTitle.getText();
    }
    public String getBookTitle(){
        waitForElementToBeVisible(bookTitle);
        return bookTitle.getText();
    }

    public String getAuthorName(){
        waitForElementToBeVisible(authorName);
        return authorName.getText();
    }
    public String getClassDetails(){
        waitForElementToBeVisible(className);
        return className.getText();
    }
    public String videoDuration(){
        waitForElementToBeVisible(videoDuration);
        return videoDuration.getText();
    }
    public String getBookDuration(){
        waitForElementToBeVisible(bookDuration);
        return  bookDuration.getText();
    }
    public boolean verifyTeacherNavigatedToCreatePage(){
       boolean flag = false;
        try{
            clickOnContinueToCreateLesson();
//            String parentWindow = driver.getWindowHandle();
            if (driver.getCurrentUrl().contains("/create/edit")){
                flag = true;
            }
//            for (String childWindow:driver.getWindowHandles()) {
//                if (!childWindow.equals(parentWindow)){
//                    driver.switchTo().window(childWindow);
//                    if (driver.getCurrentUrl().contains("/create/edit")){
//                        flag = true;
//                    }
//                    driver.close();
//                }
//            }
//            driver.switchTo().window(parentWindow);
        }catch (Exception e){
            flag= false;
        }finally {
            return flag;
        }

    }
    public void createLesson(){
        wait(5000);
        try{
            clickOnContinueToCreateLesson();
//            String parentWindow = driver.getWindowHandle();
////            for (String childWindow:driver.getWindowHandles()) {
////                if (!childWindow.equals(parentWindow)){
//                    driver.switchTo().window(childWindow);
                    try{
                        clickOnBlankLessonCreation();
                    }catch (Exception e){

                    }
                    for (int i = 0; i <recommendedAssets.size() ; i++) {
                        WebElement element = recommendedAssets.get(i);
                        waitForElementToBeVisible(element);
                        jsClick(element);
                      /*  addSlide();
                        wait(3000);*/
                    }
                    clickOnSave();
//                    driver.close();
//                }
//            }
//            driver.switchTo().window(parentWindow);
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    public void clickOnBlankLessonCreation(){
        jsClick(blankButton);
        wait(2000);
    }

    public int getTotalRecommendedContent(){
        waitForListOfElementToBeVisible(recommendedAssets);
        return recommendedAssets.size();
    }


    public void addSlide(){
        waitForElementToBeVisible(addSlide);
        addSlide.click();
    }
    public void clickOnSave(){
        waitForElementToBeVisible(save);
        jsClick(save);
        wait(5000);
    }

    public void clickOnPeriod(){
     waitForListOfElementToBeVisible(totalPeriods);
        for (int i = 0; i < totalPeriods.size(); i++) {
            WebElement element = totalPeriods.get(i);
            jsClick(element);
            //element.click();
            break;
        }
    }

    public int getTotalSlides(){
        wait(2000);
        int total=0;
        try{
            waitForListOfElementToBeVisible(totalSides);
            total = totalSides.size();
        }catch (Exception e){

        }finally {
            return total;
        }

    }
    public int getSlidesCount(){
        wait(2000);
        int total =0;
        try {
            waitForElementToBeVisible(slidesCount);
            total = Integer.parseInt(slidesCount.getText().split(" ")[0]);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            return total;
        }

    }

    public boolean isMoreActionOptionDisplayed(){
        wait(1000);
        return waitForElementToBeDisplay(moreAction);
    }

    public void clickOnMoreAction(){
        waitForElementToBeVisible(moreAction);
        moreAction.click();
    }
    public String getEditTopicText(){
        waitForElementToBeVisible(editTopic);
        return editTopic.getText();
    }
    public void clickOnEditTopic(){
        waitForElementToBeVisible(editTopic);
        editTopic.click();
    }
    public String getEditLessonText(){
        waitForElementToBeVisible(editLesson);
        return editLesson.getText();
    }
    public void clickOnEditLesson(){
        waitForElementToBeVisible(editLesson);
        editLesson.click();
    }
    public String getDeleteLessonText(){
        waitForElementToBeVisible(deleteLesson);
        return deleteLesson.getText();
    }
    public void clickOnDeleteLesson(){
        waitForElementToBeVisible(deleteLesson);
        deleteLesson.click();
    }
    public void clickOnOkContinueButton(){
        waitForElementToBeVisible(okButton);
        okButton.click();
        wait(3000);
    }
    public String getEditTopicPopupText(){
        waitForElementToBeVisible(getEditTopicTitle);
        return getEditTopicTitle.getText();
    }
    public void editLesson(){
        try{
            clickOnEditLesson();
            String parentWindow = driver.getWindowHandle();
            for (String childWindow:driver.getWindowHandles()) {
                if (!childWindow.equals(parentWindow)){
                    driver.switchTo().window(childWindow);
                    String url = driver.getCurrentUrl();
                    wait(2000);
                    Assert.assertTrue(url.contains("/create/edit"),"User is not navigated to edit lesson");
                    driver.close();
                }
            }
            driver.switchTo().window(parentWindow);
        }catch (Exception e){
            e.printStackTrace();
        }

    }
    public String getMarkAsCompletedText(){
        waitForElementToBeVisible(markCompleted);
        return markCompleted.getText();
    }
    public boolean isPublishLessonButtonAvailable(){
       return waitForElementToBeDisplay(publishLesson);
    }
    public boolean isUnPublishLessonButtonAvailable(){
        return waitForElementToBeDisplay(unpublishLesson);
    }

    public void createPageRefresh(){
        wait(2000);
        pageRefresh();
        waitForPageToLoad();
    }
    public void clickOnBackToPeriod(){
        waitForElementToBeVisible(backToPeriod);
        jsClick(backToPeriod);
        wait(5000);
    }
    public void clickOnYesDeleteButton(){
        jsClick(yesDelete);
    }
    public void clickOnToggleDeleteButton(){jsClick(toggleVisibilityOfSlide);}
    public void clickOnDuplicateSlide(){jsClick(duplicateSlideOfSlide);}
    public void clickOnSlideBackGround(){jsClick(slideBackgroundOfSlide);}
    public void clickOnTeacherNotes(){jsClick(teacherNotesOfSlide);}
    public void clickOnRecommended(){
        jsClick(recommendedOfSlide);
        }
    public void clickOnTemplates(){jsClick(templatesOfSlide);}
    public void clickOnTextOfSlide(){jsClick(textOfSlide);}
    public void clickOnImageOfSlide(){jsClick(ImageOfSlide);}
    public void clickOnVideoOfSlide(){jsClick(VideoOfSlide);}
    public void clickOnThreeDModelOfSlide(){jsClick(threeDModelOfSlide);}
    public void clickOnQuestionOfSlide(){jsClick(questionOfSlide);}
    public void clickOnExtrasOfSlide(){jsClick(extrasOfSlide);}
    public void clickOnHelpOfSlide(){jsClick(helpOfSlide);}
    public void selectRecommendedImage(int value){
        waitForListOfElementToBeVisible(recommendedImages);
        for (int i = 0; i < recommendedImages.size(); i++) {
            if (i ==value){
            WebElement element = recommendedImages.get(i);
            jsClick(element);
            break;
        }}


    }
    public void selectRecommendedVideos(int value){
        waitForListOfElementToBeVisible(recommendedVideos);
        for (int i = 0; i < recommendedVideos.size(); i++) {
            if (i ==value){
                WebElement element = recommendedVideos.get(i);
                jsClick(element);
                break;
            }}


    }

    public void selectQuestionOfQuestionSlide(int value){
        waitForListOfElementToBeVisible(QuestionOfQuestionSlide);
        for (int i = 0; i < QuestionOfQuestionSlide.size(); i++) {
            WebElement element = QuestionOfQuestionSlide.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectThreeDModelAnimationModels(int value){
        waitForListOfElementToBeVisible(ThreeDModelAnimationModels);
        for (int i = 0; i < ThreeDModelAnimationModels.size(); i++) {
            WebElement element = ThreeDModelAnimationModels.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectVideoOfVideo(int value){
        waitForListOfElementToBeVisible(VideoOfVideo);
        for (int i = 0; i < VideoOfVideo.size(); i++) {
            WebElement element = VideoOfVideo.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectCategoriesAndLanguageOfVideo(int value){
        waitForListOfElementToBeVisible(CategoriesAndLanguageOfVideo);
        for (int i = 0; i < CategoriesAndLanguageOfVideo.size(); i++) {
            WebElement element = CategoriesAndLanguageOfVideo.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectRecommendedImageOfImages(int value){
        waitForListOfElementToBeVisible(recommendedImageOfImages);
        for (int i = 0; i < recommendedImageOfImages.size(); i++) {
            WebElement element = recommendedImageOfImages.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectTableOfText(int value){
        waitForListOfElementToBeVisible(tableOfText);
        for (int i = 0; i < tableOfText.size(); i++) {
            WebElement element = tableOfText.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectRecommendedQuestions(int value){
        waitForListOfElementToBeVisible(recommendedQuestions);
        for (int i = 0; i < recommendedQuestions.size(); i++) {
            WebElement element = recommendedQuestions.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectRecommendedAllVideo(int value){
        waitForListOfElementToBeVisible(recommendedAllVideo);
        for (int i = 0; i < recommendedAllVideo.size(); i++) {
            WebElement element = recommendedAllVideo.get(i);
            jsClick(element);
            break;
        }


    }

    public void selectRecommendedImages(int value){
        waitForListOfElementToBeVisible(recommendedImages);
        for (int i = 0; i < recommendedImages.size(); i++) {
            WebElement element = recommendedImages.get(i);
            jsClick(element);
            break;
        }


    }

    public void detailsVerification(){

        softAssert.assertEquals(deleteButtonOfSlide.isDisplayed(),true,"Delete Button' is Not displayed");
        softAssert.assertEquals(duplicateSlideOfSlide.isDisplayed(),true,"duplicate Slide Of Slide' is Not displayed");
        softAssert.assertEquals(slideBackgroundOfSlide.isDisplayed(),true,"slide Back ground Of Slide' is Not displayed");
        softAssert.assertEquals(recommendedOfSlide.isDisplayed(),true,"recommended Of Slide is Not displayed");
        softAssert.assertEquals(templatesOfSlide.isDisplayed(),true,"templates Of Slide' is Not displayed");
        softAssert.assertEquals(textOfSlide.isDisplayed(),true,"text Of Slide' is Not displayed");
        softAssert.assertEquals(ImageOfSlide.isDisplayed(),true,"Image Of Slide' is Not displayed");
        softAssert.assertEquals(VideoOfSlide.isDisplayed(),true,"Video Of Slide' is Not displayed");
        softAssert.assertEquals(threeDModelOfSlide.isDisplayed(),true,"three DModel Of Slide' is Not displayed");
        softAssert.assertEquals(questionOfSlide.isDisplayed(),true,"question Of Slide is Not displayed");
        softAssert.assertEquals(extrasOfSlide.isDisplayed(),true,"extras Of Slide' is Not displayed");
        softAssert.assertEquals(helpOfSlide.isDisplayed(),true,"help Of Slide' is Not displayed");
        softAssert.assertEquals(toggleVisibilityOfSlide.isDisplayed(),true,"toggle Visibility Of Slide is Not displayed");

        softAssert.assertAll();

    }

    public String randomName(){
        // create a string of all characters
        String alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        // create random string builder
        StringBuilder sb = new StringBuilder();

        // create an object of Random class
        Random random = new Random();

        // specify length of random string
        int length = 7;

        for(int i = 0; i < length; i++) {

            // generate random index number
            int index = random.nextInt(alphabet.length());

            // get character specified by index
            // from the string
            char randomChar = alphabet.charAt(index);

            // append the character to string builder
            sb.append(randomChar);
        }

        String randomString = sb.toString();
        System.out.println("Random Name is: " + randomString);




        return randomString;

    }
    public void clickOnRandomNamefromAssignHomework(String data){
        driver.findElement(By.xpath("//div[text()='"+data+"']")).click();
        System.out.println(data);
    }

    public String verifyAssignmentName(){
       String String1 = titleOfAssignment.getText();

       return String1;

    }


}

