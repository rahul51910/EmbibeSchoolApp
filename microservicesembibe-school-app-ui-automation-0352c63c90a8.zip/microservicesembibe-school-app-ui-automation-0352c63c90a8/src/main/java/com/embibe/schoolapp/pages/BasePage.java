package com.embibe.schoolapp.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;
import java.util.function.Function;

public class BasePage {
    protected WebDriver driver;

    protected void wait(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    protected void waitForElementToBeClickable(WebElement element){

        new WebDriverWait(driver,30).until(ExpectedConditions.elementToBeClickable(element));
    }
    protected void waitForElementToBeVisible(WebElement element){
        new WebDriverWait(driver,30).until(ExpectedConditions.visibilityOf(element));
    }
    protected void waitForListOfElementToBeVisible(List<WebElement> element){
        new WebDriverWait(driver,30).until(ExpectedConditions.visibilityOfAllElements(element));
    }
    protected void waitForListOfElementToBeVisible(List<WebElement> element,int timeout){
        new WebDriverWait(driver,timeout).until(ExpectedConditions.visibilityOfAllElements(element));
    }
    protected void jsClick(WebElement element) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }
    protected void jsSendKeys(WebElement element,String value) {
        ((JavascriptExecutor) driver).executeScript("arguments[0].value='"+ value +"';", element);
    }
    protected void waitForPageToLoad() {
        new WebDriverWait(driver, 30).until(
                webDriver -> ((JavascriptExecutor) webDriver).executeScript("return document.readyState").equals("complete"));
    }
    public boolean verifyPage(String str){
        wait(2000);
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.equals(str);
        return  value;
    }
    protected boolean waitForElementToBeDisplay(WebElement element) {
        Wait wait = new FluentWait(driver).withTimeout(Duration.ofSeconds(30)).pollingEvery(Duration.ofSeconds(2));
        wait.until((Function<WebDriver, WebElement>) driver -> element);
        return element.isDisplayed();
    }
    protected void scrollToView(WebElement element) {
        if (element.isEnabled()) {
            ((JavascriptExecutor) driver).
                    executeScript("arguments[0].scrollIntoView(true);", element);
        }

    }
    protected void waitForElementToBeVisible(WebElement element, int timeout) {

        new WebDriverWait(driver, timeout).until(
                ExpectedConditions.visibilityOf(element)
        );

    }
    protected void  pageRefresh(){
        driver.navigate().refresh();
    }
    public void navigateBack(){
        driver.navigate().back();
        waitForPageToLoad();
    }
    protected void actionClick(WebElement element){
        Actions actions = new Actions(driver);
        Action action = actions.moveToElement(element).build();
        action.perform();
        wait(2000);
        Action action1 = actions.click(element).build();
        action1.perform();

    }
}
