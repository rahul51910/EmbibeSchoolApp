
package com.embibe.schoolapp.api.trackStudentWiseAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class VideosWatched {

    @SerializedName("numberOfVideosWatched")
    @Expose
    private Integer numberOfVideosWatched;
    @SerializedName("durationInMinutes")
    @Expose
    private Double durationInMinutes;

    public Integer getNumberOfVideosWatched() {
        return numberOfVideosWatched;
    }

    public void setNumberOfVideosWatched(Integer numberOfVideosWatched) {
        this.numberOfVideosWatched = numberOfVideosWatched;
    }

    public Double getDurationInMinutes() {
        return durationInMinutes;
    }

    public void setDurationInMinutes(Double durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

}
