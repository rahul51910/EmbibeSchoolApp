
package com.embibe.schoolapp.api.show;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class ClassDetail {

    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("grade")
    @Expose
    private String grade;
    @SerializedName("section")
    @Expose
    private String section;
    @SerializedName("name")
    @Expose
    private String name;
    @SerializedName("classOrgId")
    @Expose
    private String classOrgId;
    @SerializedName("subjects")
    @Expose
    private List<Subject> subjects = null;
    @SerializedName("studentCount")
    @Expose
    private Integer studentCount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getSection() {
        return section;
    }

    public void setSection(String section) {
        this.section = section;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClassOrgId() {
        return classOrgId;
    }

    public void setClassOrgId(String classOrgId) {
        this.classOrgId = classOrgId;
    }

    public List<Subject> getSubjects() {
        return subjects;
    }

    public void setSubjects(List<Subject> subjects) {
        this.subjects = subjects;
    }

    public Integer getStudentCount() {
        return studentCount;
    }

    public void setStudentCount(Integer studentCount) {
        this.studentCount = studentCount;
    }

}
