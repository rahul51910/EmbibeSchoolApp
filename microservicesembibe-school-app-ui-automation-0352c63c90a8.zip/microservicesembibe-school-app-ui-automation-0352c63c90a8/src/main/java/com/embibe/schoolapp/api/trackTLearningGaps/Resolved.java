
package com.embibe.schoolapp.api.trackTLearningGaps;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Resolved {

    @SerializedName("val")
    @Expose
    private Integer val;
    @SerializedName("desc")
    @Expose
    private String desc;
    @SerializedName("imgUrl")
    @Expose
    private String imgUrl;

    public Integer getVal() {
        return val;
    }

    public void setVal(Integer val) {
        this.val = val;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

}
