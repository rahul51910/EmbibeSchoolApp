
package com.embibe.schoolapp.api.loginPageAPI;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class LoginPageAPIHelper {

    @SerializedName("orgId")
    @Expose
    private String orgId;
    @SerializedName("orgName")
    @Expose
    private String orgName;
    @SerializedName("instituteLogo")
    @Expose
    private String instituteLogo;
    @SerializedName("orgToken")
    @Expose
    private String orgToken;
    @SerializedName("orgType")
    @Expose
    private Object orgType;
    @SerializedName("personaType")
    @Expose
    private Object personaType;

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getInstituteLogo() {
        return instituteLogo;
    }

    public void setInstituteLogo(String instituteLogo) {
        this.instituteLogo = instituteLogo;
    }

    public String getOrgToken() {
        return orgToken;
    }

    public void setOrgToken(String orgToken) {
        this.orgToken = orgToken;
    }

    public Object getOrgType() {
        return orgType;
    }

    public void setOrgType(Object orgType) {
        this.orgType = orgType;
    }

    public Object getPersonaType() {
        return personaType;
    }

    public void setPersonaType(Object personaType) {
        this.personaType = personaType;
    }

}
