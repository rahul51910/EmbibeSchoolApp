package com.embibe.schoolapp.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesReader {
    private java.util.Properties prop = new Properties();

    public PropertiesReader(){
        InputStream inputStream;
        String environment = System.getProperty("env");
        String propertiesFilePath = environment + ".properties";
        inputStream = getInputStream(propertiesFilePath);

        try {
            prop.load(inputStream);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private InputStream getInputStream(String propertiesFilePath) {
        return this.getClass().getClassLoader().getResourceAsStream(propertiesFilePath);
    }

    String getBaseUrl() {
        return prop.getProperty("baseUrl");
    }
    String getBrowserStackUsername() {

        return prop.getProperty("browserStackUsername");
    }

    String getBrowserStackKey() {

        return prop.getProperty("browserStackKey");
    }
    String getShowBasePath(){
        return prop.getProperty("show");
    }
    String getPreProdBaseUrl(){
        return prop.getProperty("preProdBaseUrl");
    }
    String getTeacherNextSlotBasePath(){
        return prop.getProperty("teacherNextSlot");
    }
    String getTeacherCalendarBasePath(){
        return prop.getProperty("teacherCalendar");
    }
    String getTodayPeriodsBasePath(){
        return prop.getProperty("todayPeriods");
    }

    String getFilesSharedBasePath(){
        return prop.getProperty("filesShared");
    }
    String getInboxMessagesBasePath(){
        return prop.getProperty("inboxMessages");
    }
    String getUserProfileBasePath(){
        return prop.getProperty("userProfile");
    }
    String getMyStudentsBasePath(){
        return prop.getProperty("myStudents");
    }
    String getAttendanceRetrieveBasePath(){
        return prop.getProperty("attendanceRetrieve");
    }
    String getAttendanceAnalyticsBasePath(){
        return prop.getProperty("attendanceAnalytics");
    }
    String getPassword(){
        return prop.getProperty("password");
    }
    String getUserName(){
        return prop.getProperty("userName");
    }
    String getSecondUsername(){
        return prop.getProperty("userName2");
    }
    String getSecondPassword(){
        return prop.getProperty("password2");
    }
    String getThirdUsername(){
        return prop.getProperty("userName3");
    }
    String getThirdPassword(){
        return prop.getProperty("password3");
    }
    String getResellerToken(){
        return prop.getProperty("resellerJWTToken");
    }
    String getSchoolId(){
        return prop.getProperty("schoolId");
    }
    String getMyClassBasePath(){
        return prop.getProperty("myClasses");
    }

    public String getTrackOverViewBasePath() {
        return prop.getProperty("trackOverView");
    }
    public String getClassID(){
        return prop.getProperty("classId");
    }
    public String getEmbibeToken(){
        return prop.getProperty("embibe-token");

    }
    public String getOrigin(){
        return prop.getProperty("Origin");

    }
    public String getOrgId(){
        return prop.getProperty("orgId");
    }
    public String getKvCode(){
        return prop.getProperty("kvCode");
    }

    public String getlocal() {
        return prop.getProperty("locale");
    }

    public String gettrackSyllabusCoverageBasePath() {
        return  prop.getProperty("trackSyllabusCoverageBasePath");
    }

    public String gettrackLearningGapsBasePath() {
        return prop.getProperty("trackLearningGapsBasePath");
    }

    public String gettrackTeachAnalysisBasePath() {
        return prop.getProperty("trackTeachAnalysisBasePath");
    }

    public String getFilter() {
        return prop.getProperty("filter");
    }

    public String getSize() {
        return prop.getProperty("size");
    }

    public String getOffset() {
        return prop.getProperty("offset");
    }

    public String getTestAnalysisBasePath() {
        return prop.getProperty("trackTestAnalysisBasePath");
    }

    public String gettracleStudentWiseAnalysisBasePath() {
        return prop.getProperty("trackStudentWiseAnalysisBasePath");
    }
    public String getCalenderUploadBasePath(){
        return prop.getProperty("calenderUploadBasePath");
    }

    public String getResellerJWTTokenForCalender() {
        return prop.getProperty("resellerJWTTokenForCalender");
    }

    public String baseUrlForStudent() {
        return prop.getProperty("baseUrlForStudent");
    }
    public String userNameOfStudent() {
        return prop.getProperty("userNameOfStudent");
    }

    public String passwordOfStudent() {
        return prop.getProperty("passwordOfStudent");
    }

    public String attendanceSearch(){return prop.getProperty("attendacesearch");}

    public String availableOrg(){return prop.getProperty("basePathofAvailableOrg");}

    public String basePathOfUserAuth() {
        return  prop.getProperty("basePathOfUserAuth");
    }

    public String deviceId() {
        return prop.getProperty("device_id");
    }
    public String assignAnalysisBasePath(){
        return prop.getProperty("assignAnalysisBasePath");
    }
}
