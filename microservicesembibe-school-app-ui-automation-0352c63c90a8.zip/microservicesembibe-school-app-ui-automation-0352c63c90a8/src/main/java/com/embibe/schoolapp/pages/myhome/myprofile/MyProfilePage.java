package com.embibe.schoolapp.pages.myhome.myprofile;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MyProfilePage extends BasePage {
    @FindBy(xpath = "//div[text()='My Profile']")
    private WebElement myProfile;

    @FindBy(xpath = "//div[text()='Full Name']/following-sibling::div")
    private WebElement fullName;

    @FindBy(xpath = "//div[text()='Email']/following-sibling::div")
    private WebElement email;

    @FindBy(xpath = "//div[text()='Contact Number']/following-sibling::div")
    private WebElement contactNumber;

    @FindBy(xpath = "//*[contains(text(),'Edit Profile')]")
    private WebElement editProfileButton;

    @FindBy(xpath = "//input[@placeholder='College']")
    private WebElement college;

    @FindBy(css = ".qualification")
    private WebElement qualification;

    @FindBy(xpath = "//div[text()='Save changes']")
    private WebElement saveChanges;

    @FindBy(css = ".load-title")
    private WebElement loadTitle;





    public MyProfilePage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void clickOnProfile(){
        waitForElementToBeVisible(myProfile);
        myProfile.click();
        wait(1000);
    }
    public boolean verifyProfilePageURL(String str){
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.equals(str);
        return  value;
    }

    public String getFullname(){
        waitForElementToBeVisible(fullName);
        return fullName.getText();
    }
    public String getEmail(){
        waitForElementToBeVisible(email);
        return email.getText();
    }
    public String getContactNumber(){
        waitForElementToBeVisible(contactNumber);
        return contactNumber.getText();
    }
    public void clickOnEditProfile(){
        waitForElementToBeVisible(editProfileButton);
        editProfileButton.click();
    }
    public void setCollege(String name){
        waitForElementToBeVisible(college);
        college.clear();
        college.sendKeys(name);
    }
    public String getQualification(){
        waitForElementToBeVisible(qualification);
        return qualification.getText();
    }
    public void clickOnSaveChanges(){
        waitForElementToBeVisible(saveChanges);
        saveChanges.click();
    }
    public String getTeacherLoadTitle(){
        waitForElementToBeVisible(loadTitle);
        return loadTitle.getText();
    }
}
