
package com.embibe.schoolapp.api.trackSyllabusCoverage;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class HelperSyllabusCoverage {

    @SerializedName("plannedProgress")
    @Expose
    private Double plannedProgress;
    @SerializedName("actualProgress")
    @Expose
    private Double actualProgress;
    @SerializedName("data")
    @Expose
    private List<Datum> data = null;

    public Double getPlannedProgress() {
        return plannedProgress;
    }

    public void setPlannedProgress(Double plannedProgress) {
        this.plannedProgress = plannedProgress;
    }

    public Double getActualProgress() {
        return actualProgress;
    }

    public void setActualProgress(Double actualProgress) {
        this.actualProgress = actualProgress;
    }

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

}
