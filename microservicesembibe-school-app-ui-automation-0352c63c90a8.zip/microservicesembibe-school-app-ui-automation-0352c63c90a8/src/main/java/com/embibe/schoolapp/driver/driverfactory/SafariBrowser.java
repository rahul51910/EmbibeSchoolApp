package com.embibe.schoolapp.driver.driverfactory;

import com.embibe.schoolapp.driver.BrowserStackDriver;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.safari.SafariDriver;
import org.openqa.selenium.safari.SafariOptions;

public class SafariBrowser implements BrowserDriver{
    @Override
    public WebDriver getDriver() throws Exception {
        SafariOptions safariOptions = new SafariOptions();
        safariOptions.setUseTechnologyPreview(true);

        switch (driverEnvironment) {

            case DriverEnvironment.BROWSERSTACK:
                return new BrowserStackDriver().getDriver(driver);

            default:
                return new SafariDriver();
        }
    }

    @Override
    public void setDriverBinaryPath() {

    }
}
