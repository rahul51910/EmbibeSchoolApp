
package com.embibe.schoolapp.api.trackStudentWiseAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class QuestionsPracticed {

    @SerializedName("numberOfQuestionsPracticed")
    @Expose
    private Integer numberOfQuestionsPracticed;
    @SerializedName("durationInMinutes")
    @Expose
    private Double durationInMinutes;

    public Integer getNumberOfQuestionsPracticed() {
        return numberOfQuestionsPracticed;
    }

    public void setNumberOfQuestionsPracticed(Integer numberOfQuestionsPracticed) {
        this.numberOfQuestionsPracticed = numberOfQuestionsPracticed;
    }

    public Double getDurationInMinutes() {
        return durationInMinutes;
    }

    public void setDurationInMinutes(Double durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

}
