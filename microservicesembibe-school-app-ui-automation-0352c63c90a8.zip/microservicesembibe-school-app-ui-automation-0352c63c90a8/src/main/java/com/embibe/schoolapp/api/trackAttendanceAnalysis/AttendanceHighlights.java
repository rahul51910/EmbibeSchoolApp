
package com.embibe.schoolapp.api.trackAttendanceAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class AttendanceHighlights {

    @SerializedName("attendance")
    @Expose
    private Attendance attendance;
    @SerializedName("workingDays")
    @Expose
    private WorkingDays workingDays;
    @SerializedName("totalStudents")
    @Expose
    private Integer totalStudents;
    @SerializedName("studentsWithAttendanceAbove75")
    @Expose
    private Integer studentsWithAttendanceAbove75;
    @SerializedName("studentsWithAttendanceBelow75")
    @Expose
    private Integer studentsWithAttendanceBelow75;

    public Attendance getAttendance() {
        return attendance;
    }

    public void setAttendance(Attendance attendance) {
        this.attendance = attendance;
    }

    public WorkingDays getWorkingDays() {
        return workingDays;
    }

    public void setWorkingDays(WorkingDays workingDays) {
        this.workingDays = workingDays;
    }

    public Integer getTotalStudents() {
        return totalStudents;
    }

    public void setTotalStudents(Integer totalStudents) {
        this.totalStudents = totalStudents;
    }

    public Integer getStudentsWithAttendanceAbove75() {
        return studentsWithAttendanceAbove75;
    }

    public void setStudentsWithAttendanceAbove75(Integer studentsWithAttendanceAbove75) {
        this.studentsWithAttendanceAbove75 = studentsWithAttendanceAbove75;
    }

    public Integer getStudentsWithAttendanceBelow75() {
        return studentsWithAttendanceBelow75;
    }

    public void setStudentsWithAttendanceBelow75(Integer studentsWithAttendanceBelow75) {
        this.studentsWithAttendanceBelow75 = studentsWithAttendanceBelow75;
    }

}
