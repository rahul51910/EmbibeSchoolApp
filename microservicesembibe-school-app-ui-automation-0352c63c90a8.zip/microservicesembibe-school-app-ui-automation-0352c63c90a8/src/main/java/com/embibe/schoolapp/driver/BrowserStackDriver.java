package com.embibe.schoolapp.driver;

import com.embibe.schoolapp.utils.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.ie.InternetExplorerOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariOptions;

import java.net.URL;

import static com.embibe.schoolapp.utils.Browsers.*;

public class BrowserStackDriver {
    private String[] getOS(){
        String os = System.getProperty("os");
        if(os.contains("Windows")){
            return os.split("-");
        }
        else if(os.contains("CATALINA")){
            String t = "OS X-Catalina";
            return t.split("-");
        }
        else if(os.contains("SNOW_LEOPARD")){
            String t = "OS X-Snow Leopard";
            return t.split("-");
        }
        else if(os.contains("MOUNTAIN_LION")){
            String t = "OS X-Mountain Lion";
            return t.split("-");
        }
        else if(os.contains("MAVERICKS")){
            String t = "OS X-Mavericks";
            return t.split("-");
        }
        else if(os.contains("YOSEMITE")){
            String t = "OS X-Yosemite";
            return t.split("-");
        }
        else if(os.contains("EL_CAPITAN")){
            String t = "OS X-El Capitan";
            return t.split("-");
        }
        else if(os.contains("SIERRA")){
            String t = "OS X-Sierra";
            return t.split("-");
        }
        else if(os.contains("HIGH_SIERRA")){
            String t = "OS X-High Sierra";
            return t.split("-");
        }
        else if(os.contains("MOJAVE")){
            String t = "OS X-Mojave";
            return t.split("-");
        }
        return "Windows 10".split(" ");
    }

    public WebDriver getDriver(String browser) throws Exception {

        String [] os = getOS();
        DesiredCapabilities capabilities = new DesiredCapabilities();
        capabilities.setCapability("browser", browser);
        String username = Properties.BROWSER_STACK_USERNAME;
        String accessKey = Properties.BROWSER_STACK_KEY;
        capabilities.setCapability("resolution", "1280x1024");
        switch (browser) {
            case CHROME:
                capabilities.setCapability("os",os[0]);
                capabilities.setCapability("os_version",os[1]);
//                capabilities.setVersion("71");
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--start-maximized");
                capabilities.setCapability(ChromeOptions.CAPABILITY, options);
                break;

            case FIREFOX:
                capabilities.setCapability("os",os[0]);
                capabilities.setCapability("os_version",os[1]);
                FirefoxOptions firefoxOptions = new FirefoxOptions();
                firefoxOptions.addArguments("--start-maximized");
                firefoxOptions.setCapability(FirefoxOptions.FIREFOX_OPTIONS, firefoxOptions);
                break;

            case IE:
                capabilities.setCapability("os",os[0]);
                capabilities.setCapability("os_version",os[1]);
                InternetExplorerOptions internetExplorerOptions = new InternetExplorerOptions();
                internetExplorerOptions.setCapability(CapabilityType.BROWSER_NAME, "IE");
                internetExplorerOptions.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
                break;

            case SAFARI:
                capabilities.setCapability("os",os[0]);
                capabilities.setCapability("os_version",os[1]);
                SafariOptions safariOptions = new SafariOptions();
                safariOptions.setUseTechnologyPreview(true);
        }
        return new RemoteWebDriver(new URL("http://" + username + ":" + accessKey + "@" + "hub-cloud.browserstack.com" + "/wd/hub"), capabilities);
    }
}
