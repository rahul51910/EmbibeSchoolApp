package com.embibe.schoolapp.pages.teach;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.time.DayOfWeek;
import java.time.LocalDateTime;
import java.util.List;

public class TeachPage extends BasePage {

    @FindBy(xpath = "//div[text()='Choose a class to teach']")
    private WebElement teachPageText;

    @FindBy(xpath = "//div[contains(@class,'content-grid-wrapper')]/div")
    private List<WebElement> timeTableDays;

    @FindBy(xpath = "//div[contains(@class,'period-slot-container')]")
    private List<WebElement> totalAllottedPeriodsOnCurrentWeek;

    @FindBy(xpath = "//*[contains(text(),'PERIOD')]")
    private List<WebElement> totalPeriodsForTheDay;

    @FindBy(xpath = "//div[text()='Start Teaching']")
    private WebElement startTeaching;

    @FindBy(css = ".copy-title ")
    private WebElement copyButton;

    @FindBy(css = "//div[contains(@class,'tab-1')]")
    private WebElement studentSection;

    @FindBy(css = "//div[contains(@class,'tab-2')]")
    private WebElement teachersSection;

    @FindBy(css = ".buttons>div")
    private List<WebElement> studentSections;





    @FindBy(xpath = "//div[contains(text(),'Homework Stats')]")
    private WebElement homeworkStats;

    @FindBy(xpath ="//div[contains(text(),'Prerequisite readiness')]")
    private WebElement prerequisite;

    @FindBy(xpath = "//div[contains(text(),'Add Interactive elements')]")
    private WebElement addInteractiveElements;

    @FindBy(xpath = "//div[contains(text(),'Recap suggestions')]")
    private WebElement recapSuggestions;


    public TeachPage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }
    public boolean verifyTeachPageURL(String str){
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.equals(str);
        return  value;
    }
    public String getTeachPageText(){
        waitForElementToBeVisible(teachPageText);
        return teachPageText.getText();
    }
    public int getTimeTableDays(){
        waitForListOfElementToBeVisible(timeTableDays);
        return timeTableDays.size();
    }

    public int getTotalAllottedPeriods(){
        waitForListOfElementToBeVisible(totalAllottedPeriodsOnCurrentWeek);
        return totalAllottedPeriodsOnCurrentWeek.size();
    }
    public int getTotalPeriodsPerDay(){
        int total= 0;
        try {
            waitForListOfElementToBeVisible(totalPeriodsForTheDay);
            total= totalPeriodsForTheDay.size();
        }catch (Exception e){

        }finally {
            return  total;
        }

    }

    public boolean isStartTeachingButtonAvailable(){
        boolean flag = false;
        LocalDateTime now = LocalDateTime.now();
        DayOfWeek dayOfWeek
                = DayOfWeek.from(now);
       int value = dayOfWeek.getValue();
        List<WebElement> todayPeriods = driver.findElements(By.xpath("//div[contains(@class,'column-main-container')]["+value+"]//div[contains(@class,'p-s-title')]"));
        for (int i = 0; i < todayPeriods.size(); i++) {
            int attempts =0;
            System.out.println("the value of i "+i);
            WebElement element = todayPeriods.get(i);
            try{

                while(attempts < 5) {
                    try {
                        actionClick(element);
                        wait(5000);
                        if (startTeaching.isDisplayed() && startTeaching.isEnabled()){
                            flag = true;
                            break;
                        }
                    } catch(StaleElementReferenceException e) {
                    }
                    System.out.println("the attempts value"+attempts);
                    attempts++;
                }

                wait(2000);
            }
            catch (Exception e){
                navigateBack();
                wait(8000);
                e.printStackTrace();
            }

        }
        return flag;
    }

    public boolean isCopyJioLinkButtonVisible(){
        return waitForElementToBeDisplay(copyButton);
    }

    public String getStartTeachingButtonText(){
        waitForElementToBeVisible(startTeaching);
        return startTeaching.getText();
    }
    public void clickOnStartTeaching(){
        waitForElementToBeVisible(startTeaching);
        startTeaching.click();
    }
    public boolean verifyTeacherNavigatedJioMeet(){
        boolean flag = false;
        try{
            clickOnStartTeaching();
            String parentWindow = driver.getWindowHandle();
            for (String childWindow:driver.getWindowHandles()) {
                if (!childWindow.equals(parentWindow)){
                    driver.switchTo().window(childWindow);
                    if (driver.getCurrentUrl().contains("iframe-teacher")){
                        flag = true;
                    }
                    driver.close();
                }
            }
            driver.switchTo().window(parentWindow);
        }catch (Exception e){

        }finally {
            return  flag;
        }
    }
    public boolean isStudentSectionVisibleOnJioMeet(){
        boolean flag = false;
        try{
            clickOnStartTeaching();
            String parentWindow = driver.getWindowHandle();
            for (String childWindow:driver.getWindowHandles()) {
                if (!childWindow.equals(parentWindow)){
                    driver.switchTo().window(childWindow);
                    flag = isStudentSectionVisible();
                    driver.close();
                }
            }
            driver.switchTo().window(parentWindow);
        }catch (Exception e){

        }finally {
            return  flag;
        }
    }
    public boolean isTeacherSectionVisibleOnJioMeet(){
        boolean flag = false;
        try{
            clickOnStartTeaching();
            String parentWindow = driver.getWindowHandle();
            for (String childWindow:driver.getWindowHandles()) {
                if (!childWindow.equals(parentWindow)){
                    driver.switchTo().window(childWindow);
                    flag = isTeacherSectionVisible();
                    driver.close();
                }
            }
            driver.switchTo().window(parentWindow);
        }catch (Exception e){

        }finally {
            return  flag;
        }
    }
    public boolean isStudentSectionVisible(){
        return waitForElementToBeDisplay(studentSection);
    }

    public boolean isTeacherSectionVisible(){
        return waitForElementToBeDisplay(teachersSection);
    }

    public int getTotalStudentsSections(){
        waitForListOfElementToBeVisible(studentSections);
        return studentSections.size();
    }
    public boolean isPreReadinessDisplaying(){
        return waitForElementToBeDisplay(prerequisite);
    }
    public boolean isHomeworkStatsDisplayed(){
        return waitForElementToBeDisplay(homeworkStats);
    }
    public boolean isAddInteractiveDisplayed(){
        return waitForElementToBeDisplay(addInteractiveElements);
    }
    public boolean isRecapSuggestions(){
        return waitForElementToBeDisplay(recapSuggestions);
    }
}
