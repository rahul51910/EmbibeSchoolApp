
package com.embibe.schoolapp.api.trackTeachAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Datum {

    @SerializedName("date")
    @Expose
    private Integer date;
    @SerializedName("periodCount")
    @Expose
    private Integer periodCount;
    @SerializedName("chapterName")
    @Expose
    private String chapterName;
    @SerializedName("topicName")
    @Expose
    private String topicName;
    @SerializedName("classAttendance")
    @Expose
    private Integer classAttendance;
    @SerializedName("classParticipation")
    @Expose
    private Double classParticipation;

    public Integer getDate() {
        return date;
    }

    public void setDate(Integer date) {
        this.date = date;
    }

    public Integer getPeriodCount() {
        return periodCount;
    }

    public void setPeriodCount(Integer periodCount) {
        this.periodCount = periodCount;
    }

    public String getChapterName() {
        return chapterName;
    }

    public void setChapterName(String chapterName) {
        this.chapterName = chapterName;
    }

    public String getTopicName() {
        return topicName;
    }

    public void setTopicName(String topicName) {
        this.topicName = topicName;
    }

    public Integer getClassAttendance() {
        return classAttendance;
    }

    public void setClassAttendance(Integer classAttendance) {
        this.classAttendance = classAttendance;
    }

    public Double getClassParticipation() {
        return classParticipation;
    }

    public void setClassParticipation(Double classParticipation) {
        this.classParticipation = classParticipation;
    }

}
