
package com.embibe.schoolapp.api.attendanceAnalysisApi;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class AttendancePercentage {

    @SerializedName("1501652559")
    @Expose
    private String _1501652559;
    @SerializedName("1501652569")
    @Expose
    private String _1501652569;
    @SerializedName("1501351229")
    @Expose
    private String _1501351229;
    @SerializedName("1501652567")
    @Expose
    private String _1501652567;
    @SerializedName("1501652556")
    @Expose
    private String _1501652556;
    @SerializedName("1501351233")
    @Expose
    private String _1501351233;
    @SerializedName("1501656516")
    @Expose
    private String _1501656516;
    @SerializedName("1501347458")
    @Expose
    private String _1501347458;
    @SerializedName("1501349706")
    @Expose
    private String _1501349706;
    @SerializedName("1501349707")
    @Expose
    private String _1501349707;
    @SerializedName("1501652484")
    @Expose
    private String _1501652484;
    @SerializedName("1501351231")
    @Expose
    private String _1501351231;
    @SerializedName("1501652482")
    @Expose
    private String _1501652482;
    @SerializedName("1501652563")
    @Expose
    private String _1501652563;
    @SerializedName("1501197010")
    @Expose
    private String _1501197010;

    public String get1501652559() {
        return _1501652559;
    }

    public void set1501652559(String _1501652559) {
        this._1501652559 = _1501652559;
    }

    public String get1501652569() {
        return _1501652569;
    }

    public void set1501652569(String _1501652569) {
        this._1501652569 = _1501652569;
    }

    public String get1501351229() {
        return _1501351229;
    }

    public void set1501351229(String _1501351229) {
        this._1501351229 = _1501351229;
    }

    public String get1501652567() {
        return _1501652567;
    }

    public void set1501652567(String _1501652567) {
        this._1501652567 = _1501652567;
    }

    public String get1501652556() {
        return _1501652556;
    }

    public void set1501652556(String _1501652556) {
        this._1501652556 = _1501652556;
    }

    public String get1501351233() {
        return _1501351233;
    }

    public void set1501351233(String _1501351233) {
        this._1501351233 = _1501351233;
    }

    public String get1501656516() {
        return _1501656516;
    }

    public void set1501656516(String _1501656516) {
        this._1501656516 = _1501656516;
    }

    public String get1501347458() {
        return _1501347458;
    }

    public void set1501347458(String _1501347458) {
        this._1501347458 = _1501347458;
    }

    public String get1501349706() {
        return _1501349706;
    }

    public void set1501349706(String _1501349706) {
        this._1501349706 = _1501349706;
    }

    public String get1501349707() {
        return _1501349707;
    }

    public void set1501349707(String _1501349707) {
        this._1501349707 = _1501349707;
    }

    public String get1501652484() {
        return _1501652484;
    }

    public void set1501652484(String _1501652484) {
        this._1501652484 = _1501652484;
    }

    public String get1501351231() {
        return _1501351231;
    }

    public void set1501351231(String _1501351231) {
        this._1501351231 = _1501351231;
    }

    public String get1501652482() {
        return _1501652482;
    }

    public void set1501652482(String _1501652482) {
        this._1501652482 = _1501652482;
    }

    public String get1501652563() {
        return _1501652563;
    }

    public void set1501652563(String _1501652563) {
        this._1501652563 = _1501652563;
    }

    public String get1501197010() {
        return _1501197010;
    }

    public void set1501197010(String _1501197010) {
        this._1501197010 = _1501197010;
    }

}
