
package com.embibe.schoolapp.api.trackStudentWiseAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Pagination {

    @SerializedName("offset")
    @Expose
    private Integer offset;
    @SerializedName("size")
    @Expose
    private Integer size;
    @SerializedName("count")
    @Expose
    private Integer count;

    public Integer getOffset() {
        return offset;
    }

    public void setOffset(Integer offset) {
        this.offset = offset;
    }

    public Integer getSize() {
        return size;
    }

    public void setSize(Integer size) {
        this.size = size;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

}
