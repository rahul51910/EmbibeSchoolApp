
package com.embibe.schoolapp.api.trackOverView;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class TrackOverViewHelper {

    @SerializedName("Outcomes Panel")
    @Expose
    private OutcomesPanel outcomesPanel;
    @SerializedName("Effort Insights")
    @Expose
    private EffortInsights effortInsights;

    public OutcomesPanel getOutcomesPanel() {
        return outcomesPanel;
    }

    public void setOutcomesPanel(OutcomesPanel outcomesPanel) {
        this.outcomesPanel = outcomesPanel;
    }

    public EffortInsights getEffortInsights() {
        return effortInsights;
    }

    public void setEffortInsights(EffortInsights effortInsights) {
        this.effortInsights = effortInsights;
    }

}
