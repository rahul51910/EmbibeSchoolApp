
package com.embibe.schoolapp.api.attendanceAnalysisApi;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class TodayAttendance {

    @SerializedName("total")
    @Expose
    private Integer total;
    @SerializedName("percentage")
    @Expose
    private Integer percentage;
    @SerializedName("count")
    @Expose
    private Integer count;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

}
