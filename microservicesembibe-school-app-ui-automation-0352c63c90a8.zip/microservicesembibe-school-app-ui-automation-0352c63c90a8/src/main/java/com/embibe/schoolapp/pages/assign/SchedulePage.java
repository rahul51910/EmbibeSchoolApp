package com.embibe.schoolapp.pages.assign;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import com.embibe.schoolapp.utils.Properties;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;

import java.time.LocalDate;
import java.util.List;

import static java.time.temporal.TemporalAdjusters.firstDayOfYear;
import static java.time.temporal.TemporalAdjusters.lastDayOfYear;

public class SchedulePage extends BasePage {
    SoftAssert softAssert=null;

    public SchedulePage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
        softAssert=new SoftAssert();
    }

    @FindBy(xpath = "//div[text()='Choose a class to create']")

    private WebElement scheduleText;

    @FindBy(xpath = "//a[text()='Assign']")
    private WebElement assignButton;

    @FindBy(xpath = "//div[text()='Schedule']")
    private WebElement schedule;

    @FindBy(xpath = "//*[contains(text(),'My School')]")
    private WebElement mySchoolsOnStudentApp;

    @FindBy(xpath = "//div[text()='Assigned Test']")
    private WebElement assignTestTab;

    @FindBy(xpath = "//div[text()='Test Quality Score']")
    private WebElement testQualityScoreText;

    @FindBy(xpath = "//div[text()='Aligned to exams']")
    private  WebElement alignedToExamsText;

    @FindBy(xpath = "(//div[text()='45 mins'])[1]")
    private WebElement fortyFiveMinsText;

    @FindBy(xpath = "(//div[text()='Duration'])[1]")
    private WebElement durationText;

    @FindBy(xpath = "(//div[text()='Questions'])[1]")
    private WebElement questionText;

    @FindBy(xpath = "(//div[text()='Marks'])[1]")
    private WebElement marksText;

    @FindBy(xpath = "(//div[text()='Select Test'])[2]")
    private WebElement selectTestText;

    @FindBy(xpath = "//div[text()='Review Questions']")
    private WebElement reviewQuestionsText;

    @FindBy(xpath = "//div[text()='Review Instructions']")
    private WebElement reviewInstructionText;

    @FindBy(xpath = "//div[text()='Assign test']")
    private WebElement AssignTestText;

    @FindBy(xpath = "//div[text()=' You can only select one Test Pack at a time.']")
    private WebElement text1;

    @FindBy(xpath = "//div[text()='Class Readiness']")
    private WebElement text2;

    @FindBy(xpath = "//img[@src='https://d34jbachbupkhk.cloudfront.net/assign/static/media/icon_testQualityScore.6592cff5.svg']")
    private WebElement icon1;

    @FindBy(xpath = "//img[@src='https://d34jbachbupkhk.cloudfront.net/assign/static/media/icon_duration.57aa4a60.svg']")
    private WebElement icon2;

    @FindBy(xpath = "//img[@src='https://d34jbachbupkhk.cloudfront.net/assign/static/media/icon_questions.ea36d356.svg']")
    private WebElement icon3;

    @FindBy(xpath = "//img[@src='https://d34jbachbupkhk.cloudfront.net/assign/static/media/icon_marks.e7367ca4.svg']")
    private WebElement icon4;

    @FindBy(xpath = "//div[text()='Review Questions for ']")
    private WebElement reviewQuestionsTextScreen;

    @FindBy(xpath = "//span[contains(text() , 'Aligned to exams')]")
    private WebElement alignmentToExamsText;

    @FindBy(xpath = "//span[contains(text() , 'Questions')]")
    private WebElement questionsOfReviewTextScreen;

    @FindBy(xpath = "//span[contains(text() , 'Estimated Duration:')]")
    private WebElement estimatedDurationText;

    @FindBy(xpath = "//span[contains(text() , 'marks')]")
    private WebElement marksTextOfReviewQuestion;

    @FindBy(xpath = "//div[contains(text() , 'Embibe Preset Test')]")
    private WebElement embibePresetTestText;

    @FindBy(xpath = "//div[contains(text() , 'Assign')]")
    private WebElement AssignTextOfAssignTest;

    @FindBy(xpath = "//div[contains(text() , 'Due Date')]")
    private WebElement dueDateTextOfAssignTest;

    @FindBy(xpath = "//div[contains(text() , 'Total Marks')]")
    private WebElement totalTimeTextOfAssignTest;

    @FindBy(xpath = "//div[contains(text() , 'Duration')]")
    private WebElement durationTextOfAssignTest;

    @FindBy(xpath = "//div[contains(text() , 'No. of Questions')]")
    private WebElement noOfQuestionTextOfAssignTest;

    @FindBy(xpath = "//div[text()='Name']")
    private WebElement nameOfAssignTestPage;

    @FindBy(xpath = "//div[text()='Chapter']")
    private WebElement ChapterOfAssignTestPage;

    @FindBy(xpath = "//div[text()='Published Date']")
    private WebElement publishedDateOfAssignTest;

    @FindBy(xpath ="//div[text()='Test Date & Time']")
    private WebElement testDateOfAssignTest;

    @FindBy(xpath ="//div[text()='Test Type']")
    private WebElement testTypeOfAssignAssignTest;

    @FindBy(xpath = "//div[text()='Status']")
    private WebElement statusOfAssignTest;

    @FindBy(xpath = "//div[text()='Assigned Homework']")
    private WebElement AssignedHomeworkTextOfAssignTab;

    @FindBy(xpath = "//div[text()='Schedule']")
    private WebElement ScheduleTextOfAssignTab;

    @FindBy(xpath = "//div[@class='title']")
    private WebElement todaysPeriodsText;

    @FindBys({@FindBy(xpath = "//div[@class='p-s-title']")})
    private List<WebElement> calendarElement;

    @FindBy(xpath = "//div[@class='sc-pZOBi bvtUIM switch-handle-online-class']")
    private WebElement onlineClassButton;

    @FindBy(xpath = "//div[text()='Track Detailed Progress']")
    private WebElement trackDetailedProgressText;

    @FindBy(xpath = "//div[text()='PRE-CLASS ACTIONS']")
    private WebElement preClassActionText;

    @FindBy(xpath = "//div[text()='CREATE OR MODIFY LESSON']")
    private WebElement createOrModifyLessonOfPreClassAction;

    @FindBy(xpath = "//div[text()='REVIEW HOMEWORK']")
    private WebElement reviewHomeWorkOfPreClassAction;

    @FindBy(xpath = "//div[text()='REVIEW PREREQUISITE READINESS']")
    private WebElement reviewPreRequisiteReadinessOfPreClassAction;

    @FindBy(xpath = "//div[text()='POST ANNOUNCEMENT']")
    private WebElement PostAnnouncementOfPreClassAction;

    @FindBy(xpath = "//div[text()='POST-CLASS ACTIONS']")
    private  WebElement postClassActionsText;

    @FindBy(xpath = "//div[text()='CHECK LESSON SUMMARY']")
    private WebElement checkLessonSummaryOfPostClassAction;

    @FindBy(xpath = "SET HOMEWORK")
    private WebElement setHomeworkOfPostClassAction;

    @FindBy(xpath = "//div[text()='SET TEST']")
    private WebElement setTestOfPostClassAction;

    @FindBy(xpath = "REVIEW CLASS PROGRESS")
    private WebElement reviewClassProgressOfPostClassAction;

    @FindBy(xpath = "//div[@class='sc-pQEbo lkxNTE']")
    private WebElement liveForeverCheckBox;

    @FindBy(xpath = "(//div[@class='sc-pdkDa gWudTU margin-top-8 cursor-pointer date-wrapper'])[1]")
    private WebElement startDateAndTimeCalender;

    @FindBy(xpath = "(//div[@class='sc-pdkDa gWudTU margin-top-8 cursor-pointer date-wrapper'])[2]")
    private WebElement endDateAndTimeCalender;

    @FindBy(xpath = "//span[text()='easy']")
    private WebElement easyTag;

    @FindBy(xpath = "//span[text()='short']")
    private WebElement shortTag;

    @FindBy(xpath = "//span[text()='medium']")
    private WebElement mediumTag;


    @FindBy(xpath = "//div[text()='Choose a class to assign homework/test']")
    private WebElement ChooseAClassToAssignHomeworkTestText;

    @FindBy(xpath = "//*[contains(@class,'calender-icon-icon')]")
    private WebElement calendarIconOfSchedulePage;

    @FindBy(xpath = "//div[text()='Go to Schedule']")
    private WebElement goToScheduleLink;

    @FindBy(xpath = "//LI[text()='Total duration of this test is ']")
    private WebElement text1OfReviewPage;

    @FindBy(xpath = "//LI[text()='Total marks of this test is ']")
    private WebElement text2OfReviewPage;

    @FindBy(xpath = "//LI[text()=' questions in the test.']")
    private WebElement text3OfReviewPage;

    @FindBy(xpath = "//LI[text()='The following are the sections in the test:']")
    private WebElement text4OfReviewPage;

    @FindBy(xpath = "//span[text()='Sign In using password']")
    private WebElement signInButton;

    @FindBy(xpath = "//input[@class='eds-text-field css-efet9v']")
    private WebElement studentMobileNumberAndEmail;

    @FindBy(xpath = "//input[@class='eds-text-field--password-field css-efet9v']")
    private WebElement password;

    @FindBy(xpath = "//span[text()='Sign In']")
    private WebElement signInButtonOfStudent;

    @FindBys({@FindBy(xpath = "//div[text()='No Topics Selected']//parent::div//parent::div/div/label[text()='10  B']")})
    private  List<WebElement> tenthBClass;

    @FindBy(xpath = "//i[text()='\uE75D']")
    private WebElement arrow;

    @FindBy(xpath = "//span[text()='Log in']")
    private WebElement loginButtonOfStudent;

    @FindBy(xpath = "//span[text()='Set Adaptive Practice']")
    private WebElement setAdaptivePractice;

    @FindBy(xpath = "//span[text()='Set an Achieve Journey']")
    private WebElement setAnAchieveJourney;

    @FindBy(xpath = "//div[text()='Set Homework Type']")
    private WebElement textSetHomeworkType;

    @FindBy(xpath = "//div[text()='Choose the type of Homework you want to Assign']")
    private WebElement text2ofSetHomeworkType;

    @FindBy(xpath = "//div[text()='Unlimited flexibility to create a HW with 3D Learning Videos and Book Questions']")
    private WebElement text3ofSetHomeworkType;

    @FindBy(xpath = "//div[contains(text(),\"Practice Homework that adapts to your student's st\")]")
    private WebElement text4ofSetHomeworkType;

    @FindBy(xpath = "//div[text()='AI-Powered Personalised Learning Journey designed to help students improve']")
    private WebElement text5ofSetHomeworkType;


    @FindBys({@FindBy(xpath = "//div[@class='sc-pjUgp dxglVK']//div[@class='inner-circle']")})
    private List<WebElement> confirmSyllabusOfSetAdaptivePracticeOption;

    @FindBys({@FindBy(xpath = "//div[@class='sc-oTcDH bdkKlq']//div[@class='inner-circle']")})
    private List<WebElement> confirmSyllabusOfSetAnAchieveJourney;

    @FindBy(xpath = "//span[text()='Home']")
    private WebElement homePage;

    @FindBys({@FindBy(xpath = "//img[@class='imgClass0']")})
    private List<WebElement> assignmentAndTestSelection;

    @FindBy(xpath = "((//*[contains(@class,'eds-row eds-row-start eds-row-top')])[4]//div[contains(@class,'sc-')])[2]")
    private WebElement selectAssignment;

    @FindBy(xpath = "(//*[contains(text(),'Close')])[2]")
    private WebElement closeOfSlide;

    @FindBy(xpath = "//i[text()='\uE804']")
    private WebElement closeAssignmentWindow;

    @FindBy(xpath = "//div[@class='sc-zsjhC eYwXoR']")
    private WebElement checkboxIHaveReadAndUnderstoodTheInstructions;

    @FindBy(xpath = "//*[contains(text(),'Start Now')]")
    private WebElement startNow;

    @FindBy(xpath = "//span[text()='Create Your Own Homework']")
    private WebElement createYourOwnHomework;

    @FindBy(xpath = "//*[contains(text(),'Showing Tests available for')]")
    private WebElement testPageData;

    @FindBy(xpath = "//*[contains(text(),'Review Questions for ')]")
    private WebElement reviewQuestionsdata;

    @FindBy(xpath = "//*[contains(text(),'Review Instructions and Schedule Test')]")
    private WebElement reviewInstructionsdata;

    @FindBy(xpath = "//*[contains(text(),'My Assignments')]")
    private WebElement MyAssignments;





















    public void clickOnAssign() {
        wait(2000);
        jsClick(assignButton);

    }
    public void clickMyAssignments(){
        wait(2000);
        jsClick(MyAssignments);
    }
    public void clickOnCreateYourOwnHomework(){
        waitForElementToBeVisible(createYourOwnHomework);
        jsClick(createYourOwnHomework);
    }
    public void clickcloseOfSlide(){
        waitForElementToBeVisible(closeOfSlide);
        jsClick(closeOfSlide);
    }
    public void waitForSometime()
    {
        wait(10000);
    }
    public void selectCheckboxIHaveReadAndUnderstoodTheInstructions(){
        waitForElementToBeVisible(checkboxIHaveReadAndUnderstoodTheInstructions);
        jsClick(checkboxIHaveReadAndUnderstoodTheInstructions);
    }
    public void clickAssignment(){
        wait(5000);
        waitForElementToBeVisible(selectAssignment);
        jsClick(selectAssignment);
    }
    public void clickHomePage(){
        wait(5000);
        waitForElementToBeVisible(homePage);
        jsClick(homePage);
    }
    public void clickStartNow(){
        wait(2000);
        waitForElementToBeVisible(startNow);
        jsClick(startNow);
    }
    public void clearCache(){
        driver.manage().deleteAllCookies();

    }
    public void clickCloseAssignmentWindow(){
        waitForElementToBeVisible(closeAssignmentWindow);
        jsClick(closeAssignmentWindow);
    }
    public void clickLoginButtonOfStudent(){
        wait(5000);
        waitForElementToBeVisible(loginButtonOfStudent);
        jsClick(loginButtonOfStudent);
    }
    public void clickSetAdaptivePractice(){
        waitForElementToBeVisible(setAdaptivePractice);
        jsClick(setAdaptivePractice);
    }
    public void clickSetAnAchieveJourney(){
        waitForElementToBeVisible(setAnAchieveJourney);
        jsClick(setAnAchieveJourney);
    }
    public void clickOnArrow() {
        jsClick(arrow);
    }
    public void clickOnAssignHomeworkTab(){
        jsClick(AssignedHomeworkTextOfAssignTab);
    }
    public void select10B(int value){
        waitForListOfElementToBeVisible(tenthBClass);
        for (int i = 0; i < tenthBClass.size(); i++) {
            if (i ==value){
                WebElement element = tenthBClass.get(i);
                wait(5000);
                jsClick(element);
                break;
            }}


    }
    public void clickSignInButtonOfStudent(){
        waitForElementToBeVisible(signInButtonOfStudent);
        jsClick(signInButtonOfStudent);
    }
    public  void clickTrackDetailedProgressLink(){
        waitForElementToBeVisible(trackDetailedProgressText);
        jsClick(trackDetailedProgressText);
    }
    public void clickOnGoToScheduleLink(){
        waitForElementToBeVisible(goToScheduleLink);
        jsClick(goToScheduleLink);
    }
    public void clickOnCalendarIcon(){
        waitForElementToBeVisible(calendarIconOfSchedulePage);
        jsClick(calendarIconOfSchedulePage);
    }
    public void chooseCalendarOptions(int value){
        waitForListOfElementToBeVisible(calendarElement);
        for (int i = 0; i < calendarElement.size(); i++) {
            if (i ==value){
                WebElement element = calendarElement.get(i);
                wait(5000);
                jsClick(element);
                break;
            }}


    }
    public void chooseAssignmentAndTestSelectionOptions(int value){
        waitForListOfElementToBeVisible(assignmentAndTestSelection);
        for (int i = 0; i < assignmentAndTestSelection.size(); i++) {
            if (i ==value){
                WebElement element = assignmentAndTestSelection.get(i);
                wait(5000);
                jsClick(element);
                break;
            }}


    }
    public void clickOnAssignHomework() {
        jsClick(AssignedHomeworkTextOfAssignTab);
    }
    public void clickSignInButton(){
        wait(5000);
        waitForElementToBeVisible(signInButton);
        jsClick(signInButton);
    }



    public void clickmySchoolsOnStudentApp(){
        waitForElementToBeVisible(mySchoolsOnStudentApp);
        jsClick(mySchoolsOnStudentApp);
    }
    public void clickOnScheduleTab() {
        jsClick(ScheduleTextOfAssignTab);
    }

    public void clickAssignTestTab(){
        waitForElementToBeVisible(assignTestTab);
        jsClick(assignTestTab);
    }
    public boolean isAssignIsPresent(){

        boolean flag = false;
        try {
            Assert.assertTrue(assignButton.isEnabled());
            flag = true;

        }
        catch (NoSuchElementException e){

        }
        return flag;

    }
    public boolean isSchedule(){

        boolean flag = false;
        try {
            Assert.assertTrue(schedule.isEnabled());
            flag = true;

        }
        catch (NoSuchElementException e){

        }
        return flag;
    }
    public void selectAndEnterEmail(){
        waitForElementToBeVisible(studentMobileNumberAndEmail);
        jsClick(studentMobileNumberAndEmail);
        studentMobileNumberAndEmail.sendKeys(Properties.userNameOfStudent);


    }
    public void selectPassword(){
        waitForElementToBeVisible(password);
        jsClick(password);
        password.sendKeys(Properties.passwordOfStudent);


    }
    public void selectConfirmSyllabusOfSetAdaptivePracticeOption(int value){
        waitForListOfElementToBeVisible(confirmSyllabusOfSetAdaptivePracticeOption);
        for (int i = 0; i < confirmSyllabusOfSetAdaptivePracticeOption.size(); i++) {
            if (i ==value){
                WebElement element = confirmSyllabusOfSetAdaptivePracticeOption.get(i);
                wait(5000);
                jsClick(element);
                wait(5000);
                break;
            }}


    }
    public void selectConfirmSyllabusOfSetAnAchieveJourneyOption(int value){
        waitForListOfElementToBeVisible(confirmSyllabusOfSetAnAchieveJourney);
        for (int i = 0; i < confirmSyllabusOfSetAnAchieveJourney.size(); i++) {
            if (i ==value){
                WebElement element = confirmSyllabusOfSetAnAchieveJourney.get(i);
                wait(5000);
                jsClick(element);
                wait(5000);
                break;
            }}


    }

    public void verificationOfTextInShowingTestsAvailablePage(){
        wait(15000);
        softAssert.assertEquals(testQualityScoreText.isDisplayed(),true,"test Quality Score Text is Not displayed");
        softAssert.assertEquals(alignedToExamsText.isDisplayed(),true,"aligned To Exams Text' is Not displayed");
        softAssert.assertEquals(fortyFiveMinsText.isDisplayed(),true,"forty Five Mins Text is Not displayed");
        softAssert.assertEquals(durationText.isDisplayed(),true,"duration Text is Not displayed");
        softAssert.assertEquals(questionText.isDisplayed(),true,"question Text is Not displayed");
        softAssert.assertEquals(marksText.isDisplayed(),true,"marks Text is Not displayed");
        softAssert.assertEquals(selectTestText.isDisplayed(),true,"select TestT ext is Not displayed");
        softAssert.assertEquals(reviewQuestionsText.isDisplayed(),true,"review Questions Text is Not displayed");
        softAssert.assertEquals(reviewInstructionText.isDisplayed(),true,"review Instruction Text is Not displayed");
        softAssert.assertEquals(AssignTestText.isDisplayed(),true,"Assign Test Text is Not displayed");
        softAssert.assertEquals(text1.isDisplayed(),true,"You can only select one Test Pack at a time is Not displayed");
        softAssert.assertAll();

    }
    public void  verifyIconOfShowingTestsAvailablePage(){
        softAssert.assertEquals(icon1.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(icon2.isDisplayed(),true,"duration Icon is Not displayed");
        softAssert.assertEquals(icon3.isDisplayed(),true,"question ICON is Not displayed");
        softAssert.assertEquals(icon4.isDisplayed(),true,"marks ICON is Not displayed");
        softAssert.assertAll();


    }
    public void  verifyAssignTestPageData(){
        softAssert.assertEquals(AssignTextOfAssignTest.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(dueDateTextOfAssignTest.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(totalTimeTextOfAssignTest.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(durationTextOfAssignTest.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(noOfQuestionTextOfAssignTest.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(selectTestText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(reviewQuestionsText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(reviewInstructionText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(AssignTestText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertAll();


    }
    public void verifyReviewQuestionPageData(){
        //softAssert.assertEquals(embibePresetTestText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(alignmentToExamsText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(questionsOfReviewTextScreen.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(estimatedDurationText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(marksTextOfReviewQuestion.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(selectTestText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(reviewQuestionsText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(reviewInstructionText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        softAssert.assertEquals(AssignTestText.isDisplayed(),true,"test Quality Score Icon is Not displayed");
        //softAssert.assertEquals(text1OfReviewPage.isDisplayed(),true," Text  is Not displayed");
        //softAssert.assertEquals(text2OfReviewPage.isDisplayed(),true," Text  is Not displayed");
        //softAssert.assertEquals(text3OfReviewPage.isDisplayed(),true,"  Text is Not displayed");
        //softAssert.assertEquals(text4OfReviewPage.isDisplayed(),true," Text  is Not displayed");
        softAssert.assertAll();


    }

    public void verifyAssignTestPageDataTitle(){
        softAssert.assertEquals(nameOfAssignTestPage.isDisplayed(),true,"name Of Assign Test Page Icon is Not displayed");
        softAssert.assertEquals(ChapterOfAssignTestPage.isDisplayed(),true,"Chapter Of Assign Test Page is Not displayed");
        softAssert.assertEquals(publishedDateOfAssignTest.isDisplayed(),true,"published Date Of Assign Test is Not displayed");
        softAssert.assertEquals(testDateOfAssignTest.isDisplayed(),true,"test Date Of Assign Test is Not displayed");
        softAssert.assertEquals(testTypeOfAssignAssignTest.isDisplayed(),true,"test Type Of  Assign Test is Not displayed");
        softAssert.assertAll();



    }
    public void AssignTabVerification(){
        softAssert.assertEquals(ScheduleTextOfAssignTab.isDisplayed(),true,"Schedule Text Of AssignTab Test Page Icon is Not displayed");
        softAssert.assertEquals(AssignedHomeworkTextOfAssignTab.isDisplayed(),true,"Assigned Homework Text Of AssignTab Page Icon is Not displayed");
        softAssert.assertEquals(assignTestTab.isDisplayed(),true,"assign Test Tab is Not displayed");
        softAssert.assertAll();
    }
    public void PrePostAssignTabVerification(){
        softAssert.assertEquals(todaysPeriodsText.isDisplayed(),true,"today's Periods Text Of AssignTab Test Page  is Not displayed");
        softAssert.assertEquals(goToScheduleLink.isDisplayed(),true,"go To Schedule Link on Assign Tab Test Page  is Not displayed");

        softAssert.assertEquals(onlineClassButton.isDisplayed(),true,"online Class Button Of AssignTab Test Page Icon is Not displayed");
        softAssert.assertEquals(trackDetailedProgressText.isDisplayed(),true,"track Detailed Progress Text Test Page  is Not displayed");
        softAssert.assertEquals(createOrModifyLessonOfPreClassAction.isDisplayed(),true,"create Or Modify Lesson Of Pre Class Action Text  is Not displayed");
        softAssert.assertEquals(reviewPreRequisiteReadinessOfPreClassAction.isDisplayed(),true,"review Pre Requisite Readiness Of Pre Class Action Text  is Not displayed");
        softAssert.assertEquals(reviewHomeWorkOfPreClassAction.isDisplayed(),true,"review HomeWork Of Pre Class Action Text  is Not displayed");
        softAssert.assertEquals(PostAnnouncementOfPreClassAction.isDisplayed(),true,"Post Announcement Of Pre Class Action Text  is Not displayed");
        softAssert.assertEquals(preClassActionText.isDisplayed(),true,"Post Announcement Of Pre Class Action Text  is Not displayed");
        softAssert.assertEquals(postClassActionsText.isDisplayed(),true,"post Class Actions Text  is Not displayed");
        softAssert.assertEquals(checkLessonSummaryOfPostClassAction.isDisplayed(),true,"check Lesson Summary Of Post Class Action Text  is Not displayed");
        softAssert.assertEquals(setHomeworkOfPostClassAction.isDisplayed(),true,"set Homework Of Post Class Action Text  is Not displayed");
        softAssert.assertEquals(setTestOfPostClassAction.isDisplayed(),true,"set Test Of Post Class Action Text  is Not displayed");
        softAssert.assertEquals(reviewClassProgressOfPostClassAction.isDisplayed(),true,"review Class Progress Of Post Class Action Text  is Not displayed");



        softAssert.assertAll();
    }

    public void firstAndLastDateOfTheYear(){
        LocalDate now = LocalDate.now(); // 2015-11-23
        LocalDate firstDay = now.with(firstDayOfYear()); // 2015-01-01
        LocalDate lastDay = now.with(lastDayOfYear());
        System.out.println(firstDay);
        System.out.println(lastDay);


    }
    public void VerifyTextOfSchedulePage(){
        softAssert.assertEquals(ChooseAClassToAssignHomeworkTestText.isDisplayed(),true,"Choose A Class To Assign Homework Test Text  is Not displayed");



        softAssert.assertAll();
    }

    public void VerifySetHomeWorkTypePageData(){
        softAssert.assertEquals(text5ofSetHomeworkType.isDisplayed(),true,"text5 of Set Homework Type Text  is Not displayed");
        softAssert.assertEquals(text4ofSetHomeworkType.isDisplayed(),true,"text 4 of Set Homework Type Text  is Not displayed");
        softAssert.assertEquals(text3ofSetHomeworkType.isDisplayed(),true,"text 3 of Set Homework Type Text  is Not displayed");
        softAssert.assertEquals(text2ofSetHomeworkType.isDisplayed(),true,"text 2 of Set Homework Type Text  is Not displayed");
        softAssert.assertEquals(textSetHomeworkType.isDisplayed(),true,"text Set Homework Type Text  is Not displayed");
        softAssert.assertEquals(setAnAchieveJourney.isDisplayed(),true,"set An Achieve Journey Test Text  is Not displayed");
        softAssert.assertEquals(setAdaptivePractice.isDisplayed(),true,"set Adaptive Practice Text  is Not displayed");



        softAssert.assertAll();
    }

    public boolean verifyTestData(){
        softAssert.assertEquals(testPageData.isDisplayed(),true,"SelectTestPage data is avilable");
        softAssert.assertAll();
        return false;
    }

    public boolean verifyReviewQuestionData(){
        softAssert.assertEquals(reviewQuestionsdata.isDisplayed(),true,"review Questions data data is avilable");
        softAssert.assertAll();
        return false;
    }

    public boolean verifyInstructionData(){
        softAssert.assertEquals(reviewInstructionsdata.isDisplayed(),true," review Instructions data Data data is available");
        softAssert.assertAll();
        return false;
    }

    public void waiting(){
        wait(15000);
    }




}
