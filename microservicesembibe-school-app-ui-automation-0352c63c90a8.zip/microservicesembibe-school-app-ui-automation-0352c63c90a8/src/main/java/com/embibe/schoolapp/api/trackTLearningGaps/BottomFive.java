
package com.embibe.schoolapp.api.trackTLearningGaps;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class BottomFive {

    @SerializedName("label")
    @Expose
    private String label;
    @SerializedName("data")
    @Expose
    private List<Object> data = null;

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public List<Object> getData() {
        return data;
    }

    public void setData(List<Object> data) {
        this.data = data;
    }

}
