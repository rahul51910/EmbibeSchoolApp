
package com.embibe.schoolapp.api.trackOverView;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class EffortInsights {

    @SerializedName("sectionDescription")
    @Expose
    private String sectionDescription;
    @SerializedName("data")
    @Expose
    private List<Datum__1> data = null;

    public String getSectionDescription() {
        return sectionDescription;
    }

    public void setSectionDescription(String sectionDescription) {
        this.sectionDescription = sectionDescription;
    }

    public List<Datum__1> getData() {
        return data;
    }

    public void setData(List<Datum__1> data) {
        this.data = data;
    }

}
