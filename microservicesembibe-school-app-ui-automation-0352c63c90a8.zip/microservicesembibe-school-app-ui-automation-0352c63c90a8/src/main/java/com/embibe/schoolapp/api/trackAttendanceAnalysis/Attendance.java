
package com.embibe.schoolapp.api.trackAttendanceAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Attendance {

    @SerializedName("attendancePercentage")
    @Expose
    private Integer attendancePercentage;
    @SerializedName("changeSinceLast")
    @Expose
    private Double changeSinceLast;

    public Integer getAttendancePercentage() {
        return attendancePercentage;
    }

    public void setAttendancePercentage(Integer attendancePercentage) {
        this.attendancePercentage = attendancePercentage;
    }

    public Double getChangeSinceLast() {
        return changeSinceLast;
    }

    public void setChangeSinceLast(Double changeSinceLast) {
        this.changeSinceLast = changeSinceLast;
    }

}
