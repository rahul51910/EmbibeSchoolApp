package com.embibe.schoolapp.pages.myhome.attendance;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import java.util.ArrayList;
import java.util.List;

public class AttendancePage extends BasePage {

    @FindBy(xpath = "//div[text()='Attendance']")
    private WebElement attendance;

    @FindBy(css = ".tbody-main>.td-row-wrapper")
    private List<WebElement> studentRows;

    @FindBy(xpath = "//div[@class='tbody-main']/div[1]//div[contains(@class,'checkbox-main ')]")
    private WebElement attendanceStatus;

    @FindBy(xpath = "//div[@class='tbody-main']/div[1]//div[@class='checkbox-tick']")
    private WebElement attendanceBox;

    @FindBy(xpath = "//input[@placeholder='search by student']")
    private WebElement searchStudent;

    @FindBy(xpath ="//*[contains(text(),'Today')]/../div[1]/div/div[1]" )
    private WebElement count;

    @FindBy(xpath = "//*[contains(@class,'sc-pt')][normalize-space()='']")
    private WebElement percentage;

    @FindBy(xpath = "//div[text()='Average Attendance']/../div[1]/div/div[1]")
    private WebElement average;

    @FindBy(xpath ="//div[text()='Perfect Attendance']/../div[1]/div/div[1]")
    private WebElement perfect;

    @FindBy(xpath = "//div[text()='Below average attendance']/../div[1]/div/div[1]")
    private WebElement belowAverage;

    @FindBy(css = ".pages-info>div")
    private List<WebElement> totalPages;

    @FindBy(css = ".navigation-block>div:nth-child(3)")
    private WebElement navigateForward;


    public AttendancePage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }



    public boolean isAttendanceHeaderDisplaying(){
        wait(2000);
        return waitForElementToBeDisplay(attendance);
    }
    public void clickOnNavigateForward(){
        scrollToView(navigateForward);
        waitForElementToBeVisible(navigateForward);
        jsClick(navigateForward);
    }
    public int getStudentsCount(){
        waitForListOfElementToBeVisible(studentRows);
        return studentRows.size();
//        try{
//            if (totalPages.size()>0){
//                for (int i = 1; i <=totalPages.size() ; i++) {
//                    total = total+studentRows.size();
//                    clickOnNavigateForward();
//                }
//            }
//        }catch (Exception e){
//            e.printStackTrace();
//            waitForListOfElementToBeVisible(studentRows);
//            total= studentRows.size();
//
//        }finally {
//            return total;
//        }

    }

    public String getAttendanceStatus(){
        wait(2000);
        String value = attendanceStatus.getAttribute("class");
        return value;
    }

    public void clickToAbsent(){
        wait(2000);
        jsClick(attendanceBox);
    }
    public void clickToPresent(){
        wait(2000);
        jsClick(attendanceStatus);
    }

    public void setSearchStudent(String value){
        waitForElementToBeVisible(searchStudent);
        searchStudent.sendKeys(value);
        wait(2000);
    }
    public List<String> getAttendancePercentageFromUI(){
        List<String> list = new ArrayList<>();
        waitForListOfElementToBeVisible(studentRows);
        for (int i = 1; i <=studentRows.size() ; i++) {
            WebElement element = driver.findElement(By.cssSelector(".tbody-main> .td-row-wrapper:nth-child("+i+")>div>div:nth-child(8)"));
            list.add(element.getText());
        }
        return list;
    }
    public void navigateBack(){
        driver.navigate().back();
        wait(2000);
    }
    public String getAttendanceCount(){
        wait(2000);
        waitForElementToBeVisible(count);
        return count.getText();
    }
    public String getAttendancePercentage(){
        wait(5000);
        waitForElementToBeVisible(percentage);
        return percentage.getText();
    }
    public String getBelowAvgAttendance(){
        waitForElementToBeVisible(belowAverage);
        return belowAverage.getText();
    }
    public String getAvgAttendance(){
        waitForElementToBeVisible(average);
        return average.getText();
    }
    public String getPerfectAttendance(){
        waitForElementToBeVisible(perfect);
        return perfect.getText();
    }


}
