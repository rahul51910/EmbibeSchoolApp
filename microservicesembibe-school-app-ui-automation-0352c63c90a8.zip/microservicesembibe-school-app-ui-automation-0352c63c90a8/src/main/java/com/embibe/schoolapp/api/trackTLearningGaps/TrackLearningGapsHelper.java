
package com.embibe.schoolapp.api.trackTLearningGaps;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class TrackLearningGapsHelper {

    @SerializedName("occurred")
    @Expose
    private Occurred occurred;
    @SerializedName("resolved")
    @Expose
    private Resolved resolved;
    @SerializedName("topFive")
    @Expose
    private TopFive topFive;
    @SerializedName("bottomFive")
    @Expose
    private BottomFive bottomFive;

    public Occurred getOccurred() {
        return occurred;
    }

    public void setOccurred(Occurred occurred) {
        this.occurred = occurred;
    }

    public Resolved getResolved() {
        return resolved;
    }

    public void setResolved(Resolved resolved) {
        this.resolved = resolved;
    }

    public TopFive getTopFive() {
        return topFive;
    }

    public void setTopFive(TopFive topFive) {
        this.topFive = topFive;
    }

    public BottomFive getBottomFive() {
        return bottomFive;
    }

    public void setBottomFive(BottomFive bottomFive) {
        this.bottomFive = bottomFive;
    }

}
