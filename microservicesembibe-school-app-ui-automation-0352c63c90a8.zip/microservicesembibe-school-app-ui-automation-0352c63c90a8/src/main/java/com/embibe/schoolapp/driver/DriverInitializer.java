package com.embibe.schoolapp.driver;

import com.embibe.schoolapp.driver.driverfactory.ChromeBrowser;
import com.embibe.schoolapp.driver.driverfactory.FirefoxBrowser;
import com.embibe.schoolapp.driver.driverfactory.IeBrowser;
import com.embibe.schoolapp.driver.driverfactory.SafariBrowser;
import com.embibe.schoolapp.utils.Browsers;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

public class DriverInitializer {
    private String browser;

    public DriverInitializer(String browser) {
        this.browser = browser;
    }

    public WebDriver init() throws Exception {

        WebDriver webDriver = null;

        switch (browser) {
            case Browsers.CHROME:
                webDriver = new ChromeBrowser().getDriver();
                webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
                webDriver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
                webDriver.manage().deleteAllCookies();
                break;

            case Browsers.FIREFOX:
                webDriver = new FirefoxBrowser().getDriver();
                webDriver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
                webDriver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
                webDriver.manage().deleteAllCookies();
                break;

            case Browsers.IE:
                webDriver = new IeBrowser().getDriver();
                break;

            case Browsers.SAFARI:
                webDriver= new SafariBrowser().getDriver();

            default:

        }

        DriverProvider.setDriver(webDriver);
        return webDriver;
    }
}
