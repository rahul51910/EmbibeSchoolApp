
package com.embibe.schoolapp.api.trackAttendanceAnalysis;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class TrackAttendanceAnalysisHelper {

    @SerializedName("attendanceHighlights")
    @Expose
    private AttendanceHighlights attendanceHighlights;
    @SerializedName("attendanceGraph")
    @Expose
    private List<AttendanceGraph> attendanceGraph = null;

    public AttendanceHighlights getAttendanceHighlights() {
        return attendanceHighlights;
    }

    public void setAttendanceHighlights(AttendanceHighlights attendanceHighlights) {
        this.attendanceHighlights = attendanceHighlights;
    }

    public List<AttendanceGraph> getAttendanceGraph() {
        return attendanceGraph;
    }

    public void setAttendanceGraph(List<AttendanceGraph> attendanceGraph) {
        this.attendanceGraph = attendanceGraph;
    }

}
