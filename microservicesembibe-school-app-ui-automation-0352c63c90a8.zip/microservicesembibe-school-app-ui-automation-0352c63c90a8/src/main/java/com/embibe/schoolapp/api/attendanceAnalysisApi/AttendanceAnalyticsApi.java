
package com.embibe.schoolapp.api.attendanceAnalysisApi;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class AttendanceAnalyticsApi {

    @SerializedName("attendance_percentage")
    @Expose
    private AttendancePercentage attendancePercentage;
    @SerializedName("analytics_data")
    @Expose
    private AnalyticsData analyticsData;

    public AttendancePercentage getAttendancePercentage() {
        return attendancePercentage;
    }

    public void setAttendancePercentage(AttendancePercentage attendancePercentage) {
        this.attendancePercentage = attendancePercentage;
    }

    public AnalyticsData getAnalyticsData() {
        return analyticsData;
    }

    public void setAnalyticsData(AnalyticsData analyticsData) {
        this.analyticsData = analyticsData;
    }

}
