package com.embibe.schoolapp.pages.login;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage extends BasePage {

    @FindBy(xpath = "//input[@type='email']")
    private WebElement email;

    @FindBy(xpath = "//input[@type='password']")
    private WebElement password;

    @FindBy(xpath = "//span[text()='Sign in']")
    private WebElement signInButton;

    @FindBy(css = ".google-signin-label")
    private WebElement loginWithGoogleAuth;



    public LoginPage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void setEmail(String value){
        waitForElementToBeVisible(email);
        email.sendKeys(value);
    }
    public void setPassword(String value){
        waitForElementToBeVisible(password);
        password.sendKeys(value);
    }

    public void clickOnSignInButton(){
        waitForElementToBeClickable(signInButton);
        if (signInButton.isDisplayed() && signInButton.isEnabled()){
            signInButton.click();
        }
    }

    public void login(String email,String password){
        setEmail(email);
        wait(2000);
        setPassword(password);
        wait(3000);
        clickOnSignInButton();
        wait(5000);
    }


    public boolean isEmailTextBoxDisplayed(){
        return waitForElementToBeDisplay(email);
    }

    public boolean isPasswordTextBoxDisplayed(){
        return waitForElementToBeDisplay(email);
    }
    public boolean isSignInButtonDisplayed(){
        return waitForElementToBeDisplay(email);
    }
    public boolean isSignInWithGoogleAuthButtonDisplayed(){
        return waitForElementToBeDisplay(loginWithGoogleAuth);
    }


}
