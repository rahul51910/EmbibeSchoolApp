package com.embibe.schoolapp.pages.myhome.myschedule;

import com.embibe.schoolapp.driver.DriverProvider;
import com.embibe.schoolapp.pages.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;
import java.time.LocalDate;
import java.time.Month;
import java.util.List;

public class MySchedulePage extends BasePage {

    @FindBy(css = ".calendar-icon")
    private WebElement calendarIcon;

    @FindBy(xpath = "//div[text()='My Schedule']")
    private WebElement mySchedule;

    @FindBy(xpath = "//div[@class='calendar-table']/table/thead/tr[1]/th[2]")
    private WebElement getCalendarHead;

    @FindBy(xpath = "//div[contains(@class,'content-grid-wrapper')]/div")
    private List<WebElement> timeTableDays;

    @FindBy(xpath = "//div[contains(@class,'period-slot-container')]")
    private List<WebElement> totalAllottedPeriodsOnCurrentWeek;

    @FindBy(xpath = "//div[@class='period-slot-container']/..")
    private List<WebElement> periodsStatus;

    @FindBy(xpath = "//div[contains(@class,'tt-main-content')]/div/div[1]/div")
    private List<WebElement> totalPeriodsForTheDay;

//    @FindBy(xpath = "//div[@class='date-range-picker']/following-sibling::div/div[2]")
    @FindBy(css = ".date-range-picker +div>div:nth-child(2)>svg")
    private WebElement calendarNextButton;

    @FindBy(css = ".th-date")
    private List<WebElement> calendarDays;

    @FindBy(css = ".periods-wrapper>div")
    private List<WebElement> todayPeriods;

    @FindBy(css = ".middle-wrapper .s-name")
    private List<WebElement> periodSubjects;

    @FindBy(xpath ="//div[text()='PRE-CLASS ACTIONS']")
    private WebElement preClassActions;

    @FindBy(xpath = "//div[text()='POST-CLASS ACTIONS']")
    private WebElement postClassActions;

    @FindBy(xpath ="//div[text()='Pre and Post Class Actions']")
    private WebElement preAndPostViewTab;

    @FindBy(css = ".p-s-header >img")
    private List<WebElement> periodActions;

    @FindBy(css = ".p-s-header>label")
    private List<WebElement> periodClasses;

    @FindBy(xpath ="(//*[contains(text(),'Classes')])[2]")
    private WebElement classes;

    @FindBys({@FindBy(xpath = "(//*[contains(text(),'Classes')])[2]//following::div[2]//*[contains(@class,'checkbox-tick') ]")})
    private WebElement classesOption;

    @FindBy(xpath = "//*[contains(text(),'Subjects')]")
    private WebElement subjects;

    @FindBy(xpath = "//*[contains(text(),'Subjects')]//following::div[2]//*[contains(@class,'checkbox-tick') ]")
    private WebElement selectSubject;




    public MySchedulePage(){
        driver = DriverProvider.getDriver();
        PageFactory.initElements(driver,this);
    }

    public void clickOnMySchedule(){
        waitForElementToBeVisible(mySchedule);
        mySchedule.click();
        wait(2000);
    }
    public void clickOnClassesDropdown(){
        jsClick(classes);
    }
    public void clicksubjects(){
        jsClick(subjects);
    }
    public boolean verifySchedulePageURL(String str){
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        boolean value =pageUrl.equals(str);
        return  value;
    }
    public Boolean isCalendarIconDisplaying(){
        return waitForElementToBeDisplay(calendarIcon);
    }
    public void clickOnCalendar(){
        wait(2000);
        waitForElementToBeVisible(calendarIcon);
        calendarIcon.click();
    }
    public String getCalendarHeaderText(){
        waitForElementToBeVisible(getCalendarHead);
        return getCalendarHead.getText();
    }
    public Month getCurrentMonth(){
        LocalDate currentDate = LocalDate.now();
        return currentDate.getMonth();
    }
    public int getCurrentYear(){
        LocalDate currentDate = LocalDate.now();
        return currentDate.getYear();
    }

    public int getTimeTableDays(){
        waitForListOfElementToBeVisible(timeTableDays);
        return timeTableDays.size();
    }

    public int getTotalAllottedPeriods(){
        waitForListOfElementToBeVisible(totalAllottedPeriodsOnCurrentWeek);
        return totalAllottedPeriodsOnCurrentWeek.size();
    }
    public int getTotalPeriodsPerDay(){
        waitForListOfElementToBeVisible(totalPeriodsForTheDay);
        return totalPeriodsForTheDay.size();
    }
    public void clickOnCalendarNextButton(){
        wait(2000);
        waitForElementToBeVisible(calendarNextButton);
        calendarNextButton.click();
    }
    public int getNextWeekDay(){
        LocalDate currentDate = LocalDate.now();
        return currentDate.plusDays(7).getDayOfMonth();
    }
    public Boolean isCalendarMovesToNextWeek(int day){
        wait(3000);
        boolean flag = false;
        try{
            waitForListOfElementToBeVisible(calendarDays);
            for (int i = 0; i < calendarDays.size(); i++) {
                WebElement element = calendarDays.get(i);
                if (Integer.parseInt(element.getText())== day ){
                    flag = true;
                    break;
                }
            }
        }catch (Exception e){
            e.printStackTrace();
            flag = false;
        }finally {
            return flag;
        }

    }
    public void selectClasses(int i){
        waitForElementToBeDisplay(classesOption);
        jsClick(classesOption);
        wait(2000);

    }
    public void selectSubjects(int i){
        waitForElementToBeVisible(selectSubject);
        jsClick(selectSubject);
        wait(2000);
    }
    public void clickOnAnyAllottedPeriod(){
        waitForListOfElementToBeVisible(periodsStatus);
        for (int i = 0; i < periodsStatus.size(); i++) {
            WebElement element = periodsStatus.get(i);
            String value = element.getAttribute("class");
            if (!value.contains("disabled")){
                WebElement element1 = totalAllottedPeriodsOnCurrentWeek.get(i);
                element1.click();
                break;
            }
        }
    }
    public int getTodayPeriodsCount(){
        waitForListOfElementToBeVisible(todayPeriods);
        return  todayPeriods.size();
    }
    public Boolean verifyNavigateToTeachPage(String text){
        waitForPageToLoad();
        String pageUrl = driver.getCurrentUrl();
        return pageUrl.contains(text);
    }

    public Boolean postClassActionsAreDisplaying(){
        return waitForElementToBeDisplay(postClassActions);
    }
    public void clickOnPreAndPostActionsTab(){
        waitForElementToBeVisible(preAndPostViewTab);
        jsClick(preAndPostViewTab);
    }
    public Boolean preClassActionsAreDisplaying(){
        return waitForElementToBeDisplay(preClassActions);
    }
    public boolean isActionUpdated(){
        boolean flag = false;
        waitForListOfElementToBeVisible(periodActions);
        for (int i = 0; i < periodActions.size(); i++) {
            WebElement element = periodsStatus.get(i);
            String value = element.getAttribute("class");
            if (!value.contains("disabled")){
                WebElement element1 = periodActions.get(i);
                String initial = element1.getAttribute("src");
                System.out.println("the initial Image value "+initial);
                if (initial.equals("https://d34jbachbupkhk.cloudfront.net/home/static/media/video-icon.dc0395a5.svg")){
                    element1.click();
                    String updatedFirst = element1.getAttribute("src");
                    System.out.println(updatedFirst+": First one");
                    flag = !updatedFirst.equals("https://d34jbachbupkhk.cloudfront.net/home/static/media/classroom-icon.bc46a4d1.svg");
                }else {
                    element1.click();
                    String updatedSecond = element1.getAttribute("src");
                    System.out.println(updatedSecond+": second one");
                    flag = !updatedSecond.equals("https://d34jbachbupkhk.cloudfront.net/home/static/media/video-icon.dc0395a5.svg");
                }
                break;
            }
        }
        return flag;
    }
    public boolean isClassesAppearOnPeriods(){
        boolean flag = true;
        waitForListOfElementToBeVisible(periodClasses);
        for (int i = 0; i < periodClasses.size(); i++) {
            WebElement element = periodsStatus.get(i);
            String value = element.getAttribute("class");
            if (!value.contains("disabled")) {
                WebElement element1 = periodClasses.get(i);
                String classText = element1.getText();
                if (classText == null){
                    flag = false;
                    break;
                }
            }
        }
        return flag;
    }

}
