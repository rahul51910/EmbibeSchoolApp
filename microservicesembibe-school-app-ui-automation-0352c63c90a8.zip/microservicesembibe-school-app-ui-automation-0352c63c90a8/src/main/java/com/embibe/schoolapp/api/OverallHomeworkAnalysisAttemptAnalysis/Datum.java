
package com.embibe.schoolapp.api.OverallHomeworkAnalysisAttemptAnalysis;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Datum {

    @SerializedName("attemptType")
    @Expose
    private String attemptType;
    @SerializedName("attemptCount")
    @Expose
    private Double attemptCount;
    @SerializedName("attemptKey")
    @Expose
    private String attemptKey;

    public String getAttemptType() {
        return attemptType;
    }

    public void setAttemptType(String attemptType) {
        this.attemptType = attemptType;
    }

    public Double getAttemptCount() {
        return attemptCount;
    }

    public void setAttemptCount(Double attemptCount) {
        this.attemptCount = attemptCount;
    }

    public String getAttemptKey() {
        return attemptKey;
    }

    public void setAttemptKey(String attemptKey) {
        this.attemptKey = attemptKey;
    }

}
