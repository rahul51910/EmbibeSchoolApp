
package com.embibe.schoolapp.api.attendancePageData;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class AttendancePageData {

    @SerializedName("data")
    @Expose
    private List<Datum> data = null;
    @SerializedName("headers")
    @Expose
    private List<Header> headers = null;
    @SerializedName("paginationParams")
    @Expose
    private PaginationParams paginationParams;

    public List<Datum> getData() {
        return data;
    }

    public void setData(List<Datum> data) {
        this.data = data;
    }

    public List<Header> getHeaders() {
        return headers;
    }

    public void setHeaders(List<Header> headers) {
        this.headers = headers;
    }

    public PaginationParams getPaginationParams() {
        return paginationParams;
    }

    public void setPaginationParams(PaginationParams paginationParams) {
        this.paginationParams = paginationParams;
    }

}
