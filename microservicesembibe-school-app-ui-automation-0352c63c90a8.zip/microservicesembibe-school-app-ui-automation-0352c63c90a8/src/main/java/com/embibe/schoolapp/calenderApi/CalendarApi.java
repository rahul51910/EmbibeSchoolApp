
package com.embibe.schoolapp.calenderApi;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class CalendarApi {

    @SerializedName("totalRecordCount")
    @Expose
    private Integer totalRecordCount;
    @SerializedName("successCount")
    @Expose
    private Integer successCount;
    @SerializedName("failedCount")
    @Expose
    private Integer failedCount;
    @SerializedName("trackerId")
    @Expose
    private String trackerId;

    public Integer getTotalRecordCount() {
        return totalRecordCount;
    }

    public void setTotalRecordCount(Integer totalRecordCount) {
        this.totalRecordCount = totalRecordCount;
    }

    public Integer getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(Integer successCount) {
        this.successCount = successCount;
    }

    public Integer getFailedCount() {
        return failedCount;
    }

    public void setFailedCount(Integer failedCount) {
        this.failedCount = failedCount;
    }

    public String getTrackerId() {
        return trackerId;
    }

    public void setTrackerId(String trackerId) {
        this.trackerId = trackerId;
    }

}
