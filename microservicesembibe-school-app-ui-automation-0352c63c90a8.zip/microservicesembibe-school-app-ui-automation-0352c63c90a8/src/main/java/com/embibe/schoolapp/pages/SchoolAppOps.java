package com.embibe.schoolapp.pages;

import com.embibe.schoolapp.api.OverallHomeworkAnalysisAttemptAnalysis.AttemptAnalysisAPIHelper;
import com.embibe.schoolapp.api.show.ShowHelper;
import com.embibe.schoolapp.api.trackOverView.TrackOverViewHelper;
import com.embibe.schoolapp.api.trackStudentWiseAnalysis.TrackStudentwiseHelper;
import com.embibe.schoolapp.api.trackSyllabusCoverage.HelperSyllabusCoverage;
import com.embibe.schoolapp.api.trackTLearningGaps.TrackLearningGapsHelper;
import com.embibe.schoolapp.api.trackTeachAnalysis.TrackTeachAnalysisHelper;
import com.embibe.schoolapp.api.trackTestAnalysis.TrackTestAnalysisHelper;
import com.embibe.schoolapp.utils.Properties;
import io.restassured.RestAssured;
import io.restassured.config.RestAssuredConfig;
import io.restassured.filter.log.RequestLoggingFilter;
import io.restassured.filter.log.ResponseLoggingFilter;
import io.restassured.http.Headers;
import io.restassured.mapper.ObjectMapperType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.commons.lang3.SystemUtils;
import org.json.JSONObject;
import org.testng.Assert;


import java.io.File;
import java.time.*;
import java.util.*;

import static io.restassured.RestAssured.given;

public class SchoolAppOps {


    Response response = null;
    RestAssuredConfig config = null;

    private static final ZoneId defaultZoneId = ZoneId.systemDefault();
    public  Map<String, Map<String,Object>> getTeacherClasses(String EmbibetokenForAPI){
        Map<String, Map<String,Object>> classInfoMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",EmbibetokenForAPI).log().all();
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> classList = response.path("classDetails");
        for (int i = 0; i < classList.size(); i++) {
            Map<String,Object> classMap = classList.get(i);
            Map<String,Object> detailsMap = new LinkedHashMap<>();
            detailsMap.put("section",classMap.get("section").toString());
            List<Map<String,Object>> subjectList = ( List<Map<String,Object>>)classMap.get("subjects");
            for (int j = 0; j < subjectList.size(); j++) {
                Map<String,Object> subjectMap = subjectList.get(j);
                detailsMap.put("subjectName",subjectMap.get("name").toString());
                detailsMap.put("studentCount",subjectMap.get("studentCount"));
                detailsMap.put("classOrgId",classMap.get("classOrgId"));
            }
            classInfoMap.put(classMap.get("name").toString(),detailsMap);
        }
        return classInfoMap;
    }

    public   Map<String,Object> getTeacherIdAndSchoolId(String EmbibetokenForAPI,String className){

        Map<String,Object> classInfoMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",EmbibetokenForAPI);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> classList = response.path("classDetails");
        for (int i = 0; i < classList.size(); i++) {
            Map<String,Object> classMap = classList.get(i);
            if(classMap.get("name").toString().equals(className)){
                List<Map<String,Object>> subjectList = ( List<Map<String,Object>>)classMap.get("subjects");
                for (int j = 0; j < subjectList.size(); j++) {
                    Map<String,Object> subjectMap = subjectList.get(j);
                    classInfoMap.put("subjectName",subjectMap.get("name").toString());
                    classInfoMap.put("studentCount",subjectMap.get("studentCount"));
                    classInfoMap.put("classOrgId",classMap.get("classOrgId"));
                    classInfoMap.put("subjectKveCode",subjectMap.get("subjectKveCode"));
                }
                classInfoMap.put("teacherId",response.path("adminId"));
                classInfoMap.put("schoolId",response.path("parentOrganizationId"));
                break;
            }
        }
        return classInfoMap;
    }


    public   Map<String,Object> getPersonalDetails(String EmbibetokenForAPI){

        Map<String,Object> personalMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",EmbibetokenForAPI);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        Map<String,Object> personalDetails = response.path("personalDetails");
        personalMap.put("emailId",personalDetails.get("emailId"));
        personalMap.put("mobileNumber",personalDetails.get("mobileNumber"));
        personalMap.put("firstName",personalDetails.get("firstName"));
        return personalMap;
    }



    public Map<String,Object>  verifyGetTeacherSubjectNextSlot(String resellerJwtToken,String classId, String subjectName){
        Map<String,Object> nextSlotMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.teacherNextSlotBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",resellerJwtToken);
        request.header("Content-Type","application/json");
        request.queryParam("classId",classId);
        request.queryParam("subjectName",subjectName);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        nextSlotMap.put("name",response.path("name"));
        nextSlotMap.put("startTime",response.path("startTime"));
        nextSlotMap.put("endTime",response.path("endTime"));
        nextSlotMap.put("date",response.path("date"));
        return nextSlotMap;
    }

    public Map<String,Object> getTimeTableDataForTheCurrentWeek(String resellerJwtToken){
        int totalAllottedPeriods = 0;
        Map<String,Object> timeTableInfoMap = new LinkedHashMap<>();
        Long startTime = getEpochByDateTime(LocalDate.now().with(DayOfWeek.MONDAY), LocalTime.of(00, 00));
        Long endTime = getEpochByDateTime(LocalDate.now().with(DayOfWeek.SUNDAY), LocalTime.of(23, 59));
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.teacherCalendarBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",resellerJwtToken);
        request.header("Content-Type","application/json");
        request.queryParam("startTime",startTime);
        request.queryParam("endTime",endTime);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> totalPeriodsPerDay = response.path("metaData.slotInfo");
        List<Map<String,Object>> timeTableDays = response.path("headers");
        Map<String,Object> daySlotsMap = response.path("data");
        Set<String> daysSet = daySlotsMap.keySet();
        for (String day:daysSet) {
          List<Map<String,Object>> periodList = (List<Map<String,Object>>) daySlotsMap.get(day);
            for (int i = 0; i < periodList.size(); i++) {
                Map<String,Object> periodsMap = periodList.get(i);
                if (periodsMap.get("id") != null){
                    totalAllottedPeriods++;
                }
            }
        }
        timeTableInfoMap.put("periodsPerDay",totalPeriodsPerDay.size());
        timeTableInfoMap.put("timeTableDaysForWeek",timeTableDays.size());
        timeTableInfoMap.put("totalAllottedPeriods",totalAllottedPeriods);
        return timeTableInfoMap;

    }

    public Map<String,Map<String,Object>> verifyTodayPeriods(String resellerJWTToken){
        Map<String,Map<String,Object>> slotMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.todayPeriodsBasePath;
        RequestSpecification request = given().config(config).filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",resellerJWTToken);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> actualSlotList = response.path("data");
        for (int i = 0; i < actualSlotList.size(); i++) {
            Map<String,Object> infoMap = new LinkedHashMap<>();
            Map<String,Object> slotInfo = actualSlotList.get(i);
            infoMap.put("subjectName",slotInfo.get("subjectName"));
            infoMap.put("classType",slotInfo.get("classType"));
            infoMap.put("classId",slotInfo.get("classId"));
            slotMap.put(slotInfo.get("id").toString(),infoMap);
        }
        return slotMap;
    }


    public int getListOfFilesShared(String resellerJWTToken){
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.filesSharedBasePath;
        RequestSpecification request = given().config(config).filters(new ResponseLoggingFilter(), new RequestLoggingFilter());
        request.header("Content-Type","application/json");
        request.header("reseller-jwt-token",resellerJWTToken);
        response = request.get();
        Assert.assertEquals(response.statusCode(),200);
        List<Map<String,Object>> filesList = response.path("response.data");
        return filesList.size();
    }

    public int getMessages(String collection,String resellerJWTToken,int pageNumber,int pageSize){
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.inboxMessagesBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(), new RequestLoggingFilter());
        request.header("Content-Type","application/json");
        request.header("reseller-jwt-token",resellerJWTToken);
        request.queryParam("collection",collection);
        request.queryParam("pgNumber",pageNumber);
        request.queryParam("pgSize",pageSize);
        response = request.get();
        Assert.assertEquals(response.statusCode(),200);
        List<Map<String,Object>> messageList = response.path("response.data");
        return messageList.size();
    }

    public void verifyGetProfile(String resellerJWTToken){
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.userProfileBasePath;
        RequestSpecification request = given().config(config).filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",resellerJWTToken);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> fieldsList = response.path("fields");
    }

    public Map<String,Map<String,Object>> getClassDetails(String resellerJWTToken,String orgId,int offset,int size){
        Map<String,Map<String,Object>> classStudentMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.myStudentsBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("embibe-token",resellerJWTToken);
        request.queryParam("offset",offset);
        request.queryParam("size",size);
        request.queryParam("orgId",orgId);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> classList = response.path("data");
        for (int i = 0; i <classList.size() ; i++) {
            Map<String,Object> classMap = classList.get(i);
            Map<String,Object> detailsMap = new LinkedHashMap<>();
            detailsMap.put("subject",classMap.get("subject"));
            detailsMap.put("strength",classMap.get("strength"));
            classStudentMap.put(classMap.get("class").toString(),detailsMap);
        }
        return classStudentMap;
    }
    public Map<String,List<String>> getStudentDetails(String resellerJWTToken,String classId,String subjectKvCode){
        Map<String,List<String>> classStudentsMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.myStudentsBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("embibe-token",resellerJWTToken);
        request.queryParam("classId",classId);
        request.queryParam("kvCode",subjectKvCode);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
//        List<Map<String,Object>> classList = response.path("data");
//        for (int i = 0; i <classList.size() ; i++) {
//            Map<String,Object> classMap = classList.get(i);
            List<Map<String,Object>> studentsList = response.path("students");
            List<String> studentNames = new ArrayList<>();
            for (int j = 0; j <studentsList.size() ; j++) {
                Map<String,Object> studentsMap = studentsList.get(j);
                studentNames.add(studentsMap.get("name").toString());
            }
            classStudentsMap.put(classId,studentNames);

//        }
        return classStudentsMap;
    }

    public List<String> getAttendancePercentage(String resellerJWTToken,String teacherId,String classId,String subject,String instituteID){
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.attendanceAnalyticsBasePath;
        RequestSpecification request = given().config(config).filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",resellerJWTToken);
        request.queryParam("instituteId",instituteID);
        request.queryParam("classId",classId);
        request.queryParam("subject",subject);
        request.queryParam("teacherID",teacherId);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        Map<String,String> percentageMap = response.path("attendance_percentage");
        Set<String> set = percentageMap.keySet();
        List<String> list = new ArrayList<>();
        for (String str:set) {
            list.add(percentageMap.get(str));
        }
        return list;
    }
    public Map<String,Integer> getAttendanceAnalytics(String jwtToken,String teacherId,String classId,String subject,String instituteID,String subjectKveCode){
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.attendanceAnalyticsBasePath;
        RequestSpecification request = given().config(config).filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",getresellerJwtTokenForShowAPI());
        request.queryParam("instituteId",instituteID);
        request.queryParam("classId",classId);
        request.queryParam("subject",subject);
        request.queryParam("teacherID",teacherId);
        request.queryParam("subjectKveCode",subjectKveCode);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        Map<String,String> dataMap = response.path("analytics_data.today_attendance");
        Map<String,Integer> analyticsMap = new LinkedHashMap<>();
        analyticsMap.put("total", Integer.valueOf(String.valueOf(dataMap.get("total"))));
        analyticsMap.put("percentage",Integer.valueOf(String.valueOf(dataMap.get("percentage"))));
        analyticsMap.put("count",Integer.valueOf(String.valueOf(dataMap.get("count"))));
//        Float f = (Float)response.path("analytics_data.avg_attendance");
        analyticsMap.put("avgAttendance",response.path("analytics_data.avg_attendance"));
        analyticsMap.put("perfectAttendance",response.path("analytics_data.perfect_attendees"));
        analyticsMap.put("belowAvg",response.path("analytics_data.attendees_below_avg"));
        return analyticsMap;
    }
    public static Long getEpochByDateTime(LocalDate date, LocalTime time) {
        LocalDateTime localDateTime = LocalDateTime.of(date, time);
        Instant instant = localDateTime.atZone(defaultZoneId).toInstant();
        return instant.getEpochSecond();
    }
    public long getEpochTime(){
        Instant instant = Instant.now();
        long epochTime = instant.toEpochMilli();
        return  epochTime;

    }
    public long getEpochTimeInSec(){
        Instant instant = Instant.now();
        long epochTime = instant.getEpochSecond();
        return  epochTime;

    }

    public int getAllDownloadFilesCount(){
        String home = System.getProperty("user.home");
        String downloadPath = null;
        if (SystemUtils.IS_OS_MAC){
            downloadPath = home + "/Downloads/";
        }else if (SystemUtils.IS_OS_LINUX){
            downloadPath = home + "/Downloads/";
        }else if(SystemUtils.IS_OS_WINDOWS){
            downloadPath = home + "\\Downloads\\";
        }
        File dir = new File(downloadPath);
        File[] dir_contents = dir.listFiles();
        return dir_contents.length;
    }
    public Map<String, Map<String,Object>> getClassIdAndKvCodes(String jwtToken){
        Map<String, Map<String,Object>> classInfoMap = new LinkedHashMap<>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.myClassesBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("embibe-token",jwtToken);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        List<Map<String,Object>> classList = response.path("data");
        for (int i = 0; i < classList.size(); i++) {
            Map<String,Object> classMap = classList.get(i);
            Map<String,Object> detailsMap = new LinkedHashMap<>();
            detailsMap.put("classId",classMap.get("classId"));
            detailsMap.put("subjectKvCode",classMap.get("subjectKvCode"));
            detailsMap.put("subject",classMap.get("subject"));
            detailsMap.put("strength",classMap.get("strength"));
            classInfoMap.put(classMap.get("name").toString(),detailsMap);
        }
        return classInfoMap;
    }
    public int getClassCount(String EmbibetokenForAPI) {
        int count = 0;
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",EmbibetokenForAPI);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        ShowHelper value = response.as(ShowHelper.class, ObjectMapperType.GSON);
        for (int i =0;i< value.getClassDetails().size();i++){
            count++;
            System.out.println(value.getClassDetails().get(i).getName());

        }
        return value.getClassDetails().size();
    }
    public List<String> getSubjectsNames(String EmbibetokenForAPI) {

        List<String> l1 = new ArrayList<String>();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",EmbibetokenForAPI);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        ShowHelper value = response.as(ShowHelper.class, ObjectMapperType.GSON);
        for (int i =0;i< value.getSubjects().size();i++){
            l1.add(value.getSubjects().get(i));

            System.out.println(value.getSubjects());

        }
        return l1;
    }
    public HashMap<String,String> getOutcomesPanel(String startDate,String endDate) {
        HashMap<String,String>  hashMap = new HashMap<>();

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.trackOverViewBasePath;
        Response response = given().urlEncodingEnabled(false).
        header("Origin",Properties.origin).
        header("embibe-token",getresellerJwtTokenForShowAPI()).
        queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("orgId",Properties.orgId).
                queryParam("startDate",startDate).
                queryParam("endDate",endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        TrackOverViewHelper value = response.as(TrackOverViewHelper.class, ObjectMapperType.GSON);
        for (int i =0;i< value.getOutcomesPanel().getData().size();i++){
            /*if(value.getOutcomesPanel().getData().get(i).getName().equalsIgnoreCase("Mastery Improvement"));
            {
                value.getOutcomesPanel().getData().get(i).getValue();
            }*/
            hashMap.put(value.getOutcomesPanel().getData().get(i).getName(),value.getOutcomesPanel().getData().get(i).getValue());


        }
        for (int i = 0; i < value.getEffortInsights().getData().size(); i++) {
            hashMap.put(value.getEffortInsights().getData().get(i).getName(), value.getEffortInsights().getData().get(i).getValue());


        }
        return hashMap;
    }
    public HashMap<String,String> getOutcomesPanel2ndData(String startDate,String endDate){
        HashMap<String,String>  hashMap = new HashMap<>();

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.trackOverViewBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin",Properties.origin).
                header("embibe-token",Properties.embibeToken).
                queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("orgId",Properties.orgId).
                queryParam("startDate",startDate).
                queryParam("endDate",endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        TrackOverViewHelper value = response.as(TrackOverViewHelper.class, ObjectMapperType.GSON);
        for (int i =0;i< value.getOutcomesPanel().getData().size();i++){
            hashMap.put(value.getOutcomesPanel().getData().get(i).getName(),value.getOutcomesPanel().getData().get(i).getPercentChange());


        }
        for (int i = 0; i < value.getEffortInsights().getData().size(); i++) {
            hashMap.put(value.getEffortInsights().getData().get(i).getName(), value.getEffortInsights().getData().get(i).getPercentChange());


        }
        return hashMap;
    }
    public List<JSONObject> getSyllabusCoverage(String startDate,String endDate){

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.SyllabusCoverageBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin",Properties.origin).
                header("embibe-token",Properties.embibeToken).
                queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("orgId",Properties.orgId).
                queryParam("locale",Properties.locale).
                queryParam("startDate",startDate).
                queryParam("endDate",endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        HelperSyllabusCoverage value = response.as(HelperSyllabusCoverage.class, ObjectMapperType.GSON);
        List<JSONObject> values = new ArrayList<>();
        for(int i =0;i<value.getData().size();i++){
            JSONObject obj = new JSONObject();
            obj.put("planned",value.getData().get(i).getPlanned());
            obj.put("actual",value.getData().get(i).getActual());
            values.add(obj);




        }

        return values;
    }
    public HashMap<String,String> gettrackLearningGapsData(String startDate,String endDate) {
        HashMap<String, String> hashMap = new HashMap<>();

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.trackTeachAnalysisBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin", Properties.origin).
                header("embibe-token", Properties.embibeToken).
                queryParam("classId", Properties.classID).
                queryParam("kvCode", Properties.kvCode).
                queryParam("orgId", Properties.orgId).
                queryParam("locale", Properties.locale).
                queryParam("startDate", startDate).
                queryParam("endDate", endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        TrackLearningGapsHelper value = response.as(TrackLearningGapsHelper.class, ObjectMapperType.GSON);
        hashMap.put(value.getOccurred().getDesc(), String.valueOf(value.getOccurred().getVal()));
        hashMap.put(value.getResolved().getDesc(), String.valueOf(value.getResolved().getVal()));
        hashMap.put(value.getTopFive().getLabel(), String.valueOf(value.getTopFive().getData().size()));
        hashMap.put(value.getBottomFive().getLabel(), String.valueOf(value.getBottomFive().getData().size()));

        return hashMap;
    }
    public List<JSONObject> getTeachAnalysisTabData(String startDate,String endDate){

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.trackTeachAnalysisBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin",Properties.origin).
                header("embibe-token",Properties.embibeToken).
                queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("orgId",Properties.orgId).
                queryParam("startDate",startDate).
                queryParam("filter" , Properties.trackTeachfilter).
                queryParam("size",Properties.trackDataSize).
                queryParam("offset" ,Properties.getOffset).
                queryParam("endDate",endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        TrackTeachAnalysisHelper value = response.as(TrackTeachAnalysisHelper.class, ObjectMapperType.GSON);
        List<JSONObject> values = new ArrayList<>();
        for(int i =0;i<value.getData().size();i++){
            JSONObject obj = new JSONObject();
            obj.put("date",value.getData().get(i).getDate());
            obj.put("periodCount",value.getData().get(i).getPeriodCount());
            obj.put("chapterName",value.getData().get(i).getChapterName());
            obj.put("topicName",value.getData().get(i).getTopicName());
            obj.put("classAttendance",value.getData().get(i).getClassAttendance());
            obj.put("classParticipation",value.getData().get(i).getClassParticipation());
            values.add(obj);
        }        return values;

    }
    public List<JSONObject> getTestAnalysisData(String startDate,String endDate){

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.trackTestAnalysisBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin",Properties.origin).
                header("embibe-token",Properties.embibeToken).
                queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("startDate",startDate).
                queryParam("size",Properties.trackDataSize).
                queryParam("offset" ,Properties.getOffset).
                queryParam("endDate",endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        TrackTestAnalysisHelper value = response.as(TrackTestAnalysisHelper.class, ObjectMapperType.GSON);
        List<JSONObject> values = new ArrayList<>();
        for(int i =0;i<value.getData().size();i++){
            JSONObject obj = new JSONObject();
           /* obj.put("Test Name",value.getData().get(i).getName());
            obj.put("% Avg. Score",value.getData().get(i).getPeriodCount());
            obj.put("Avg. Marks",value.getData().get(i).getChapterName());
            obj.put("% Submission",value.getData().get(i).getTopicName());
            obj.put("Test Type",value.getData().get(i).getClassAttendance());
            obj.put("classParticipation",value.getData().get(i).getClassParticipation());*/
            values.add(obj);
        }        return values;

    }
    public List<JSONObject> getTrackStudentWiseAnalysis(String startDate,String endDate){

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.trackStudentWiseAnalysisBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin",Properties.origin).
                header("embibe-token",Properties.embibeToken).
                queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("startDate",startDate).
                queryParam("size",Properties.trackDataSize).
                queryParam("orgId",Properties.orgId).
                queryParam("offset" ,Properties.getOffset).
                queryParam("endDate",endDate).log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        TrackStudentwiseHelper value = response.as(TrackStudentwiseHelper.class, ObjectMapperType.GSON);
        List<JSONObject> values = new ArrayList<>();
        for(int i =0;i<value.getData().size();i++) {
            JSONObject obj = new JSONObject();
            obj.put("studentName",value.getData().get(i).getStudentName());
            obj.put("classRank",value.getData().get(i).getClassRank());
            obj.put("performance",value.getData().get(i).getPerformance());
            obj.put("videosWatched",value.getData().get(i).getVideosWatched());
            obj.put("questionsPracticed",value.getData().get(i).getQuestionsPracticed());
            obj.put("testTaken",value.getData().get(i).getTestTaken());
            obj.put("totalTime",value.getData().get(i).getTotalTime());
            obj.put("studentAccuracy",value.getData().get(i).getStudentAccuracy());
            values.add(obj);
        }return values;
    }
    public void CalenderReset() {
        File file = new File(System.getProperty("user.dir") +"/CalenderFile.csv");


        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.calenderUploadBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("reseller-jwt-token",Properties.resellerJWTTokenForCalender).
                header("accept","*/*").
                queryParam("startDate","2022-01-01").
                queryParam("endDate","2022-11-01").
                queryParam("overwrite","true").

                multiPart("file",file).
                when().post().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);

    }
    public int getMyClassCount(String jwtToken) {
        int count = 0;
        jwtToken = getEmbibeTokenShowAPI();
        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request = given().config(config);//.filters(new ResponseLoggingFilter(),new RequestLoggingFilter());
        request.header("reseller-jwt-token",jwtToken);
        response = request.get();
        Assert.assertEquals(response.statusCode(), 200);
        ShowHelper value = response.as(ShowHelper.class, ObjectMapperType.GSON);
        for (int i =0;i< value.getClassDetails().size();i++){
            count++;
            System.out.println(value.getClassDetails().get(i).getName());

        }
        return value.getClassDetails().size();
    }
    public String getresellerJwtTokenForShowAPI() {


        Response response1 = null;
        Response response2 = null;
        Response response3 = null;


        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.availableOrg;
        RequestSpecification request = given().config(config);
        request.header("Origin",Properties.origin);
        request.queryParam("email",Properties.userName);
        response1 = request.get();
        Assert.assertEquals(response1.statusCode(), 200);
        response1.prettyPrint();
        JsonPath jsonPathEvaluator = response1.jsonPath();
        List<Map<String,Object>> classList = response1.path("$");

        List<String> list = new ArrayList<String>();
        list.add(classList.get(0).get("orgToken").toString());
        list.add(classList.get(0).get("orgId").toString());

        System.out.println("this is the res1"+classList.get(0).get("orgToken"));

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.basePathOfUserAuth;
        RequestSpecification request1 = given().config(config);
        request1.header("org-token",list.get(0));
        request1.header("Origin",Properties.origin).log().all();






        String s = "{\"email\":\""+Properties.userName+"\"" +
                ",\"password\":\""+Properties.password+"\"" +
                ",\"orgId\":\""+classList.get(0).get("orgToken")+"\"" +
                ",\"device_id\":\"0.19776670736051405\"}";
        request1.body(s);

        response2 = request1.post();


        Assert.assertEquals(response2.statusCode(), 200);
        response2.prettyPrint();

       String token= response2.getHeader("embibe-token");
        System.out.println("token value is "+token);


        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.showBasePath;
        RequestSpecification request2 = given().config(config);
        request2.header("reseller-jwt-token",token);
        request2.header("Origin",Properties.origin).log().all();
        response3 = request2.get();


        Assert.assertEquals(response3.statusCode(), 200);
        response3.prettyPrint();
        Headers h1 = response3.headers();
        String h2 = response3.getHeader("reseller-jwt-token");
        String token1= response2.getHeader("reseller-jwt-token");
        System.out.println("jwt token value is "+h2);

        return h2;

    }
    public String getEmbibeTokenShowAPI() {


        Response response11 = null;
        Response response22 = null;
        Response response3 = null;


        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.availableOrg;
        RequestSpecification request = given().config(config);
        request.header("Origin", Properties.origin);
        request.queryParam("email", Properties.userName);
        response11 = request.get();
        Assert.assertEquals(response11.statusCode(), 200);
        response11.prettyPrint();
        JsonPath jsonPathEvaluator = response11.jsonPath();
        List<Map<String, Object>> classList = response11.path("$");

        List<String> list = new ArrayList<String>();
        list.add(classList.get(0).get("orgToken").toString());
        list.add(classList.get(0).get("orgId").toString());

        System.out.println("this is the res1" + classList.get(0).get("orgToken"));

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.basePathOfUserAuth;
        RequestSpecification request1 = given().config(config);
        request1.header("org-token", list.get(0));
        request1.header("Origin", Properties.origin).log().all();


        String s = "{\"email\":\"" + Properties.userName + "\"" +
                ",\"password\":\"" + Properties.password + "\"" +
                ",\"orgId\":\"" + classList.get(0).get("orgToken") + "\"" +
                ",\"device_id\":\"0.19776670736051405\"}";
        request1.body(s);

        response22 = request1.post();


        Assert.assertEquals(response22.statusCode(), 200);
        response22.prettyPrint();

        String token = response22.getHeader("embibe-token");
        System.out.println("token value is " + token);
        return token;
    }
    public HashMap<String,String> getattemptAnalysis() {
        HashMap<String,String>  hashMap = new HashMap<>();

        RestAssured.baseURI = Properties.preProdBaseUrl;
        RestAssured.basePath = Properties.assignAnalysisBasePath;
        Response response = given().urlEncodingEnabled(false).
                header("Origin",Properties.origin).
                header("embibe-token",getEmbibeTokenShowAPI()).
                queryParam("classId",Properties.classID).
                queryParam("kvCode",Properties.kvCode).
                queryParam("homeworkId","628cbb13a982553684490139").log().all().
                when().get().then().extract().response();
        response.prettyPrint();
        Assert.assertEquals(response.statusCode(), 200);
        AttemptAnalysisAPIHelper value = response.as(AttemptAnalysisAPIHelper.class, ObjectMapperType.GSON);
        for (int i =0;i< value.getData().size();i++){


            hashMap.put(value.getData().get(i).getAttemptType(), String.valueOf(value.getData().get(i).getAttemptCount()));


        }

        return hashMap;
    }

}