
package com.embibe.schoolapp.api.trackAttendanceAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class WorkingDays {

    @SerializedName("attendedWorkingDays")
    @Expose
    private Integer attendedWorkingDays;
    @SerializedName("totalWorkingDays")
    @Expose
    private Integer totalWorkingDays;

    public Integer getAttendedWorkingDays() {
        return attendedWorkingDays;
    }

    public void setAttendedWorkingDays(Integer attendedWorkingDays) {
        this.attendedWorkingDays = attendedWorkingDays;
    }

    public Integer getTotalWorkingDays() {
        return totalWorkingDays;
    }

    public void setTotalWorkingDays(Integer totalWorkingDays) {
        this.totalWorkingDays = totalWorkingDays;
    }

}
