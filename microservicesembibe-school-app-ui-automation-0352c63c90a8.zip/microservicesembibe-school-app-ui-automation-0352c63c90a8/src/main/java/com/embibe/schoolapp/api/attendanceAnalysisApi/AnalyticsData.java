
package com.embibe.schoolapp.api.attendanceAnalysisApi;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class AnalyticsData {

    @SerializedName("today_attendance")
    @Expose
    private TodayAttendance todayAttendance;
    @SerializedName("avg_attendance")
    @Expose
    private Double avgAttendance;
    @SerializedName("perfect_attendees")
    @Expose
    private Integer perfectAttendees;
    @SerializedName("attendees_below_avg")
    @Expose
    private Integer attendeesBelowAvg;

    public TodayAttendance getTodayAttendance() {
        return todayAttendance;
    }

    public void setTodayAttendance(TodayAttendance todayAttendance) {
        this.todayAttendance = todayAttendance;
    }

    public Double getAvgAttendance() {
        return avgAttendance;
    }

    public void setAvgAttendance(Double avgAttendance) {
        this.avgAttendance = avgAttendance;
    }

    public Integer getPerfectAttendees() {
        return perfectAttendees;
    }

    public void setPerfectAttendees(Integer perfectAttendees) {
        this.perfectAttendees = perfectAttendees;
    }

    public Integer getAttendeesBelowAvg() {
        return attendeesBelowAvg;
    }

    public void setAttendeesBelowAvg(Integer attendeesBelowAvg) {
        this.attendeesBelowAvg = attendeesBelowAvg;
    }

}
