
package com.embibe.schoolapp.api.trackStudentWiseAnalysis;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class TestTaken {

    @SerializedName("numberOfTestsTaken")
    @Expose
    private Integer numberOfTestsTaken;
    @SerializedName("durationInMinutes")
    @Expose
    private Double durationInMinutes;

    public Integer getNumberOfTestsTaken() {
        return numberOfTestsTaken;
    }

    public void setNumberOfTestsTaken(Integer numberOfTestsTaken) {
        this.numberOfTestsTaken = numberOfTestsTaken;
    }

    public Double getDurationInMinutes() {
        return durationInMinutes;
    }

    public void setDurationInMinutes(Double durationInMinutes) {
        this.durationInMinutes = durationInMinutes;
    }

}
