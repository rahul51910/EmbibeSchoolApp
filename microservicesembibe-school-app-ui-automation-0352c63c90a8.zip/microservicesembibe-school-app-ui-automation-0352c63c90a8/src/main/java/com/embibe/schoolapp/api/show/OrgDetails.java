
package com.embibe.schoolapp.api.show;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class OrgDetails {

    @SerializedName("orgName")
    @Expose
    private String orgName;
    @SerializedName("orgAddress")
    @Expose
    private String orgAddress;
    @SerializedName("orgState")
    @Expose
    private String orgState;
    @SerializedName("orgCity")
    @Expose
    private String orgCity;
    @SerializedName("orgPincode")
    @Expose
    private String orgPincode;
    @SerializedName("mobile")
    @Expose
    private String mobile;
    @SerializedName("instituteLogo")
    @Expose
    private String instituteLogo;
    @SerializedName("personaType")
    @Expose
    private String personaType;
    @SerializedName("signUpNeeded")
    @Expose
    private Boolean signUpNeeded;

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getOrgAddress() {
        return orgAddress;
    }

    public void setOrgAddress(String orgAddress) {
        this.orgAddress = orgAddress;
    }

    public String getOrgState() {
        return orgState;
    }

    public void setOrgState(String orgState) {
        this.orgState = orgState;
    }

    public String getOrgCity() {
        return orgCity;
    }

    public void setOrgCity(String orgCity) {
        this.orgCity = orgCity;
    }

    public String getOrgPincode() {
        return orgPincode;
    }

    public void setOrgPincode(String orgPincode) {
        this.orgPincode = orgPincode;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getInstituteLogo() {
        return instituteLogo;
    }

    public void setInstituteLogo(String instituteLogo) {
        this.instituteLogo = instituteLogo;
    }

    public String getPersonaType() {
        return personaType;
    }

    public void setPersonaType(String personaType) {
        this.personaType = personaType;
    }

    public Boolean getSignUpNeeded() {
        return signUpNeeded;
    }

    public void setSignUpNeeded(Boolean signUpNeeded) {
        this.signUpNeeded = signUpNeeded;
    }

}
