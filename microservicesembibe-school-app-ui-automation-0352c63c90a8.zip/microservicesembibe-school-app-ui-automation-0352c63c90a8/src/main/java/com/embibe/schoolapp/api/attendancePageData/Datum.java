
package com.embibe.schoolapp.api.attendancePageData;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class Datum {

    @SerializedName("parentOrgId")
    @Expose
    private String parentOrgId;
    @SerializedName("rollNumber")
    @Expose
    private String rollNumber;
    @SerializedName("fullName")
    @Expose
    private String fullName;
    @SerializedName("emailId")
    @Expose
    private String emailId;
    @SerializedName("testAppStudentId")
    @Expose
    private Integer testAppStudentId;
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("rootOrgId")
    @Expose
    private String rootOrgId;
    @SerializedName("status")
    @Expose
    private String status;

    public String getParentOrgId() {
        return parentOrgId;
    }

    public void setParentOrgId(String parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public String getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(String rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Integer getTestAppStudentId() {
        return testAppStudentId;
    }

    public void setTestAppStudentId(Integer testAppStudentId) {
        this.testAppStudentId = testAppStudentId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRootOrgId() {
        return rootOrgId;
    }

    public void setRootOrgId(String rootOrgId) {
        this.rootOrgId = rootOrgId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

}
