
package com.embibe.schoolapp.api.trackTestAnalysis;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;


public class TrackTestAnalysisHelper {

    @SerializedName("data")
    @Expose
    private List<Object> data = null;
    @SerializedName("pagination")
    @Expose
    private Pagination pagination;
    @SerializedName("headers")
    @Expose
    private List<Header> headers = null;

    public List<Object> getData() {
        return data;
    }

    public void setData(List<Object> data) {
        this.data = data;
    }

    public Pagination getPagination() {
        return pagination;
    }

    public void setPagination(Pagination pagination) {
        this.pagination = pagination;
    }

    public List<Header> getHeaders() {
        return headers;
    }

    public void setHeaders(List<Header> headers) {
        this.headers = headers;
    }

}
